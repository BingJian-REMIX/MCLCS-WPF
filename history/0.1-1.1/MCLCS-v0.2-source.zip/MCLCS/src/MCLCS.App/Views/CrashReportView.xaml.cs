using System.Windows;
using MCLCS.Core.Launcher;

namespace MCLCS.App.Views;

public partial class CrashReportView : Window
{
    public CrashReportView()
    {
        InitializeComponent();
    }

    /// <summary>根据崩溃报告文件分析并展示。文件不存在时显示提示。</summary>
    public CrashReportView(string reportPath) : this()
    {
        if (string.IsNullOrEmpty(reportPath) || !System.IO.File.Exists(reportPath))
        {
            DataContext = new CrashAnalysis { ExceptionType = "无崩溃报告", Summary = "未找到崩溃报告文件。" };
            return;
        }

        var text = System.IO.File.ReadAllText(reportPath);
        var analysis = CrashAnalyzer.Analyze(text);
        analysis.RawReport = text;
        DataContext = analysis;
    }
}
