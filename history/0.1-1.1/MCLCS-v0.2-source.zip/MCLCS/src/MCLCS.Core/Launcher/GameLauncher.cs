using System.Diagnostics;
using MCLCS.Core.Download;
using MCLCS.Core.Models;
using MCLCS.Core.Utils;

namespace MCLCS.Core.Launcher;

/// <summary>一次启动的结果。</summary>
public class LaunchResult
{
    public int ExitCode { get; set; }
    public string? CrashReportPath { get; set; }
    public bool Crashed => CrashReportPath is not null;
}

/// <summary>
/// 游戏启动：合并版本、构建 classpath 与参数、解压 natives、启动 Java 进程，
/// 退出后检测崩溃报告。
/// </summary>
public static class GameLauncher
{
    /// <summary>构造 ${...} 变量字典（含 classpath、natives_directory 等）。</summary>
    public static Dictionary<string, string> BuildVariables(VersionJson merged,
        string gameRoot, string leafId, string nativesDir, LaunchOptions options)
    {
        var classpath = ClasspathBuilder.ComputeClasspath(gameRoot, leafId, merged);
        var assetsIndexName = merged.Assets ?? merged.AssetIndex?.Id ?? "";

        var vars = new Dictionary<string, string>
        {
            ["auth_player_name"] = options.Username,
            ["auth_uuid"] = options.Uuid,
            ["auth_access_token"] = options.AccessToken,
            ["auth_session"] = options.AccessToken,
            ["auth_xuid"] = options.UserType == "msa" ? options.Uuid : "0",
            ["user_type"] = options.UserType,
            ["user_properties"] = options.UserProperties,
            ["version_name"] = merged.Id,
            ["version_type"] = merged.Type,
            ["assets_root"] = PathEx.AssetsDir(gameRoot),
            ["assets_index_name"] = assetsIndexName,
            ["game_directory"] = gameRoot,
            ["natives_directory"] = nativesDir,
            ["library_directory"] = PathEx.LibrariesDir(gameRoot),
            ["classpath"] = classpath,
            ["classpath_separator"] = Path.PathSeparator.ToString(),
            ["launcher_name"] = GameConstants.LauncherName,
            ["launcher_version"] = GameConstants.LauncherVersion,
            ["max_mem"] = $"{options.MaxMemoryMb}M"
        };

        if (options.Resolution.HasValue)
        {
            vars["resolution_width"] = options.Resolution.Value.Width.ToString();
            vars["resolution_height"] = options.Resolution.Value.Height.ToString();
        }

        return vars;
    }

    /// <summary>启动游戏并等待退出，随后检测崩溃报告。</summary>
    public static async Task<LaunchResult> LaunchAsync(string gameRoot,
        string versionId,
        JavaInfo java,
        LaunchOptions options,
        ILogger? logger = null,
        CancellationToken ct = default)
    {
        var merged = VersionMerger.Merge(gameRoot, versionId);
        var nativesDir = PathEx.NativesDir(gameRoot, versionId);
        Directory.CreateDirectory(nativesDir);

        var variables = BuildVariables(merged, gameRoot, versionId, nativesDir, options);
        var resolved = ArgumentProcessor.Process(merged, variables, options, nativesDir);

        // 解压原生库
        var natives = ClasspathBuilder.GetNativeEntries(gameRoot, merged, nativesDir);
        ClasspathBuilder.ExtractNatives(natives);

        var psi = new ProcessStartInfo
        {
            FileName = java.JavaExe,
            UseShellExecute = false,
            CreateNoWindow = false,
            WorkingDirectory = gameRoot
        };

        foreach (var a in resolved.JvmArgs) psi.ArgumentList.Add(a);
        psi.ArgumentList.Add(resolved.MainClass);
        foreach (var a in resolved.GameArgs) psi.ArgumentList.Add(a);

        logger?.Log($"启动版本 {merged.Id}（{java.MajorVersion}）：{resolved.MainClass}");

        using var proc = Process.Start(psi)
            ?? throw new InvalidOperationException("无法启动游戏进程");

        await proc.WaitForExitAsync(ct);
        var exitCode = proc.ExitCode;

        var crash = CrashDetector.FindLatestCrashReport(gameRoot);
        if (crash is not null)
            logger?.Log($"检测到崩溃报告：{crash}（退出码 {exitCode}）");
        else
            logger?.Log($"游戏进程已退出（退出码 {exitCode}），未检测到崩溃报告。");

        return new LaunchResult { ExitCode = exitCode, CrashReportPath = crash };
    }
}
