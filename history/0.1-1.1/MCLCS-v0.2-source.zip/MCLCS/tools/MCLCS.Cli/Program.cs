﻿using MCLCS.App.Services;
using MCLCS.Core.Utils;

namespace MCLCS.Cli;

internal static class Program
{
    private static async Task<int> Main(string[] args)
    {
        if (args.Length == 0)
        {
            PrintHelp();
            return 0;
        }

        var cmd = args[0].ToLowerInvariant();
        var remaining = args[1..];

        return cmd switch
        {
            "launch" => await Launch(remaining),
            "list" => await ListVersions(remaining),
            "install" => await Install(remaining),
            "version" => Version(),
            "help" or "--help" or "-h" => { PrintHelp(); return 0; },
            _ => { Console.Error.WriteLine($"未知命令: {cmd}。运行 mclcs help 查看帮助。"); return 1; }
        };
    }

    private static async Task<int> Launch(string[] args)
    {
        var gameRoot = GameConstants.DefaultGameRoot;
        string? versionId = null;
        string? username = null;
        int? memory = null;
        string? java = null;

        var i = 0;
        while (i < args.Length)
        {
            switch (args[i])
            {
                case "--game-dir" when i + 1 < args.Length: gameRoot = args[++i]; break;
                case "--username" when i + 1 < args.Length: username = args[++i]; break;
                case "--memory" or "-m" when i + 1 < args.Length && int.TryParse(args[i + 1], out var m): memory = m; i++; break;
                case "--java" when i + 1 < args.Length: java = args[++i]; break;
                default:
                    if (!args[i].StartsWith("-")) versionId = args[i];
                    break;
            }
            i++;
        }

        if (string.IsNullOrEmpty(versionId))
        {
            Console.Error.WriteLine("用法: mclcs launch <versionId> [--username name] [--memory MB] [--java path] [--game-dir path]");
            return 1;
        }

        var svc = new LauncherService(gameRoot);
        svc.Logged += msg => Console.WriteLine($"[MCLCS] {msg}");

        Console.WriteLine($"启动版本: {versionId}");
        try
        {
            var overrides = new LaunchCliOverrides { Username = username, MaxMemoryMb = memory, JavaPath = java };
            var result = await svc.LaunchAsync(versionId, cliOverrides: overrides);
            if (result.CrashReportPath is not null)
                Console.WriteLine($"检测到崩溃报告: {result.CrashReportPath} (退出码 {result.ExitCode})");
            else
                Console.WriteLine($"游戏正常退出 (退出码 {result.ExitCode})");
            return result.ExitCode;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"启动失败: {ex.Message}");
            return 1;
        }
    }

    private static async Task<int> ListVersions(string[] args)
    {
        var gameRoot = GameConstants.DefaultGameRoot;
        if (args.Length >= 2 && args[0] == "--game-dir") gameRoot = args[1];

        var svc = new LauncherService(gameRoot);
        var versions = svc.ListInstalledVersions();

        if (versions.Count == 0)
        {
            Console.WriteLine("暂无已安装版本。使用 mclcs install <vanilla|fabric|forge> <version> 安装。");
            return 0;
        }

        Console.WriteLine($"已安装版本 ({gameRoot})：");
        foreach (var (id, type) in versions)
            Console.WriteLine($"  {id,-30} {type}");
        return 0;
    }

    private static async Task<int> Install(string[] args)
    {
        if (args.Length < 2)
        {
            Console.Error.WriteLine("用法: mclcs install <vanilla|fabric|forge> <versionId> [--game-dir path]");
            return 1;
        }

        var installType = args[0].ToLowerInvariant();
        var versionId = args[1];
        var gameRoot = GameConstants.DefaultGameRoot;
        if (args.Length >= 4 && args[2] == "--game-dir") gameRoot = args[3];

        if (installType is not ("vanilla" or "fabric" or "forge"))
        {
            Console.Error.WriteLine("类型必须是 vanilla、fabric 或 forge");
            return 1;
        }

        var svc = new LauncherService(gameRoot);
        svc.Logged += msg => Console.WriteLine($"[MCLCS] {msg}");

        Console.WriteLine($"安装 {installType} {versionId} → {gameRoot}");
        try
        {
            await svc.InstallAsync(installType, versionId);
            Console.WriteLine("安装完成。");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"安装失败: {ex.Message}");
            return 1;
        }
    }

    private static int Version()
    {
        Console.WriteLine($"MCLCS {GameConstants.LauncherVersion}");
        return 0;
    }

    private static void PrintHelp()
    {
        Console.WriteLine($"MCLCS v{GameConstants.LauncherVersion} — Minecraft 启动器");
        Console.WriteLine();
        Console.WriteLine("命令:");
        Console.WriteLine("  launch  <versionId> [--username <name>] [--memory <MB>] [--java <path>] [--game-dir <path>]");
        Console.WriteLine("  list    [--game-dir <path>]");
        Console.WriteLine("  install <vanilla|fabric|forge> <versionId> [--game-dir <path>]");
        Console.WriteLine("  version");
        Console.WriteLine("  help");
        Console.WriteLine();
        Console.WriteLine($"默认游戏目录: {GameConstants.DefaultGameRoot}");
    }
}
