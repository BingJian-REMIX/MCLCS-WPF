using System.Collections.ObjectModel;
using System.Windows.Input;
using MCLCS.Core.Launcher;
using MCLCS.Core.Localization;
using MCLCS.Core.Mvvm;
using MCLCS.Core.Profiles;
using MCLCS.Core.Recommend;
using MCLCS.Core.Theme;
using MCLCS.Core.Utils;
using MCLCS.App.Services;

namespace MCLCS.App.ViewModels;

/// <summary>玩法偏好勾选项。</summary>
public class CategoryPref : ObservableObject
{
    public GameplayCategory Category { get; set; }
    public string Label { get; set; } = "";

    private bool _isChecked;
    public bool IsChecked
    {
        get => _isChecked;
        set => SetField(ref _isChecked, value);
    }
}

public class SettingsViewModel : ObservableObject
{
    private string _javaPath = "";
    private int _maxMemoryMb = 2048;
    private string _username = "Player";
    private string _extraJvmArgs = "";
    private string _statusMessage = "";
    private AccountEntry? _selectedAccount;
    private ObservableCollection<AccountEntry> _accounts = new();
    private string _selectedTheme = "Dark";
    private string _selectedLanguage = "zh_CN";
    private string _selectedRepairPolicy = "Ask";
    private string _selectedJavaVendor = "Auto";
    private string _selectedAutoInstallMods = "Ask";
    private string _selectedIntelliRecommend = "Enabled";
    private ObservableCollection<CategoryPref> _categoryPreferences = new();

    public string JavaPath
    {
        get => _javaPath;
        set => SetField(ref _javaPath, value);
    }

    public int MaxMemoryMb
    {
        get => _maxMemoryMb;
        set => SetField(ref _maxMemoryMb, value);
    }

    public string Username
    {
        get => _username;
        set => SetField(ref _username, value);
    }

    public string ExtraJvmArgs
    {
        get => _extraJvmArgs;
        set => SetField(ref _extraJvmArgs, value);
    }

    public string StatusMessage
    {
        get => _statusMessage;
        set => SetField(ref _statusMessage, value);
    }

    public AccountEntry? SelectedAccount
    {
        get => _selectedAccount;
        set => SetField(ref _selectedAccount, value);
    }

    public ObservableCollection<AccountEntry> Accounts
    {
        get => _accounts;
        set => SetField(ref _accounts, value);
    }

    public ICommand SaveCommand { get; }
    public ICommand AutoDetectJavaCommand { get; }
    public ICommand RefreshAccountsCommand { get; }
    public ICommand SetActiveAccountCommand { get; }

    public string SelectedTheme
    {
        get => _selectedTheme;
        set
        {
            if (SetField(ref _selectedTheme, value) && Enum.TryParse<ThemeType>(value, out var t))
            {
                ThemeManager.Current = t;
                ThemeManager.SavePreference(GameConstants.DefaultGameRoot);
            }
        }
    }

    public string SelectedLanguage
    {
        get => _selectedLanguage;
        set
        {
            if (SetField(ref _selectedLanguage, value))
            {
                LocaleManager.CurrentLocale = value;
            }
        }
    }

    public List<string> AvailableLanguages => LocaleManager.AvailableLocales;

    /// <summary>崩溃自动修复策略：Always / Ask / Never。</summary>
    public string SelectedRepairPolicy
    {
        get => _selectedRepairPolicy;
        set => SetField(ref _selectedRepairPolicy, value);
    }

    /// <summary>Java 自动安装源：Auto / Temurin / Oracle。</summary>
    public string SelectedJavaVendor
    {
        get => _selectedJavaVendor;
        set => SetField(ref _selectedJavaVendor, value);
    }

    /// <summary>自动安装缺失前置：Always / Ask / Never。</summary>
    public string SelectedAutoInstallMods
    {
        get => _selectedAutoInstallMods;
        set => SetField(ref _selectedAutoInstallMods, value);
    }

    /// <summary>智能推荐总开关：Enabled / LocalOnly / Disabled。</summary>
    public string SelectedIntelliRecommend
    {
        get => _selectedIntelliRecommend;
        set => SetField(ref _selectedIntelliRecommend, value);
    }

    /// <summary>玩法偏好勾选（与推荐卡片过滤联动）。</summary>
    public ObservableCollection<CategoryPref> CategoryPreferences
    {
        get => _categoryPreferences;
        set => SetField(ref _categoryPreferences, value);
    }

    public SettingsViewModel()
    {
        SaveCommand = new RelayCommand(_ => Save());
        AutoDetectJavaCommand = new AsyncRelayCommand(_ => AutoDetectJavaAsync());
        RefreshAccountsCommand = new RelayCommand(_ => RefreshAccounts());
        SetActiveAccountCommand = new RelayCommand(_ => SetActiveAccount());

        var profile = ProfileStore.Load(GameConstants.DefaultGameRoot);
        JavaPath = profile.JavaPath ?? "";
        MaxMemoryMb = profile.MaxMemoryMb;
        Username = profile.DefaultUsername;
        ExtraJvmArgs = string.Join(" ", profile.ExtraJvmArgs);
        SelectedRepairPolicy = profile.RepairPolicy.ToString();
        SelectedJavaVendor = profile.PreferredJavaVendor.ToString();
        SelectedAutoInstallMods = profile.AutoInstallMissingMods.ToString();
        SelectedIntelliRecommend = profile.IntelliRecommend.ToString();
        LoadCategoryPreferences(profile);
        RefreshAccounts();

        // 主题/语言偏好
        ThemeManager.LoadPreference(GameConstants.DefaultGameRoot);
        _selectedTheme = ThemeManager.Current.ToString();
        _selectedLanguage = LocaleManager.CurrentLocale;
    }

    private void LoadCategoryPreferences(LauncherProfile profile)
    {
        var prefs = new ObservableCollection<CategoryPref>();
        foreach (var cat in GameplayCategoryMap.All)
        {
            prefs.Add(new CategoryPref
            {
                Category = cat,
                Label = GameplayCategoryMap.DisplayName(cat),
                IsChecked = profile.PreferredCategories.Contains(cat)
            });
        }
        CategoryPreferences = prefs;
    }

    private void Save()
    {
        var profile = new LauncherProfile
        {
            JavaPath = string.IsNullOrWhiteSpace(JavaPath) ? null : JavaPath,
            MaxMemoryMb = MaxMemoryMb,
            DefaultUsername = Username,
            GameRoot = GameConstants.DefaultGameRoot,
            ExtraJvmArgs = string.IsNullOrWhiteSpace(ExtraJvmArgs)
                ? new List<string>()
                : ExtraJvmArgs.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToList(),
            RepairPolicy = Enum.TryParse<CrashRepairPolicy>(SelectedRepairPolicy, out var rp)
                ? rp : CrashRepairPolicy.Ask,
            PreferredJavaVendor = Enum.TryParse<JavaVendor>(SelectedJavaVendor, out var jv)
                ? jv : JavaVendor.Auto,
            AutoInstallMissingMods = Enum.TryParse<AutoInstallPolicy>(SelectedAutoInstallMods, out var ai)
                ? ai : AutoInstallPolicy.Ask,
            IntelliRecommend = Enum.TryParse<IntelliRecommendMode>(SelectedIntelliRecommend, out var ir)
                ? ir : IntelliRecommendMode.Enabled,
            PreferredCategories = CategoryPreferences.Where(p => p.IsChecked)
                .Select(p => p.Category).ToList()
        };
        ProfileStore.Save(profile);
        StatusMessage = "已保存设置";
    }

    private async Task AutoDetectJavaAsync()
    {
        var java = await JavaDetector.FindBestAsync(GameConstants.MinimumJavaMajorVersion);
        if (java is not null)
        {
            JavaPath = java.JavaExe;
            StatusMessage = $"检测到 Java {java.MajorVersion}：{java.JavaExe}";
        }
        else
        {
            StatusMessage = "未检测到 Java 21，请安装 Java 21 或以上";
        }
    }

    private void RefreshAccounts()
    {
        var list = AccountStore.Load(GameConstants.DefaultGameRoot);
        Accounts = new ObservableCollection<AccountEntry>(list);
    }

    private void SetActiveAccount()
    {
        if (SelectedAccount is null) return;
        AccountStore.MarkUsed(GameConstants.DefaultGameRoot, SelectedAccount.Id);
        StatusMessage = $"当前账号: {SelectedAccount.DisplayName} ({SelectedAccount.AuthType})";
    }
}
