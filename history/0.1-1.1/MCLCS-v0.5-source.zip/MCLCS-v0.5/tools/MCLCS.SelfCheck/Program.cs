using System.Text.Json;
using MCLCS.Core.Auth;
using MCLCS.Core.Download;
using MCLCS.Core.Installers;
using MCLCS.Core.Launcher;
using MCLCS.Core.Localization;
using MCLCS.Core.Models;
using MCLCS.Core.Mods;
using MCLCS.Core.Profiles;
using MCLCS.Core.Recommend;
using MCLCS.Core.Skin;
using MCLCS.Core.Theme;
using MCLCS.Core.Utils;

namespace MCLCS.SelfCheck;

internal static class Program
{
    private static int _passed;
    private static int _failed;

    private static void Check(string name, bool condition)
    {
        if (condition) { _passed++; Console.WriteLine($"  PASS  {name}"); }
        else { _failed++; Console.WriteLine($"  FAIL  {name}"); }
    }

    private static async Task Main()
    {
        Console.WriteLine("=== MCLCS Core 自检 ===\n");

        await JavaDetection();
        MavenParsing();
        ArgumentProcessing();
        ClasspathAndNatives();
        CrashAnalysis();
        OfflineAuth();
        await VersionMerge();
        AccountStoreTest();
        LaunchOptionsAndAuthVars();
        RepairEngineTest();
        ModpackIndexParsing();
        ModrinthModelDeserialization();
        CurseForgeModels();
        LocalizationTest();
        SkinFetcherTest();
        ThemeManagerTest();
        ModMetadataParserTest();
        CrashRepairModelsV05Test();
        LibraryRepairTest();
        RecommendationSystemTest();
        JavaVendorTest();
        AutoInstallPolicyTest();
        ModConflictPlanTest();
        ProfileV05Test();

        Console.WriteLine($"\n=== 结果：{_passed} 通过, {_failed} 失败 ===");
        Environment.Exit(_failed == 0 ? 0 : 1);
    }

    private static async Task JavaDetection()
    {
        Console.WriteLine("[Java 版本解析]");
        Check("1.8.0_301 -> 8", JavaDetector.MajorFromVersionString("1.8.0_301") == 8);
        Check("21.0.3 -> 21", JavaDetector.MajorFromVersionString("21.0.3") == 21);
        Check("17 -> 17", JavaDetector.MajorFromVersionString("17") == 17);
        await Task.CompletedTask;
    }

    private static void MavenParsing()
    {
        Console.WriteLine("[Maven 坐标解析]");
        var c = MavenCoordinate.Parse("org.lwjgl:lwjgl:3.3.1");
        Check("group", c.Group == "org.lwjgl");
        Check("artifact", c.Artifact == "lwjgl");
        Check("version", c.Version == "3.3.1");
        Check("localPath", c.LocalPath() == "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1.jar");
        var c2 = MavenCoordinate.Parse("com.example:mod:1.0:natives-linux");
        Check("classifier path", c2.LocalPath() == "com/example/mod/1.0/mod-1.0-natives-linux.jar");
    }

    private static void ArgumentProcessing()
    {
        Console.WriteLine("[参数解析：规则 + 变量 + 内存注入]");

        // 构造一个含 windows/linux 规则与变量的版本（在 Linux 沙箱上运行）
        var version = new VersionJson
        {
            Id = "test",
            MainClass = "net.minecraft.client.main.Main",
            Arguments = new Arguments
            {
                Jvm = new List<ArgumentItem>
                {
                    new() { Values = new() { "-XX:+UseG1GC" } },
                    new() { Rules = new() { new Rule { Action = "allow", Os = new OsRule { Name = "windows" } } },
                            Values = new() { "-DWINDOWS_MARKER=1" } },
                    new() { Rules = new() { new Rule { Action = "allow", Os = new OsRule { Name = "linux" } } },
                            Values = new() { "-DLINUX_MARKER=1" } }
                },
                Game = new List<ArgumentItem>
                {
                    new() { Values = new() { "--username", "${auth_player_name}" } },
                    new() { Rules = new() { new Rule { Action = "allow", Features = new() { { "has_custom_resolution", true } } } },
                            Values = new() { "--width", "${resolution_width}" } }
                }
            }
        };

        var vars = new Dictionary<string, string>
        {
            ["auth_player_name"] = "Steve",
            ["natives_directory"] = "/tmp/natives"
        };
        var options = new LaunchOptions { MaxMemoryMb = 4096 };
        var resolved = ArgumentProcessor.Process(version, vars, options, "/tmp/natives");

        Check("保留 -XX:+UseG1GC", resolved.JvmArgs.Contains("-XX:+UseG1GC"));
        Check("包含 linux 标记", resolved.JvmArgs.Contains("-DLINUX_MARKER=1"));
        Check("排除 windows 标记", !resolved.JvmArgs.Contains("-DWINDOWS_MARKER=1"));
        Check("注入 -Xmx4096M", resolved.JvmArgs.Any(a => a == "-Xmx4096M"));
        Check("注入 java.library.path", resolved.JvmArgs.Any(a => a.StartsWith("-Djava.library.path=")));
        Check("注入 org.lwjgl.librarypath", resolved.JvmArgs.Any(a => a.StartsWith("-Dorg.lwjgl.librarypath=")));
        Check("变量替换用户名", resolved.GameArgs.Count >= 2 && resolved.GameArgs[1] == "Steve");
        Check("无自定义分辨率时排除 --width", !resolved.GameArgs.Contains("--width"));

        // 旧版 minecraftArguments 回退
        Console.WriteLine("[参数解析：旧版 minecraftArguments]");
        var legacy = new VersionJson
        {
            Id = "legacy",
            MinecraftArguments = "-Xmx2G -Dfoo=bar -cp ${classpath} net.minecraft.client.main.Main --username ${auth_player_name}"
        };
        var lvars = new Dictionary<string, string> { ["auth_player_name"] = "Alex", ["classpath"] = "a.jar;b.jar" };
        var lresolved = ArgumentProcessor.Process(legacy, lvars, new LaunchOptions { MaxMemoryMb = 2048 }, "/tmp/n");
        Check("legacy 提取 mainClass", lresolved.MainClass == "net.minecraft.client.main.Main");
        Check("legacy 替换用户名", lresolved.GameArgs.Contains("Alex"));
        Check("legacy 内存被用户值覆盖", lresolved.JvmArgs.Contains("-Xmx2048M"));
    }

    private static void ClasspathAndNatives()
    {
        Console.WriteLine("[classpath 构建 + natives]");
        var root = Path.Combine(Path.GetTempPath(), "mclcs_cp_" + Guid.NewGuid().ToString("N"));
        try
        {
            var vdir = Path.Combine(root, "versions", "1.20.1");
            Directory.CreateDirectory(vdir);
            File.WriteAllText(Path.Combine(vdir, "1.20.1.jar"), "dummy");

            var libDir = Path.Combine(root, "libraries", "com", "mojang", "log4j", "2.19.1");
            Directory.CreateDirectory(libDir);
            File.WriteAllText(Path.Combine(libDir, "log4j-2.19.1.jar"), "dummy");

            var version = new VersionJson
            {
                Id = "1.20.1",
                Libraries = new List<Library>
                {
                    new() { Name = "com.mojang:log4j:2.19.1",
                            Downloads = new LibraryDownloads { Artifact = new DownloadInfo { Path = "com/mojang/log4j/2.19.1/log4j-2.19.1.jar" } } },
                    new() { Name = "org.lwjgl:lwjgl:3.3.1",
                            Natives = new Dictionary<string, string> { { "linux", "natives-linux" } },
                            Downloads = new LibraryDownloads { Classifiers = new() { ["natives-linux"] = new DownloadInfo { Path = "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1-natives-linux.jar" } } } }
                }
            };

            var cp = ClasspathBuilder.ComputeClasspath(root, "1.20.1", version);
            Check("classpath 含版本 jar", cp.Contains("1.20.1.jar"));
            Check("classpath 含库 jar", cp.Contains("log4j-2.19.1.jar"));

            var natives = ClasspathBuilder.GetNativeEntries(root, version, Path.Combine(root, "natives"));
            Check("识别 1 个 natives 条目", natives.Count == 1);
            Check("natives 路径含 natives-linux", natives.Count == 1 && natives[0].JarPath.Contains("natives-linux"));
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }
    }

    private static void CrashAnalysis()
    {
        Console.WriteLine("[崩溃分析]");
        var oom = CrashAnalyzer.Analyze("Description: The game crashed. java.lang.OutOfMemoryError: Java heap space");
        Check("OutOfMemoryError", oom.ExceptionType.Contains("内存不足"));

        var uvc = CrashAnalyzer.Analyze("java.lang.UnsupportedClassVersionError: class file version 65.0");
        Check("UnsupportedClassVersion 识别", uvc.ExceptionType.Contains("Java 版本不匹配"));
        Check("推算需要 Java 21", uvc.Summary.Contains("Java 21"));

        var cnf = CrashAnalyzer.Analyze("java.lang.ClassNotFoundException: com.example.mymod.Mod");
        Check("ClassNotFoundException", cnf.ExceptionType.Contains("类未找到"));

        var gl = CrashAnalyzer.Analyze("OpenGL error: Could not create context");
        Check("OpenGL 错误", gl.ExceptionType.Contains("OpenGL"));
    }

    private static void OfflineAuth()
    {
        Console.WriteLine("[离线认证 UUID]");
        var uuid = OfflineAuthenticator.GenerateOfflineUuid("Notch");
        Check("UUID 长度 36", uuid.Length == 36);
        Check("UUID 含连字符", uuid.Contains('-'));
        Check("同名稳定", OfflineAuthenticator.GenerateOfflineUuid("Notch") == uuid);
    }

    private static async Task VersionMerge()
    {
        Console.WriteLine("[版本合并（Fabric 继承原版）]");
        var root = Path.Combine(Path.GetTempPath(), "mclcs_merge_" + Guid.NewGuid().ToString("N"));
        try
        {
            var vanillaDir = Path.Combine(root, "versions", "1.20.1");
            Directory.CreateDirectory(vanillaDir);
            var vanilla = new VersionJson
            {
                Id = "1.20.1",
                MainClass = "net.minecraft.client.main.Main",
                Libraries = new List<Library> { new() { Name = "com.mojang:patchy:1.0" } },
                Arguments = new Arguments
                {
                    Game = new List<ArgumentItem> { new() { Values = new() { "--username", "${auth_player_name}" } } }
                }
            };
            await File.WriteAllTextAsync(Path.Combine(vanillaDir, "1.20.1.json"),
                JsonSerializer.Serialize(vanilla, new JsonSerializerOptions { WriteIndented = true }));

            var fabricDir = Path.Combine(root, "versions", "fabric-1.20.1");
            Directory.CreateDirectory(fabricDir);
            var fabric = new VersionJson
            {
                Id = "fabric-1.20.1",
                InheritsFrom = "1.20.1",
                MainClass = "net.fabricmc.loader.impl.launcher.Main",
                Libraries = new List<Library> { new() { Name = "net.fabricmc:fabric-loader:0.15.0" } },
                Arguments = new Arguments
                {
                    Game = new List<ArgumentItem> { new() { Values = new() { "--fabric" } } }
                }
            };
            await File.WriteAllTextAsync(Path.Combine(fabricDir, "fabric-1.20.1.json"),
                JsonSerializer.Serialize(fabric, new JsonSerializerOptions { WriteIndented = true }));

            var merged = VersionMerger.Merge(root, "fabric-1.20.1");
            Check("mainClass 取自子版本(Fabric)", merged.MainClass == "net.fabricmc.loader.impl.launcher.Main");
            Check("库合并含原版库", merged.Libraries.Any(l => l.Name == "com.mojang:patchy:1.0"));
            Check("库合并含 Fabric 库", merged.Libraries.Any(l => l.Name == "net.fabricmc:fabric-loader:0.15.0"));
            Check("game 参数合并含原版", merged.Arguments!.Game.Any(i => i.Values.Contains("--username")));
            Check("game 参数合并含 Fabric", merged.Arguments!.Game.Any(i => i.Values.Contains("--fabric")));
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }
        await Task.CompletedTask;
    }

    // ---- v0.2 新增测试 ----

    private static void AccountStoreTest()
    {
        Console.WriteLine("[账号存储 CRUD]");
        var tmp = Path.Combine(Path.GetTempPath(), "mclcs_acctest_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(tmp);
            var list = AccountStore.Load(tmp);
            Check("新目录返回空列表", list.Count == 0);

            var a = new AccountEntry
            {
                Id = "test1",
                DisplayName = "离线玩家",
                AuthType = "offline",
                Username = "Player"
            };
            AccountStore.Upsert(tmp, a);

            var loaded = AccountStore.Load(tmp);
            Check("保存后加载 1 条", loaded.Count == 1);
            Check("条目属性正确", loaded[0].Id == "test1" && loaded[0].AuthType == "offline");
            Check("自动设置 lastUsed", !string.IsNullOrEmpty(loaded[0].LastUsed));

            var lu = AccountStore.GetLastUsed(tmp);
            Check("GetLastUsed 返回正确", lu is not null && lu.Id == "test1");

            AccountStore.Remove(tmp, "test1");
            Check("删除后为空", AccountStore.Load(tmp).Count == 0);
        }
        finally
        {
            if (Directory.Exists(tmp)) Directory.Delete(tmp, true);
        }
    }

    private static void LaunchOptionsAndAuthVars()
    {
        Console.WriteLine("[LaunchOptions 扩展字段]");
        var options = new LaunchOptions
        {
            UserType = "msa",
            UserProperties = "{\"prop\":\"value\"}",
            ExtraJvmArgs = new List<string> { "-XX:+UseZGC" }
        };
        Check("UserType msa", options.UserType == "msa");
        Check("UserProperties 非空", options.UserProperties != "{}");
        Check("ExtraJvmArgs 有值", options.ExtraJvmArgs.Count == 1);
    }

    private static void RepairEngineTest()
    {
        Console.WriteLine("[崩溃修复规划引擎]");
        var gameRoot = Path.Combine(Path.GetTempPath(), "mclcs_repair_" + Guid.NewGuid().ToString("N"));

        // 内存不足，当前 2048MB -> 应调大到 4096MB
        var oom = new CrashAnalysis { Category = CrashCategory.OutOfMemory };
        var planOom = CrashRepairEngine.BuildPlan(oom, new LauncherProfile { MaxMemoryMb = 2048 }, null, gameRoot, "1.20.1");
        Check("OOM 可自动修复", planOom.CanRepair);
        Check("OOM 策略=调大内存", planOom.Strategy == RepairStrategy.IncreaseMemory);
        Check("OOM 目标内存=4096", planOom.TargetMemoryMb == 4096);
        Check("OOM 非破坏性", planOom.NonDestructive);

        // 内存已到上限 -> 不可再调
        var oomMax = new CrashAnalysis { Category = CrashCategory.OutOfMemory };
        var planMax = CrashRepairEngine.BuildPlan(oomMax, new LauncherProfile { MaxMemoryMb = GameConstants.MaxRepairMemoryMb }, null, gameRoot, "1.20.1");
        Check("OOM 达上限不可修复", !planMax.CanRepair);

        // Java 版本不匹配，需要 Java 21
        var java = new CrashAnalysis { Category = CrashCategory.JavaVersion, RequiredJavaMajor = 21 };
        var planJava = CrashRepairEngine.BuildPlan(java, new LauncherProfile(), null, gameRoot, "1.20.1");
        Check("Java 版本可自动修复", planJava.CanRepair);
        Check("Java 策略=切换Java", planJava.Strategy == RepairStrategy.SwitchJava);
        Check("Java 需要 21", planJava.RequiredJavaMajor == 21);

        // 缺少库，给定版本 -> 重新下载
        var miss = new CrashAnalysis { Category = CrashCategory.MissingLibrary };
        var planMiss = CrashRepairEngine.BuildPlan(miss, new LauncherProfile(), null, gameRoot, "1.20.1");
        Check("缺失库可自动修复", planMiss.CanRepair);
        Check("缺失库策略=重下库", planMiss.Strategy == RepairStrategy.RedownloadLibraries);
        Check("缺失库版本正确", planMiss.VersionId == "1.20.1");

        // 缺失库但无版本 -> 不可修复
        var missNoVer = new CrashAnalysis { Category = CrashCategory.MissingLibrary };
        Check("缺失库无版本不可修复", !CrashRepairEngine.BuildPlan(missNoVer, new LauncherProfile(), null, gameRoot, null).CanRepair);

        // OpenGL / 未知 -> 不可自动修复
        var gl = new CrashAnalysis { Category = CrashCategory.OpenGL };
        Check("OpenGL 不可自动修复", !CrashRepairEngine.BuildPlan(gl, new LauncherProfile(), null, gameRoot, "1.20.1").CanRepair);
        var unk = new CrashAnalysis { Category = CrashCategory.Unknown };
        Check("Unknown 不可自动修复", !CrashRepairEngine.BuildPlan(unk, new LauncherProfile(), null, gameRoot, "1.20.1").CanRepair);

        // 分析器：从类版本反推所需 Java
        var uvc = CrashAnalyzer.Analyze("java.lang.UnsupportedClassVersionError: class file version 65.0");
        Check("类版本 65 -> 需要 Java 21", uvc.RequiredJavaMajor == 21);
        Check("RawReport 可赋值", (uvc.RawReport = "x") == "x");

        // 策略枚举默认值
        Check("RepairPolicy 默认 Ask", new LauncherProfile().RepairPolicy == CrashRepairPolicy.Ask);
    }

    private static void ModpackIndexParsing()
    {
        Console.WriteLine("[整合包索引解析]");
        var json = @"{
            ""formatVersion"": 1,
            ""game"": ""minecraft"",
            ""versionId"": ""1.20.1"",
            ""name"": ""Test Pack"",
            ""dependencies"": { ""minecraft"": ""1.20.1"", ""fabric-loader"": ""0.15.0"" },
            ""files"": [
                {
                    ""path"": ""mods/sodium.jar"",
                    ""env"": { ""client"": ""required"", ""server"": ""unsupported"" },
                    ""hashes"": { ""sha1"": ""abc123"", ""sha512"": ""def456"" },
                    ""downloads"": [""https://example.com/sodium.jar""],
                    ""fileSize"": 123456
                }
            ]
        }";
        var index = JsonSerializer.Deserialize<ModrinthPackIndex>(json);
        Check("formatVersion 1", index is not null && index.FormatVersion == 1);
        Check("name Test Pack", index!.Name == "Test Pack");
        Check("dependencies 含 fabric-loader", index.Dependencies.ContainsKey("fabric-loader"));
        Check("1 个 file", index.Files.Count == 1);
        Check("file client=required", index.Files[0].Env.Client == "required");
        Check("downloads URL", index.Files[0].Downloads[0] == "https://example.com/sodium.jar");
    }

    private static void ModrinthModelDeserialization()
    {
        Console.WriteLine("[Modrinth 模型反序列化]");
        var projJson = @"{""id"":""abc"",""slug"":""sodium"",""title"":""Sodium"",""description"":""Fast"",""body"":""..."",""project_type"":""mod"",""game_versions"":[""1.20.1""],""loaders"":[""fabric""],""downloads"":999,""icon_url"":""https://icon.png"",""gallery"":[]}";
        var proj = JsonSerializer.Deserialize<ModrinthProject>(projJson);
        Check("ModrinthProject title", proj is not null && proj.Title == "Sodium");

        var depJson = @"[{""version_id"":null,""project_id"":""fabric-api"",""file_name"":null,""dependency_type"":""required""}]";
        var deps = JsonSerializer.Deserialize<List<ModrinthDependency>>(depJson);
        Check("dependency type=required", deps is not null && deps[0].DependencyType == "required");

        // LoaderType.NeoForge
        Check("NeoForge loader string", ModrinthClient.LoaderString(LoaderType.NeoForge) == "neoforge");
    }

    // ---- v0.3 新增测试 ----

    private static void CurseForgeModels()
    {
        Console.WriteLine("[CurseForge 模型反序列化]");
        var manifestJson = @"{
            ""minecraft"": { ""version"": ""1.20.1"", ""modLoaders"": [{""id"":""fabric-0.15.0"",""primary"":true}] },
            ""manifestType"": ""minecraftModpack"",
            ""manifestVersion"": 1,
            ""name"": ""Test CF Pack"",
            ""version"": ""1.0"",
            ""author"": ""Author"",
            ""files"": [{""projectID"":123,""fileID"":456,""required"":true}],
            ""overrides"": ""overrides""
        }";
        var manifest = JsonSerializer.Deserialize<CurseForgeManifest>(manifestJson);
        Check("CF manifest name", manifest is not null && manifest.Name == "Test CF Pack");
        Check("CF mc version", manifest!.Minecraft.Version == "1.20.1");
        Check("CF fabric loader", manifest.Minecraft.ModLoaders[0].Id == "fabric-0.15.0");
        Check("CF 1 file", manifest.Files.Count == 1);
        Check("CF file projectID", manifest.Files[0].ProjectId == 123);
    }

    private static void LocalizationTest()
    {
        Console.WriteLine("[多语言管理]");
        Check("默认 zh_CN", LocaleManager.CurrentLocale == "zh_CN");
        Check("T(app.title) zh", LocaleManager.T("app.title") == "MCLCS 启动器");

        LocaleManager.CurrentLocale = "en_US";
        Check("T(app.title) en", LocaleManager.T("app.title") == "MCLCS Launcher");
        Check("T(不存在) fallback", LocaleManager.T("nonexistent_key") == "nonexistent_key");

        LocaleManager.CurrentLocale = "zh_CN"; // 恢复
        Check("Tf 格式化", LocaleManager.Tf("msg.launching", "1.20.1").Contains("1.20.1"));
    }

    private static void SkinFetcherTest()
    {
        Console.WriteLine("[皮肤解析]");
        // 模拟 textures Base64
        var texturesJson = @"{""textures"":{""SKIN"":{""url"":""https://example.com/skin.png"",""metadata"":{""model"":""slim""}},""CAPE"":{""url"":""https://example.com/cape.png""}}}";
        var b64 = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(texturesJson));
        var profile = new MinecraftProfile
        {
            Id = "abc",
            Name = "TestPlayer",
            Properties = new List<ProfileProperty> { new() { Name = "textures", Value = b64 } }
        };
        // 使用反射调用私有方法测试（这里只测模型绑定）
        Check("Profile name", profile.Name == "TestPlayer");
        Check("Profile has textures", profile.Properties.Any(p => p.Name == "textures"));
    }

    private static void ThemeManagerTest()
    {
        Console.WriteLine("[主题管理]");
        var initial = ThemeManager.Current;
        Check("默认暗色", initial == ThemeType.Dark);

        ThemeManager.Current = ThemeType.Light;
        Check("切换亮色", ThemeManager.Current == ThemeType.Light);

        ThemeManager.Current = ThemeType.Dark;
        Check("切回暗色", ThemeManager.Current == ThemeType.Dark);
    }

    private static void ModMetadataParserTest()
    {
        Console.WriteLine("[Mod 元数据解析]");

        // 测试 TOML 解析
        var toml = @"
[[mods]]
modId=""examplemod""
displayName=""Example Mod""
version=""1.0.0""

[[dependencies.examplemod]]
modId=""fabric-api""
mandatory=true
versionRange=""[0.92,1.0)""
ordering=""NONE""
side=""BOTH""
";
        var meta = ModMetadataParser.ParseForgeMod("nonexistent.jar"); // 文件不存在返回 null
        Check("不存在的jar返回null", meta is null);

        // 测试 DependencyCheckResult 模型
        var result = new DependencyCheckResult
        {
            ModFileName = "test.jar",
            ModId = "testmod",
            ModName = "Test Mod",
            Missing = { new MissingDependency { DependencyId = "dep1", VersionRange = ">=1.0", Required = true } }
        };
        Check("依赖检查 Missing 1", result.Missing.Count == 1);
        Check("依赖检查 dep1", result.Missing[0].DependencyId == "dep1");
    }

    // ---- v0.5 新增测试 ----

    private static void RecommendationSystemTest()
    {
        Console.WriteLine("[智能推荐系统 v0.5]");

        // 玩法分区映射
        Check("technology → Tech", GameplayCategoryMap.FromModrinthCategories(new[] { "technology" }) == GameplayCategory.Tech);
        Check("magic → Magic", GameplayCategoryMap.FromModrinthCategories(new[] { "magic" }) == GameplayCategory.Magic);
        Check("未识别 → null", GameplayCategoryMap.FromModrinthCategories(new[] { "xyz" }) is null);
        Check("Tech 展示名=生电", GameplayCategoryMap.DisplayName(GameplayCategory.Tech) == "生电");
        Check("All 含 6 个分区", GameplayCategoryMap.All.Count == 6);
        Check("ToModrinth Tech=technology", GameplayCategoryMap.ToModrinthCategory(GameplayCategory.Tech) == "technology");

        // 规则引擎：Fabric 已装但无 API + 存在光影包但无 Iris
        var root = Path.Combine(Path.GetTempPath(), "mclcs_rec_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(root);
            var sp = PathEx.ShaderPacksDir(root);
            Directory.CreateDirectory(sp);
            File.WriteAllText(Path.Combine(sp, "test.zip"), "dummy");

            var installed = new List<ModEntry>
            {
                new() { ModId = "sodium", Loader = "fabric", FileName = "sodium.jar" }
            };
            var rules = RuleEngine.EvaluateLocalRules(root, installed);
            Check("规则推荐 Fabric API", rules.Any(r => r.Slug == "fabric-api" && r.IsDependencyCompletion));
            Check("规则推荐 Iris", rules.Any(r => r.Slug == "iris" && r.IsDependencyCompletion));

            // 已装 Fabric API + Iris → 不再推荐
            var installed2 = new List<ModEntry>
            {
                new() { ModId = "fabric-api", Loader = "fabric", FileName = "fabric-api.jar" },
                new() { ModId = "iris", Loader = "fabric", FileName = "iris.jar" }
            };
            var rules2 = RuleEngine.EvaluateLocalRules(root, installed2);
            Check("已装 API+Ir is 时无推荐", rules2.Count == 0);
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }

        // 推荐引擎：Disabled → 空；LocalOnly + 玩法偏好过滤
        var profileDisabled = new LauncherProfile { IntelliRecommend = IntelliRecommendMode.Disabled };
        var empty = RecommendationEngine.BuildAsync(GameConstants.DefaultGameRoot, profileDisabled,
            new HttpClient(), null).GetAwaiter().GetResult();
        Check("Disabled 返回空", empty.Count == 0);

        var profileLocal = new LauncherProfile
        {
            IntelliRecommend = IntelliRecommendMode.LocalOnly,
            PreferredCategories = new() { GameplayCategory.Tech } // 只关心生电
        };
        // LocalOnly 不联网，仅本地规则；用含 Fabric 的假环境
        var root2 = Path.Combine(Path.GetTempPath(), "mclcs_rec2_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(root2);
            var localItems = RuleEngine.EvaluateLocalRules(root2, new List<ModEntry> { new() { ModId = "x", Loader = "fabric" } });
            // 依赖补全类（fabric-api → Tech）应保留；若偏好只选 Tech 则 iris(Optimization) 被过滤——但规则引擎不过滤，过滤在引擎
            Check("本地规则含 fabric-api", localItems.Any(i => i.Slug == "fabric-api"));
        }
        finally
        {
            if (Directory.Exists(root2)) Directory.Delete(root2, true);
        }

        // 热门榜单缓存：写入缓存后可命中（不联网）
        var root3 = Path.Combine(Path.GetTempPath(), "mclcs_rec3_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(root3);
            var cached = new List<RecommendationItem>
            {
                new() { Slug = "sodium", Title = "Sodium", Category = GameplayCategory.Optimization }
            };
            // 直接写缓存（通过反射私有方法不便，这里用公开路径约定复刻）
            var cacheDir = Path.Combine(root3, "cache");
            Directory.CreateDirectory(cacheDir);
            var payload = new { CachedAt = DateTime.UtcNow, Items = cached };
            File.WriteAllText(Path.Combine(cacheDir, "mclcs_hot_any_Any_all.json"),
                System.Text.Json.JsonSerializer.Serialize(payload));

            var hot = HotRanking.GetHotAsync(new HttpClient(), root3, null, LoaderType.Any, null, ct: CancellationToken.None)
                .GetAwaiter().GetResult();
            Check("榜单命中本地缓存", hot.Count == 1 && hot[0].Slug == "sodium");
        }
        finally
        {
            if (Directory.Exists(root3)) Directory.Delete(root3, true);
        }
    }

    /// <summary>无网络下载器（仅用于离线测试）。</summary>
    private class NoopDownloader : IDownloader
    {
        public Task DownloadAsync(DownloadItem item, IProgress<double>? progress = null, CancellationToken ct = default)
            => Task.CompletedTask;
        public Task DownloadBatchAsync(IEnumerable<DownloadItem> items, IProgress<(int Done, int Total)>? progress = null, CancellationToken ct = default)
            => Task.CompletedTask;
    }

    private static async Task LibraryRepairTest()
    {
        Console.WriteLine("[库修复 LibraryRepair]");
        var root = Path.Combine(Path.GetTempPath(), "mclcs_librepair_" + Guid.NewGuid().ToString("N"));
        var downloader = new NoopDownloader();
        try
        {
            var vdir = Path.Combine(root, "versions", "1.20.1");
            Directory.CreateDirectory(vdir);
            var version = new VersionJson { Id = "1.20.1", Libraries = new() };
            await File.WriteAllTextAsync(Path.Combine(vdir, "1.20.1.json"),
                JsonSerializer.Serialize(version));

            // 无库版本：无需下载，所有库健康（FixedCount=0）
            var ok = await LibraryRepair.RepairAsync(root, "1.20.1", new HttpClient(), downloader, null);
            Check("无库版本 AllHealthy", ok.AllHealthy);
            Check("无库版本 FixedCount=0", ok.FixedCount == 0);

            // 不存在的版本：返回失败
            var fail = await LibraryRepair.RepairAsync(root, "9.9.9", new HttpClient(), downloader, null);
            Check("不存在版本 Success=false", !fail.Success);
            Check("不存在版本 AllHealthy=false", !fail.AllHealthy);
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }
        await Task.CompletedTask;
    }

    private static void CrashRepairModelsV05Test()
    {
        Console.WriteLine("[崩溃修复模型 v0.5]");

        // ModConflictInfo
        var conflict = new ModConflictInfo
        {
            FilePath = "/mods/sodium.jar",
            Name = "Sodium"
        };
        Check("ModConflictInfo FilePath", conflict.FilePath == "/mods/sodium.jar");
        Check("ModConflictInfo Name", conflict.Name == "Sodium");

        // RepairStrategy 新枚举值
        Check("DisableConflictingMods 枚举值", RepairStrategy.DisableConflictingMods.ToString() == "DisableConflictingMods");
        Check("InstallMissingModDependency 枚举值", RepairStrategy.InstallMissingModDependency.ToString() == "InstallMissingModDependency");

        // CrashRepairPlan 新字段
        var plan = new CrashRepairPlan();
        Check("ConflictingMods 初始为空", plan.ConflictingMods.Count == 0);
        Check("MissingModDependencies 初始为空", plan.MissingModDependencies.Count == 0);
        Check("KeepModFile 初始为 null", plan.KeepModFile is null);

        plan.ConflictingMods.Add(new ModConflictInfo { FilePath = "/mods/a.jar", Name = "A" });
        plan.ConflictingMods.Add(new ModConflictInfo { FilePath = "/mods/b.jar", Name = "B" });
        Check("ConflictingMods 添加后 2 个", plan.ConflictingMods.Count == 2);

        plan.MissingModDependencies.Add("fabric-api");
        plan.MissingModDependencies.Add("cloth-config");
        Check("MissingModDependencies 添加后 2 个", plan.MissingModDependencies.Count == 2);
        Check("MissingModDependencies 含 fabric-api", plan.MissingModDependencies.Contains("fabric-api"));
    }

    private static void JavaVendorTest()
    {
        Console.WriteLine("[JavaVendor 枚举 & Oracle 安装模型]");

        // 枚举值
        Check("JavaVendor.Auto", JavaVendor.Auto.ToString() == "Auto");
        Check("JavaVendor.Temurin", JavaVendor.Temurin.ToString() == "Temurin");
        Check("JavaVendor.Oracle", JavaVendor.Oracle.ToString() == "Oracle");

        // 默认值
        var profile = new LauncherProfile();
        Check("Profile 默认 PreferredJavaVendor = Auto", profile.PreferredJavaVendor == JavaVendor.Auto);

        // JavaInstaller 静态方法存在
        var ensureMethod = typeof(JavaInstaller).GetMethod("EnsureJavaAsync",
            new[] { typeof(int), typeof(string), typeof(IDownloader), typeof(JavaVendor), typeof(ILogger), typeof(CancellationToken) });
        Check("JavaInstaller.EnsureJavaAsync(JavaVendor) 方法存在", ensureMethod is not null);

        // Oracle 方法存在（public static）
        var oracleMethod = typeof(JavaInstaller).GetMethod("InstallOracleAsync",
            System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
        Check("JavaInstaller.InstallOracleAsync 方法存在", oracleMethod is not null);
    }

    private static void AutoInstallPolicyTest()
    {
        Console.WriteLine("[AutoInstallPolicy 枚举]");

        Check("AutoInstallPolicy.Always", AutoInstallPolicy.Always.ToString() == "Always");
        Check("AutoInstallPolicy.Ask", AutoInstallPolicy.Ask.ToString() == "Ask");
        Check("AutoInstallPolicy.Never", AutoInstallPolicy.Never.ToString() == "Never");

        var profile = new LauncherProfile();
        Check("Profile 默认 AutoInstallMissingMods = Ask", profile.AutoInstallMissingMods == AutoInstallPolicy.Ask);
    }

    private static void ModConflictPlanTest()
    {
        Console.WriteLine("[Mod 冲突修复规划]");

        var gameRoot = Path.Combine(Path.GetTempPath(), "mclcs_conflict_" + Guid.NewGuid().ToString("N"));
        try
        {
            // 创建一个无 mods 目录的环境，测试非 OOM/非 Java 的崩溃也能产出 plan
            Directory.CreateDirectory(gameRoot);
            var modsDir = Path.Combine(gameRoot, "mods");
            Directory.CreateDirectory(modsDir);

            // 非 OOM/Java 的崩溃（如 ClassNotFoundException），应尝试检测 mod 问题
            var cnf = new CrashAnalysis { Category = CrashCategory.MissingLibrary };
            var plan = CrashRepairEngine.BuildPlan(cnf, new LauncherProfile(), null, gameRoot, "1.20.1");

            // 在没有 mod 冲突/缺失依赖的情况下，不应产出冲突或缺失计划
            Check("无冲突时 ConflictingMods 为空", plan.ConflictingMods.Count == 0);
            Check("无缺失时 MissingModDependencies 为空", plan.MissingModDependencies.Count == 0);
        }
        finally
        {
            if (Directory.Exists(gameRoot)) Directory.Delete(gameRoot, true);
        }
    }

    private static void ProfileV05Test()
    {
        Console.WriteLine("[LauncherProfile v0.5 序列化]");

        var profile = new LauncherProfile
        {
            PreferredJavaVendor = JavaVendor.Oracle,
            AutoInstallMissingMods = AutoInstallPolicy.Always
        };

        var json = JsonSerializer.Serialize(profile);
        Check("序列化含 preferredJavaVendor", json.Contains("preferredJavaVendor"));
        Check("序列化含 autoInstallMissingMods", json.Contains("autoInstallMissingMods"));

        var deserialized = JsonSerializer.Deserialize<LauncherProfile>(json);
        Check("反序列化 PreferredJavaVendor = Oracle", deserialized?.PreferredJavaVendor == JavaVendor.Oracle);
        Check("反序列化 AutoInstallMissingMods = Always", deserialized?.AutoInstallMissingMods == AutoInstallPolicy.Always);
    }
}
