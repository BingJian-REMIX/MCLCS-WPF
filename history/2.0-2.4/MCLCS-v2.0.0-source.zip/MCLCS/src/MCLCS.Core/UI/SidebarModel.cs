using System.Text.Json.Serialization;

namespace MCLCS.Core.UI;

/// <summary>侧边栏导航项。</summary>
public sealed class SidebarItem
{
    public SidebarItem(string id, string title, string icon, int order, bool bottom = false)
    {
        Id = id;
        Title = title;
        Icon = icon;
        Order = order;
        Bottom = bottom;
    }

    public string Id { get; }
    public string Title { get; }
    public string Icon { get; }
    public int Order { get; }

    /// <summary>是否固定在侧边栏底部（设置 / 关于）。</summary>
    public bool Bottom { get; }

    /// <summary>徽标数字，0 表示不显示；-1 表示仅显示红点。</summary>
    public int Badge { get; set; }

    public bool HasBadge => Badge != 0;
    public string BadgeText => Badge < 0 ? "" : (Badge > 99 ? "99+" : Badge.ToString());
}

/// <summary>
/// 全局侧边栏状态机：默认折叠（仅图标），鼠标悬停延迟后展开；可"钉住"保持展开。
/// 纯逻辑，界面层只负责把鼠标事件与计时器转成 <see cref="HoverEnter"/> / <see cref="HoverLeave"/> 调用。
/// </summary>
public class SidebarState
{
    /// <summary>折叠宽度（px）。</summary>
    public const double CollapsedWidth = 48;

    /// <summary>展开宽度（px）。</summary>
    public const double ExpandedWidth = 200;

    /// <summary>悬停多久后展开（毫秒）。</summary>
    public const int HoverExpandDelayMs = 150;

    /// <summary>移出多久后收起（毫秒）。</summary>
    public const int HoverCollapseDelayMs = 300;

    /// <summary>是否被钉住（钉住时始终展开，不响应悬停）。</summary>
    public bool Pinned { get; private set; }

    /// <summary>当前是否展开。</summary>
    public bool Expanded { get; private set; }

    /// <summary>鼠标是否在侧边栏范围内。</summary>
    public bool Hovering { get; private set; }

    /// <summary>当前应用的宽度。</summary>
    public double Width => Expanded || Pinned ? ExpandedWidth : CollapsedWidth;

    /// <summary>当前选中项 Id。</summary>
    public string? SelectedId { get; private set; }

    /// <summary>鼠标进入：延迟由界面层负责，回调到此方法时即展开。</summary>
    public void HoverEnter()
    {
        Hovering = true;
        if (!Pinned) Expanded = true;
    }

    /// <summary>鼠标离开：钉住时保持展开。</summary>
    public void HoverLeave()
    {
        Hovering = false;
        if (!Pinned) Expanded = false;
    }

    /// <summary>切换钉住状态；钉住时立即展开，取消钉住后按当前悬停状态决定。</summary>
    public bool TogglePin()
    {
        Pinned = !Pinned;
        Expanded = Pinned || Hovering;
        return Pinned;
    }

    public void Select(string? id) => SelectedId = id;

    /// <summary>从配置恢复（钉住状态持久化）。</summary>
    public void Restore(SidebarConfig cfg)
    {
        Pinned = cfg.Pinned;
        Expanded = cfg.Pinned;
        SelectedId = string.IsNullOrWhiteSpace(cfg.LastSelectedId) ? Sidebar.Items[0].Id : cfg.LastSelectedId;
    }

    /// <summary>写回配置。</summary>
    public SidebarConfig Capture() => new() { Pinned = Pinned, LastSelectedId = SelectedId };
}

/// <summary>侧边栏持久化配置。</summary>
public class SidebarConfig
{
    [JsonPropertyName("pinned")]
    public bool Pinned { get; set; }

    [JsonPropertyName("lastSelectedId")]
    public string? LastSelectedId { get; set; }

    /// <summary>是否启用悬停展开（关闭后只能通过钉住按钮展开）。</summary>
    [JsonPropertyName("hoverExpand")]
    public bool HoverExpand { get; set; } = true;
}

/// <summary>侧边栏项注册表。</summary>
public static class Sidebar
{
    public static IReadOnlyList<SidebarItem> Items { get; } = new List<SidebarItem>
    {
        new("home",     "主页",   "home",     0),
        new("game",     "游戏",   "gamepad",  1),
        new("download", "下载",   "download", 2),
        new("toolbox",  "工具箱", "toolbox",  3),
        new("account",  "账号",   "user",     4),
        new("settings", "设置",   "cog",      5, bottom: true),
        new("about",    "关于",   "info",     6, bottom: true)
    };

    public static IEnumerable<SidebarItem> Top => Items.Where(i => !i.Bottom).OrderBy(i => i.Order);
    public static IEnumerable<SidebarItem> Bottom => Items.Where(i => i.Bottom).OrderBy(i => i.Order);

    public static SidebarItem? ById(string? id) =>
        string.IsNullOrWhiteSpace(id) ? null : Items.FirstOrDefault(i => i.Id == id);

    /// <summary>侧边栏项与主标签的映射（前四项一一对应）。</summary>
    public static MainTabKind? ToMainTab(string? id) => id switch
    {
        "home" => MainTabKind.Home,
        "game" => MainTabKind.Game,
        "download" => MainTabKind.Download,
        "toolbox" => MainTabKind.Toolbox,
        _ => null
    };
}
