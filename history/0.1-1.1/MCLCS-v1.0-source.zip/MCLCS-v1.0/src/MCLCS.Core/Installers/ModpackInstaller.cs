using System.Text.Json;
using MCLCS.Core.Download;
using MCLCS.Core.Models;
using MCLCS.Core.Utils;

namespace MCLCS.Core.Installers;

/// <summary>
/// Modrinth 整合包安装器（.mrpack 格式）。
/// 流程：解压 → 读 modrinth.index.json → 安装 MC + loader → 并行下载文件 → 复制 overrides。
/// </summary>
public class ModpackInstaller
{
    private readonly string _gameRoot;
    private readonly HttpClient _client;
    private readonly IDownloader _downloader;
    private readonly ILogger? _logger;

    public ModpackInstaller(string gameRoot, HttpClient client, IDownloader downloader, ILogger? logger = null)
    {
        _gameRoot = gameRoot;
        _client = client;
        _downloader = downloader;
        _logger = logger;
    }

    /// <summary>安装 .mrpack 整合包。</summary>
    public async Task InstallAsync(string mrpackPath,
        IProgress<(int Done, int Total)>? progress = null,
        CancellationToken ct = default)
    {
        if (!File.Exists(mrpackPath))
            throw new FileNotFoundException("整合包文件不存在", mrpackPath);

        var tempDir = Path.Combine(Path.GetTempPath(), "mclcs_mrpack_" + Guid.NewGuid().ToString("N"));
        try
        {
            // 1. 解压 .mrpack（本质是 ZIP）
            _logger?.Log("解压整合包 ...");
            Unzip.ExtractToDirectory(mrpackPath, tempDir);
            var indexJson = Path.Combine(tempDir, "modrinth.index.json");
            if (!File.Exists(indexJson))
                throw new InvalidDataException("整合包缺少 modrinth.index.json");

            var index = JsonSerializer.Deserialize<ModrinthPackIndex>(await File.ReadAllTextAsync(indexJson, ct))
                        ?? throw new InvalidDataException("无法解析 modrinth.index.json");

            _logger?.Log($"整合包: {index.Name} (MC {index.VersionId}, format {index.FormatVersion})");

            // 2. 安装原版 + loader
            await InstallGameAndLoader(index, progress, ct);

            // 3. 下载 files（Mod）
            await DownloadPackFiles(index, progress, ct);

            // 4. 复制 overrides 到游戏目录
            CopyOverrides(tempDir);

            _logger?.Log($"整合包 {index.Name} 安装完成");
        }
        finally
        {
            if (Directory.Exists(tempDir)) Directory.Delete(tempDir, true);
        }
    }

    private async Task InstallGameAndLoader(ModrinthPackIndex index,
        IProgress<(int Done, int Total)>? progress,
        CancellationToken ct)
    {
        // 安装原版
        _logger?.Log($"安装原版 Minecraft {index.VersionId} ...");
        var vanilla = new VanillaInstaller(_gameRoot, _client, _downloader, _logger);
        await vanilla.InstallAsync(index.VersionId, progress, ct);

        // 按 dependencies 安装 loader
        foreach (var (loader, version) in index.Dependencies)
        {
            if (loader == "minecraft") continue;

            _logger?.Log($"安装 loader: {loader} {version}");
            switch (loader)
            {
                case "fabric-loader":
                    await new FabricInstaller(_gameRoot, _client, _downloader, _logger)
                        .InstallAsync(index.VersionId, progress, ct);
                    break;
                case "forge":
                    await new ForgeInstaller(_gameRoot, _client, _downloader, _logger)
                        .InstallAsync(index.VersionId, progress, ct);
                    break;
                case "quilt-loader":
                    _logger?.Log("Quilt loader 暂未实现，跳过");
                    break;
                case "neoforge":
                    _logger?.Log("NeoForge 暂未实现，跳过");
                    break;
                default:
                    _logger?.Log($"未知 loader: {loader}，跳过");
                    break;
            }
        }
    }

    private async Task DownloadPackFiles(ModrinthPackIndex index,
        IProgress<(int Done, int Total)>? progress,
        CancellationToken ct)
    {
        var clientFiles = index.Files
            .Where(f => f.Env.Client is "required" or "optional")
            .ToList();

        if (clientFiles.Count == 0) return;

        var modsDir = PathEx.ModsDir(_gameRoot);
        Directory.CreateDirectory(modsDir);

        var items = clientFiles.Select(f =>
        {
            var dest = Path.Combine(modsDir, Path.GetFileName(f.Path));
            return new DownloadItem(f.Downloads, dest, f.Hashes.Sha1, f.FileSize);
        }).ToList();

        _logger?.Log($"下载 {items.Count} 个 Mod ...");
        await _downloader.DownloadBatchAsync(items, progress, ct);
    }

    private void CopyOverrides(string tempDir)
    {
        var overridesDir = Path.Combine(tempDir, "overrides");
        if (!Directory.Exists(overridesDir)) return;

        _logger?.Log("复制 overrides ...");
        foreach (var file in Directory.EnumerateFiles(overridesDir, "*", SearchOption.AllDirectories))
        {
            var relative = file[(overridesDir.Length + 1)..];
            var dest = Path.Combine(_gameRoot, relative);
            var destDir = Path.GetDirectoryName(dest);
            if (destDir is not null) Directory.CreateDirectory(destDir);
            File.Copy(file, dest, overwrite: true);
        }
    }
}
