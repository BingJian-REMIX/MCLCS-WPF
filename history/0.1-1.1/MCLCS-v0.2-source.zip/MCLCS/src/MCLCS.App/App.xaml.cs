using System.Windows;

namespace MCLCS.App;

public partial class App : Application
{
}
