using System.Runtime.InteropServices;
using MCLCS.Core.Download;
using MCLCS.Core.Utils;

namespace MCLCS.Core.Launcher;

/// <summary>
/// Java 自动安装：当系统无满足要求的 Java 时，下载并解压 Eclipse Temurin。
/// 默认解压到 {gameRoot}/runtime/jdk-{major}，避免依赖系统安装/管理员权限。
/// </summary>
public static class JavaInstaller
{
    /// <summary>确保存在满足 minMajor 的 Java；不存在则尝试安装。返回可用的 JavaInfo。</summary>
    public static async Task<JavaInfo?> EnsureJavaAsync(int minMajor,
        string gameRoot,
        IDownloader downloader,
        ILogger? logger = null,
        CancellationToken ct = default)
    {
        var existing = await JavaDetector.FindBestAsync(minMajor);
        if (existing is not null)
        {
            logger?.Log($"已找到可用 Java：{existing}");
            return existing;
        }

        logger?.Log($"未找到 Java ≥ {minMajor}，尝试自动安装 Eclipse Temurin ...");
        return await InstallTemurinAsync(minMajor, gameRoot, downloader, logger, ct);
    }

    public static async Task<JavaInfo?> InstallTemurinAsync(int major,
        string gameRoot,
        IDownloader downloader,
        ILogger? logger = null,
        CancellationToken ct = default)
    {
        var os = OperatingSystem.IsWindows() ? "windows" : (OperatingSystem.IsMacOS() ? "mac" : "linux");
        var arch = RuntimeInformation.OSArchitecture == Architecture.Arm64 ? "aarch64" : "x64";
        var url = $"{GameConstants.AdoptiumApiBase}/binary/latest/{major}/ga/{os}/{arch}/jdk/hotspot/normal/eclipse?archive_type=zip";

        var runtimeDir = Path.Combine(gameRoot, "runtime");
        Directory.CreateDirectory(runtimeDir);
        var zipPath = Path.Combine(runtimeDir, $"temurin-{major}.zip");

        logger?.Log($"下载 Temurin {major} 自 {url}");
        await downloader.DownloadAsync(new DownloadItem(new[] { url }, zipPath), null, ct);

        if (!HashUtil.IsZip(zipPath))
            throw new InvalidDataException("下载的 Java 安装包不是有效的 ZIP 文件");

        var extractDir = Path.Combine(runtimeDir, $"jdk-{major}");
        if (Directory.Exists(extractDir)) Directory.Delete(extractDir, true);
        Unzip.ExtractToDirectory(zipPath, extractDir);
        File.Delete(zipPath);

        // 顶层文件夹形如 jdk-21.0.x+xx，将其内容归一到 extractDir
        FlattenSingleTopFolder(extractDir);

        var javaExeName = OperatingSystem.IsWindows() ? "java.exe" : "java";
        var javaExe = Path.Combine(extractDir, "bin", javaExeName);
        if (!File.Exists(javaExe))
            throw new FileNotFoundException("解压后未找到 java 可执行文件", javaExe);

        var (majorVer, raw) = await JavaDetector.QueryVersionAsync(javaExe);
        logger?.Log($"Temurin 安装完成：{raw} @ {javaExe}");

        return new JavaInfo { JavaExe = javaExe, MajorVersion = majorVer, RawVersion = raw };
    }

    /// <summary>若解压后顶层只有一个子文件夹，将其下内容提升一层，统一目录结构。</summary>
    private static void FlattenSingleTopFolder(string dir)
    {
        var subs = Directory.GetFileSystemEntries(dir);
        if (subs.Length == 1 && Directory.Exists(subs[0]))
        {
            var inner = subs[0];
            foreach (var entry in Directory.GetFileSystemEntries(inner))
            {
                var name = Path.GetFileName(entry);
                var target = Path.Combine(dir, name);
                if (Directory.Exists(entry)) Directory.Move(entry, target);
                else File.Move(entry, target);
            }
            Directory.Delete(inner, true);
        }
    }
}
