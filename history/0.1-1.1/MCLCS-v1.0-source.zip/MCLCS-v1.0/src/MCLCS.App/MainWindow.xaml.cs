using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using MCLCS.Core.Profiles;
using MCLCS.Core.Utils;
using MCLCS.App.Views;

namespace MCLCS.App;

public partial class MainWindow : Window
{
    private readonly Dictionary<string, FrameworkElement> _pages = new();
    private string _currentKey = "";

    public MainWindow()
    {
        InitializeComponent();

        _pages["Home"] = new HomeView();
        _pages["Download"] = new DownloadPageView();
        _pages["Toolbox"] = new ToolboxView();
        _pages["Settings"] = new SettingsView();

        NavigateTo("Home");

        // 启动器运行日志实时反映到状态栏
        Services.LauncherService.Instance.Logged += line =>
        {
            if (!string.IsNullOrWhiteSpace(line))
                ViewModels.StatusBarViewModel.Current.LastLog = line;
        };

        // 关闭时刷新一次运行实例统计
        Closed += (_, _) => ViewModels.StatusBarViewModel.Current.RefreshAsync();
    }

    private void Nav_Click(object sender, RoutedEventArgs e)
    {
        var btn = (FrameworkElement)sender;
        var key = btn.Name switch
        {
            nameof(BtnHome) => "Home",
            nameof(BtnDownload) => "Download",
            nameof(BtnToolbox) => "Toolbox",
            nameof(BtnSettings) => "Settings",
            nameof(BtnAccount) => "Settings",
            _ => "Home"
        };
        NavigateTo(key);
    }

    private void NavigateTo(string key)
    {
        if (key == _currentKey) return;
        _pages.TryGetValue(key, out var page);
        if (page is null) return;

        PageHost.Content = page;
        _currentKey = key;

        // 高亮当前导航按钮
        foreach (var b in new[] { BtnHome, BtnDownload, BtnToolbox, BtnSettings })
            b.Foreground = (System.Windows.Media.Brush)FindResource("SecondaryForeground");

        var active = key switch
        {
            "Home" => BtnHome,
            "Download" => BtnDownload,
            "Toolbox" => BtnToolbox,
            _ => BtnSettings
        };
        active.Foreground = (System.Windows.Media.Brush)FindResource("AccentBrush");

        // 分页切换动画（受 AnimationsEnabled 控制）
        var profile = ProfileStore.Load(GameConstants.DefaultGameRoot);
        if (profile.AnimationsEnabled)
            PlayPageTransition();
    }

    private void PlayPageTransition()
    {
        var duration = TimeSpan.FromMilliseconds(220);
        var fade = new DoubleAnimation(0, 1, duration)
        {
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
        };
        var slide = new DoubleAnimation(18, 0, duration)
        {
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
        };
        PageBorder.BeginAnimation(UIElement.OpacityProperty, fade);
        PageTransform.BeginAnimation(TranslateTransform.YProperty, slide);
    }
}
