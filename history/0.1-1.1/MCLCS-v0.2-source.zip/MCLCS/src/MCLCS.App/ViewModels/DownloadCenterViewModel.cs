using System.Collections.ObjectModel;
using System.Windows.Input;
using MCLCS.Core.Download;
using MCLCS.Core.Models;
using MCLCS.Core.Mvvm;
using MCLCS.Core.Utils;
using MCLCS.App.Services;

namespace MCLCS.App.ViewModels;

public class SearchResultEntry
{
    public string ProjectId { get; init; } = "";
    public string Title { get; init; } = "";
    public string Summary { get; init; } = "";
}

public class DownloadCenterViewModel : ObservableObject
{
    private string _query = "";
    private string _selectedLoader = "Any";
    private string _selectedGameVersion = "";
    private string _selectedProjectType = "mod";
    private ObservableCollection<SearchResultEntry> _results = new();
    private SearchResultEntry? _selectedResult;
    private string _statusMessage = "";
    private bool _isBusy;

    public ObservableCollection<string> Loaders { get; } = new() { "Any", "Fabric", "Forge", "Quilt" };
    public ObservableCollection<string> ProjectTypes { get; } = new() { "mod", "shader", "resourcepack" };
    public ObservableCollection<string> GameVersions { get; } = new() { "" };

    public string Query
    {
        get => _query;
        set => SetField(ref _query, value);
    }

    public string SelectedLoader
    {
        get => _selectedLoader;
        set => SetField(ref _selectedLoader, value);
    }

    public string SelectedGameVersion
    {
        get => _selectedGameVersion;
        set => SetField(ref _selectedGameVersion, value);
    }

    public string SelectedProjectType
    {
        get => _selectedProjectType;
        set => SetField(ref _selectedProjectType, value);
    }

    public ObservableCollection<SearchResultEntry> Results
    {
        get => _results;
        set => SetField(ref _results, value);
    }

    public SearchResultEntry? SelectedResult
    {
        get => _selectedResult;
        set => SetField(ref _selectedResult, value);
    }

    public string StatusMessage
    {
        get => _statusMessage;
        set => SetField(ref _statusMessage, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        set => SetField(ref _isBusy, value);
    }

    public ICommand LoadVersionsCommand { get; }
    public ICommand SearchCommand { get; }
    public ICommand DownloadCommand { get; }

    public DownloadCenterViewModel()
    {
        LoadVersionsCommand = new AsyncRelayCommand(_ => LoadGameVersionsAsync());
        SearchCommand = new AsyncRelayCommand(_ => SearchAsync(), _ => !IsBusy);
        DownloadCommand = new AsyncRelayCommand(_ => DownloadAsync(), _ => !IsBusy);
        _ = LoadGameVersionsAsync();
    }

    private async Task LoadGameVersionsAsync()
    {
        var versions = await LauncherService.Instance.GetVanillaVersionsAsync();
        GameVersions.Clear();
        GameVersions.Add(""); // Any
        foreach (var v in versions) GameVersions.Add(v);
    }

    private async Task SearchAsync()
    {
        IsBusy = true;
        try
        {
            var loader = SelectedLoader == "Any" ? LoaderType.Any : Enum.Parse<LoaderType>(SelectedLoader);
            var type = SelectedProjectType switch
            {
                "shader" => ModrinthProjectType.Shader,
                "resourcepack" => ModrinthProjectType.ResourcePack,
                _ => ModrinthProjectType.Mod
            };
            var list = await LauncherService.Instance.SearchModsAsync(Query, string.IsNullOrEmpty(SelectedGameVersion) ? null : SelectedGameVersion, loader, type);
            Results = new ObservableCollection<SearchResultEntry>(
                list.Select(h => new SearchResultEntry { ProjectId = h.ProjectId, Title = h.Title, Summary = h.Description }));
            StatusMessage = Results.Count > 0 ? $"找到 {Results.Count} 个结果" : "未找到结果";
        }
        catch (Exception ex)
        {
            StatusMessage = $"搜索失败：{ex.Message}";
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task DownloadAsync()
    {
        if (SelectedResult is null) { StatusMessage = "请先选择一个结果"; return; }
        IsBusy = true;
        try
        {
            var loader = SelectedLoader == "Any" ? LoaderType.Any : Enum.Parse<LoaderType>(SelectedLoader);
            var targetDir = SelectedProjectType switch
            {
                "shader" => PathEx.ShaderPacksDir(GameConstants.DefaultGameRoot),
                "resourcepack" => PathEx.ResourcePacksDir(GameConstants.DefaultGameRoot),
                _ => PathEx.ModsDir(GameConstants.DefaultGameRoot)
            };
            StatusMessage = $"正在下载 {SelectedResult.Title} …";
            var ok = await LauncherService.Instance.DownloadModAsync(SelectedResult.ProjectId, targetDir,
                string.IsNullOrEmpty(SelectedGameVersion) ? null : SelectedGameVersion, loader);
            StatusMessage = ok ? $"已下载到 {targetDir}" : "下载失败";
        }
        catch (Exception ex)
        {
            StatusMessage = $"下载出错：{ex.Message}";
        }
        finally
        {
            IsBusy = false;
        }
    }
}
