using System.Windows;
using MCLCS.App.ViewModels;

namespace MCLCS.App.Views;

public partial class RecommendationView : UserControl
{
    public RecommendationView()
    {
        InitializeComponent();
    }
}
