using System.Windows.Input;
using MCLCS.Core.Ai;
using MCLCS.Core.Mvvm;

namespace MCLCS.App.ViewModels;

/// <summary>AI 助手面板：崩溃解读、Mod 描述翻译（本地启发式 / 外部 API，由设置决定）。</summary>
public class AiAssistViewModel : ObservableObject
{
    private string _crashText = "";
    private string _interpretation = "";
    private string _modText = "";
    private string _translated = "";
    private string _statusMessage = "";
    private bool _isBusy;

    public string CrashText
    {
        get => _crashText;
        set => SetField(ref _crashText, value);
    }

    public string Interpretation
    {
        get => _interpretation;
        set => SetField(ref _interpretation, value);
    }

    public string ModText
    {
        get => _modText;
        set => SetField(ref _modText, value);
    }

    public string Translated
    {
        get => _translated;
        set => SetField(ref _translated, value);
    }

    public string StatusMessage
    {
        get => _statusMessage;
        set => SetField(ref _statusMessage, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        set => SetField(ref _isBusy, value);
    }

    public bool AiEnabled => Assistant.Config.Enabled;

    public ICommand InterpretCommand { get; }
    public ICommand TranslateCommand { get; }

    public AiAssistViewModel()
    {
        InterpretCommand = new AsyncRelayCommand(_ => InterpretAsync(), _ => !IsBusy);
        TranslateCommand = new AsyncRelayCommand(_ => TranslateAsync(), _ => !IsBusy);
    }

    private async Task InterpretAsync()
    {
        if (string.IsNullOrWhiteSpace(CrashText)) { StatusMessage = "请粘贴崩溃日志"; return; }
        IsBusy = true;
        try
        {
            Interpretation = await Assistant.InterpretCrashAsync(CrashText);
            StatusMessage = Assistant.Config.Enabled && Assistant.Config.Mode == AiMode.External
                ? "已使用外部 AI 解读" : "已使用本地启发式解读";
        }
        finally { IsBusy = false; }
    }

    private async Task TranslateAsync()
    {
        if (string.IsNullOrWhiteSpace(ModText)) { StatusMessage = "请粘贴 Mod 描述"; return; }
        IsBusy = true;
        try
        {
            Translated = await Assistant.TranslateModDescriptionAsync(ModText);
        }
        finally { IsBusy = false; }
    }
}
