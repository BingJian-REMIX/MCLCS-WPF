using System.Text.Json.Serialization;
using MCLCS.Core.Ai;
using MCLCS.Core.Launcher;
using MCLCS.Core.Recommend;
using MCLCS.Core.Utils;

namespace MCLCS.Core.Profiles;

/// <summary>下载源偏好（设置 → 下载）。</summary>
public enum DownloadSourcePreference
{
    /// <summary>镜像优先（BMCLAPI 等），失败回退官方。</summary>
    MirrorFirst,
    /// <summary>官方优先，失败回退镜像。</summary>
    OfficialFirst
}

/// <summary>启动器持久化配置（默认用户名、内存、Java 路径等）。</summary>
public class LauncherProfile
{
    [JsonPropertyName("defaultUsername")]
    public string DefaultUsername { get; set; } = "Player";

    [JsonPropertyName("maxMemoryMb")]
    public int MaxMemoryMb { get; set; } = 2048;

    [JsonPropertyName("minMemoryMb")]
    public int MinMemoryMb { get; set; } = 512;

    [JsonPropertyName("javaPath")]
    public string? JavaPath { get; set; }

    [JsonPropertyName("gameRoot")]
    public string GameRoot { get; set; } = GameConstants.DefaultGameRoot;

    [JsonPropertyName("lastVersionId")]
    public string? LastVersionId { get; set; }

    [JsonPropertyName("resolutionWidth")]
    public int? ResolutionWidth { get; set; }

    [JsonPropertyName("resolutionHeight")]
    public int? ResolutionHeight { get; set; }

    /// <summary>额外的 JVM 参数（如 -XX:+UseZGC）。</summary>
    [JsonPropertyName("extraJvmArgs")]
    public List<string> ExtraJvmArgs { get; set; } = new();

    /// <summary>当前活跃账号 ID（AccountEntry.Id）。</summary>
    [JsonPropertyName("lastAccountId")]
    public string? LastAccountId { get; set; }

    /// <summary>崩溃自动修复策略：始终开启 / 每次询问 / 始终拒绝（默认每次询问）。</summary>
    [JsonPropertyName("repairPolicy")]
    public CrashRepairPolicy RepairPolicy { get; set; } = CrashRepairPolicy.Ask;

    /// <summary>自动安装 Java 时首选的发行商：Auto / Temurin / Oracle（默认 Auto）。</summary>
    [JsonPropertyName("preferredJavaVendor")]
    public JavaVendor PreferredJavaVendor { get; set; } = JavaVendor.Auto;

    /// <summary>启动时自动安装缺失的 Mod 前置依赖：开启 / 询问 / 关闭（默认询问）。</summary>
    [JsonPropertyName("autoInstallMissingMods")]
    public AutoInstallPolicy AutoInstallMissingMods { get; set; } = AutoInstallPolicy.Ask;

    /// <summary>智能推荐总开关：启用推荐 / 仅本地 / 禁用（默认启用）。</summary>
    [JsonPropertyName("intelliRecommend")]
    public IntelliRecommendMode IntelliRecommend { get; set; } = IntelliRecommendMode.Enabled;

    /// <summary>用户感兴趣的玩法分区（默认全选）。用于优先展示对应类别的推荐。</summary>
    [JsonPropertyName("preferredCategories")]
    public List<GameplayCategory> PreferredCategories { get; set; } = new()
    {
        GameplayCategory.Tech, GameplayCategory.Building, GameplayCategory.Adventure,
        GameplayCategory.Magic, GameplayCategory.Optimization, GameplayCategory.Utility
    };

    // ---- 通用（设置 → 通用）----

    [JsonPropertyName("language")]
    public string Language { get; set; } = "zh-CN";

    [JsonPropertyName("autoStartLauncher")]
    public bool AutoStartLauncher { get; set; }

    [JsonPropertyName("minimizeToTray")]
    public bool MinimizeToTray { get; set; }

    [JsonPropertyName("animationsEnabled")]
    public bool AnimationsEnabled { get; set; } = true;

    // ---- 下载（设置 → 下载）----

    [JsonPropertyName("downloadSource")]
    public DownloadSourcePreference DownloadSource { get; set; } = DownloadSourcePreference.MirrorFirst;

    [JsonPropertyName("maxConcurrentDownloads")]
    public int MaxConcurrentDownloads { get; set; } = 8;

    // ---- 外观（设置 → 外观）----

    [JsonPropertyName("themeColor")]
    public string ThemeColor { get; set; } = "#3a7b4f";

    [JsonPropertyName("backgroundImagePath")]
    public string? BackgroundImagePath { get; set; }

    [JsonPropertyName("fontScale")]
    public double FontScale { get; set; } = 1.0;

    // ---- 关于 / 更新 ----

    [JsonPropertyName("autoUpdateCheck")]
    public bool AutoUpdateCheck { get; set; } = true;

    // ---- AI 助手（设置 → AI 助手）----

    [JsonPropertyName("ai")]
    public AiConfig Ai { get; set; } = new();
}

/// <summary>缺失 Mod 前置依赖的自动安装策略。</summary>
public enum AutoInstallPolicy
{
    /// <summary>始终自动安装缺失的前置依赖。</summary>
    Always,

    /// <summary>每次询问用户是否安装。</summary>
    Ask,

    /// <summary>从不自动安装（仅提示）。</summary>
    Never
}
