using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MCLCS.Core.Toolbox;

/// <summary>备份类型。</summary>
public enum BackupKind
{
    /// <summary>单个存档。</summary>
    Save,
    /// <summary>配置目录（config/、options.txt 等）。</summary>
    Config,
    /// <summary>Mod 目录。</summary>
    Mods,
    /// <summary>自定义目录。</summary>
    Custom
}

/// <summary>一条备份记录。</summary>
public class BackupRecord
{
    [JsonPropertyName("id")] public string Id { get; set; } = "";
    [JsonPropertyName("kind")] public BackupKind Kind { get; set; }

    /// <summary>备份来源（存档名 / 目录名）。</summary>
    [JsonPropertyName("sourceName")] public string SourceName { get; set; } = "";

    /// <summary>备份 zip 的完整路径。</summary>
    [JsonPropertyName("archivePath")] public string ArchivePath { get; set; } = "";

    [JsonPropertyName("createdAt")] public DateTime CreatedAt { get; set; } = DateTime.Now;
    [JsonPropertyName("sizeBytes")] public long SizeBytes { get; set; }
    [JsonPropertyName("fileCount")] public int FileCount { get; set; }

    /// <summary>用户备注。</summary>
    [JsonPropertyName("note")] public string? Note { get; set; }

    /// <summary>是否为自动备份（启动前自动创建）。</summary>
    [JsonPropertyName("auto")] public bool Auto { get; set; }

    public string SizeText => SizeBytes switch
    {
        < 1024 => $"{SizeBytes} B",
        < 1024 * 1024 => $"{SizeBytes / 1024.0:F1} KB",
        < 1024L * 1024 * 1024 => $"{SizeBytes / 1024.0 / 1024:F1} MB",
        _ => $"{SizeBytes / 1024.0 / 1024 / 1024:F2} GB"
    };

    public bool Exists => !string.IsNullOrEmpty(ArchivePath) && File.Exists(ArchivePath);
}

/// <summary>备份保留策略。</summary>
public class BackupPolicy
{
    /// <summary>每个来源最多保留多少份（0 = 不限）。</summary>
    [JsonPropertyName("keepPerSource")] public int KeepPerSource { get; set; } = 5;

    /// <summary>超过多少天的自动备份会被清理（0 = 不按时间清理）。</summary>
    [JsonPropertyName("maxAgeDays")] public int MaxAgeDays { get; set; } = 30;

    /// <summary>启动游戏前自动备份当前存档。</summary>
    [JsonPropertyName("autoBeforeLaunch")] public bool AutoBeforeLaunch { get; set; }

    /// <summary>备份总目录（相对 gameRoot）。</summary>
    [JsonPropertyName("folder")] public string Folder { get; set; } = "backups";
}

/// <summary>备份操作结果。</summary>
public sealed class BackupResult
{
    public bool Ok { get; init; }
    public string? Error { get; init; }
    public BackupRecord? Record { get; init; }

    public static BackupResult Fail(string error) => new() { Ok = false, Error = error };
}

/// <summary>
/// 备份管理器（工具箱面板 11）：把存档 / 配置 / Mod 目录打成 zip，支持列出、恢复、按策略清理。
/// 索引文件为 <c>{gameRoot}/{folder}/backups.json</c>。
/// </summary>
public static class BackupManager
{
    public const string IndexFileName = "backups.json";

    private static readonly JsonSerializerOptions JsonOpts = new() { WriteIndented = true };

    public static string BackupRoot(string gameRoot, BackupPolicy? policy = null) =>
        Path.Combine(gameRoot, (policy ?? new BackupPolicy()).Folder);

    public static string IndexPath(string gameRoot, BackupPolicy? policy = null) =>
        Path.Combine(BackupRoot(gameRoot, policy), IndexFileName);

    /// <summary>生成备份文件名：<c>{kind}_{source}_{yyyyMMdd-HHmmss}.zip</c>。</summary>
    public static string BuildArchiveName(BackupKind kind, string sourceName, DateTime time)
    {
        var safe = sourceName;
        foreach (var c in Path.GetInvalidFileNameChars()) safe = safe.Replace(c, '_');
        if (safe.Length > 40) safe = safe[..40];
        return $"{kind.ToString().ToLowerInvariant()}_{safe}_{time:yyyyMMdd-HHmmss}.zip";
    }

    /// <summary>读取备份索引（不存在返回空表）。</summary>
    public static List<BackupRecord> LoadIndex(string gameRoot, BackupPolicy? policy = null)
    {
        try
        {
            var path = IndexPath(gameRoot, policy);
            if (!File.Exists(path)) return new List<BackupRecord>();
            return JsonSerializer.Deserialize<List<BackupRecord>>(File.ReadAllText(path))
                   ?? new List<BackupRecord>();
        }
        catch
        {
            return new List<BackupRecord>();
        }
    }

    /// <summary>写入备份索引。</summary>
    public static bool SaveIndex(string gameRoot, List<BackupRecord> records, BackupPolicy? policy = null)
    {
        try
        {
            var root = BackupRoot(gameRoot, policy);
            Directory.CreateDirectory(root);
            File.WriteAllText(IndexPath(gameRoot, policy), JsonSerializer.Serialize(records, JsonOpts));
            return true;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>创建一份备份。</summary>
    public static BackupResult Create(
        string gameRoot, string sourceDir, BackupKind kind,
        string? note = null, bool auto = false, BackupPolicy? policy = null)
    {
        policy ??= new BackupPolicy();

        if (string.IsNullOrWhiteSpace(sourceDir) || !Directory.Exists(sourceDir))
            return BackupResult.Fail("源目录不存在");

        try
        {
            var root = BackupRoot(gameRoot, policy);
            Directory.CreateDirectory(root);

            var sourceName = new DirectoryInfo(sourceDir).Name;
            var now = DateTime.Now;
            var archivePath = Path.Combine(root, BuildArchiveName(kind, sourceName, now));

            var files = Directory.GetFiles(sourceDir, "*", SearchOption.AllDirectories);
            if (File.Exists(archivePath)) File.Delete(archivePath);
            ZipFile.CreateFromDirectory(sourceDir, archivePath, CompressionLevel.Fastest, includeBaseDirectory: false);

            var record = new BackupRecord
            {
                Id = Guid.NewGuid().ToString("N")[..12],
                Kind = kind,
                SourceName = sourceName,
                ArchivePath = archivePath,
                CreatedAt = now,
                SizeBytes = new FileInfo(archivePath).Length,
                FileCount = files.Length,
                Note = note,
                Auto = auto
            };

            var index = LoadIndex(gameRoot, policy);
            index.Add(record);
            SaveIndex(gameRoot, index, policy);

            return new BackupResult { Ok = true, Record = record };
        }
        catch (Exception ex)
        {
            return BackupResult.Fail(ex.Message);
        }
    }

    /// <summary>
    /// 恢复备份到目标目录。<paramref name="overwrite"/> 为 true 时先清空目标目录，
    /// 否则目标目录非空即失败。
    /// </summary>
    public static BackupResult Restore(BackupRecord record, string targetDir, bool overwrite = false)
    {
        if (!record.Exists) return BackupResult.Fail("备份文件已丢失");

        try
        {
            if (Directory.Exists(targetDir))
            {
                if (!overwrite && Directory.EnumerateFileSystemEntries(targetDir).Any())
                    return BackupResult.Fail("目标目录非空，需勾选覆盖");
                if (overwrite) Directory.Delete(targetDir, recursive: true);
            }
            Directory.CreateDirectory(targetDir);
            ZipFile.ExtractToDirectory(record.ArchivePath, targetDir, overwriteFiles: true);
            return new BackupResult { Ok = true, Record = record };
        }
        catch (Exception ex)
        {
            return BackupResult.Fail(ex.Message);
        }
    }

    /// <summary>删除一条备份（含 zip 文件）。</summary>
    public static bool Delete(string gameRoot, string backupId, BackupPolicy? policy = null)
    {
        var index = LoadIndex(gameRoot, policy);
        var rec = index.FirstOrDefault(r => r.Id == backupId);
        if (rec is null) return false;

        try { if (File.Exists(rec.ArchivePath)) File.Delete(rec.ArchivePath); } catch { /* ignore */ }
        index.Remove(rec);
        SaveIndex(gameRoot, index, policy);
        return true;
    }

    /// <summary>
    /// 计算按策略应被淘汰的备份（纯函数，便于自检）：
    /// 先按超龄剔除自动备份，再按"每来源保留 N 份"保留最新的。手动备份不受超龄限制。
    /// </summary>
    public static List<BackupRecord> SelectExpired(
        IEnumerable<BackupRecord> records, BackupPolicy policy, DateTime? now = null)
    {
        var t = now ?? DateTime.Now;
        var all = records.ToList();
        var expired = new List<BackupRecord>();

        if (policy.MaxAgeDays > 0)
        {
            expired.AddRange(all.Where(r => r.Auto && (t - r.CreatedAt).TotalDays > policy.MaxAgeDays));
        }

        if (policy.KeepPerSource > 0)
        {
            foreach (var group in all.Except(expired).GroupBy(r => (r.Kind, r.SourceName)))
            {
                var ordered = group.OrderByDescending(r => r.CreatedAt).ToList();
                if (ordered.Count > policy.KeepPerSource)
                    expired.AddRange(ordered.Skip(policy.KeepPerSource));
            }
        }

        return expired.Distinct().ToList();
    }

    /// <summary>按策略清理，返回实际删除的份数。</summary>
    public static int Prune(string gameRoot, BackupPolicy policy, DateTime? now = null)
    {
        var index = LoadIndex(gameRoot, policy);
        var expired = SelectExpired(index, policy, now);
        if (expired.Count == 0) return 0;

        foreach (var rec in expired)
        {
            try { if (File.Exists(rec.ArchivePath)) File.Delete(rec.ArchivePath); } catch { /* ignore */ }
            index.Remove(rec);
        }
        SaveIndex(gameRoot, index, policy);
        return expired.Count;
    }

    /// <summary>列出备份（按时间倒序，可按类型过滤）。</summary>
    public static List<BackupRecord> List(string gameRoot, BackupKind? kind = null, BackupPolicy? policy = null) =>
        LoadIndex(gameRoot, policy)
            .Where(r => kind is null || r.Kind == kind)
            .OrderByDescending(r => r.CreatedAt)
            .ToList();

    /// <summary>统计占用空间（字节）。</summary>
    public static long TotalSize(string gameRoot, BackupPolicy? policy = null) =>
        LoadIndex(gameRoot, policy).Sum(r => r.SizeBytes);
}
