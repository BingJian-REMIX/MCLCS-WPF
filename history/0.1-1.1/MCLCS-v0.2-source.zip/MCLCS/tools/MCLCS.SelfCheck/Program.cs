using System.Text.Json;
using MCLCS.Core.Auth;
using MCLCS.Core.Download;
using MCLCS.Core.Installers;
using MCLCS.Core.Launcher;
using MCLCS.Core.Models;
using MCLCS.Core.Profiles;
using MCLCS.Core.Utils;

namespace MCLCS.SelfCheck;

internal static class Program
{
    private static int _passed;
    private static int _failed;

    private static void Check(string name, bool condition)
    {
        if (condition) { _passed++; Console.WriteLine($"  PASS  {name}"); }
        else { _failed++; Console.WriteLine($"  FAIL  {name}"); }
    }

    private static async Task Main()
    {
        Console.WriteLine("=== MCLCS Core 自检 ===\n");

        await JavaDetection();
        MavenParsing();
        ArgumentProcessing();
        ClasspathAndNatives();
        CrashAnalysis();
        OfflineAuth();
        await VersionMerge();
        AccountStoreTest();
        LaunchOptionsAndAuthVars();
        ModpackIndexParsing();
        ModrinthModelDeserialization();

        Console.WriteLine($"\n=== 结果：{_passed} 通过, {_failed} 失败 ===");
        Environment.Exit(_failed == 0 ? 0 : 1);
    }

    private static async Task JavaDetection()
    {
        Console.WriteLine("[Java 版本解析]");
        Check("1.8.0_301 -> 8", JavaDetector.MajorFromVersionString("1.8.0_301") == 8);
        Check("21.0.3 -> 21", JavaDetector.MajorFromVersionString("21.0.3") == 21);
        Check("17 -> 17", JavaDetector.MajorFromVersionString("17") == 17);
        await Task.CompletedTask;
    }

    private static void MavenParsing()
    {
        Console.WriteLine("[Maven 坐标解析]");
        var c = MavenCoordinate.Parse("org.lwjgl:lwjgl:3.3.1");
        Check("group", c.Group == "org.lwjgl");
        Check("artifact", c.Artifact == "lwjgl");
        Check("version", c.Version == "3.3.1");
        Check("localPath", c.LocalPath() == "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1.jar");
        var c2 = MavenCoordinate.Parse("com.example:mod:1.0:natives-linux");
        Check("classifier path", c2.LocalPath() == "com/example/mod/1.0/mod-1.0-natives-linux.jar");
    }

    private static void ArgumentProcessing()
    {
        Console.WriteLine("[参数解析：规则 + 变量 + 内存注入]");

        // 构造一个含 windows/linux 规则与变量的版本（在 Linux 沙箱上运行）
        var version = new VersionJson
        {
            Id = "test",
            MainClass = "net.minecraft.client.main.Main",
            Arguments = new Arguments
            {
                Jvm = new List<ArgumentItem>
                {
                    new() { Values = new() { "-XX:+UseG1GC" } },
                    new() { Rules = new() { new Rule { Action = "allow", Os = new OsRule { Name = "windows" } } },
                            Values = new() { "-DWINDOWS_MARKER=1" } },
                    new() { Rules = new() { new Rule { Action = "allow", Os = new OsRule { Name = "linux" } } },
                            Values = new() { "-DLINUX_MARKER=1" } }
                },
                Game = new List<ArgumentItem>
                {
                    new() { Values = new() { "--username", "${auth_player_name}" } },
                    new() { Rules = new() { new Rule { Action = "allow", Features = new() { { "has_custom_resolution", true } } } },
                            Values = new() { "--width", "${resolution_width}" } }
                }
            }
        };

        var vars = new Dictionary<string, string>
        {
            ["auth_player_name"] = "Steve",
            ["natives_directory"] = "/tmp/natives"
        };
        var options = new LaunchOptions { MaxMemoryMb = 4096 };
        var resolved = ArgumentProcessor.Process(version, vars, options, "/tmp/natives");

        Check("保留 -XX:+UseG1GC", resolved.JvmArgs.Contains("-XX:+UseG1GC"));
        Check("包含 linux 标记", resolved.JvmArgs.Contains("-DLINUX_MARKER=1"));
        Check("排除 windows 标记", !resolved.JvmArgs.Contains("-DWINDOWS_MARKER=1"));
        Check("注入 -Xmx4096M", resolved.JvmArgs.Any(a => a == "-Xmx4096M"));
        Check("注入 java.library.path", resolved.JvmArgs.Any(a => a.StartsWith("-Djava.library.path=")));
        Check("注入 org.lwjgl.librarypath", resolved.JvmArgs.Any(a => a.StartsWith("-Dorg.lwjgl.librarypath=")));
        Check("变量替换用户名", resolved.GameArgs.Count >= 2 && resolved.GameArgs[1] == "Steve");
        Check("无自定义分辨率时排除 --width", !resolved.GameArgs.Contains("--width"));

        // 旧版 minecraftArguments 回退
        Console.WriteLine("[参数解析：旧版 minecraftArguments]");
        var legacy = new VersionJson
        {
            Id = "legacy",
            MinecraftArguments = "-Xmx2G -Dfoo=bar -cp ${classpath} net.minecraft.client.main.Main --username ${auth_player_name}"
        };
        var lvars = new Dictionary<string, string> { ["auth_player_name"] = "Alex", ["classpath"] = "a.jar;b.jar" };
        var lresolved = ArgumentProcessor.Process(legacy, lvars, new LaunchOptions { MaxMemoryMb = 2048 }, "/tmp/n");
        Check("legacy 提取 mainClass", lresolved.MainClass == "net.minecraft.client.main.Main");
        Check("legacy 替换用户名", lresolved.GameArgs.Contains("Alex"));
        Check("legacy 内存被用户值覆盖", lresolved.JvmArgs.Contains("-Xmx2048M"));
    }

    private static void ClasspathAndNatives()
    {
        Console.WriteLine("[classpath 构建 + natives]");
        var root = Path.Combine(Path.GetTempPath(), "mclcs_cp_" + Guid.NewGuid().ToString("N"));
        try
        {
            var vdir = Path.Combine(root, "versions", "1.20.1");
            Directory.CreateDirectory(vdir);
            File.WriteAllText(Path.Combine(vdir, "1.20.1.jar"), "dummy");

            var libDir = Path.Combine(root, "libraries", "com", "mojang", "log4j", "2.19.1");
            Directory.CreateDirectory(libDir);
            File.WriteAllText(Path.Combine(libDir, "log4j-2.19.1.jar"), "dummy");

            var version = new VersionJson
            {
                Id = "1.20.1",
                Libraries = new List<Library>
                {
                    new() { Name = "com.mojang:log4j:2.19.1",
                            Downloads = new LibraryDownloads { Artifact = new DownloadInfo { Path = "com/mojang/log4j/2.19.1/log4j-2.19.1.jar" } } },
                    new() { Name = "org.lwjgl:lwjgl:3.3.1",
                            Natives = new Dictionary<string, string> { { "linux", "natives-linux" } },
                            Downloads = new LibraryDownloads { Classifiers = new() { ["natives-linux"] = new DownloadInfo { Path = "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1-natives-linux.jar" } } } }
                }
            };

            var cp = ClasspathBuilder.ComputeClasspath(root, "1.20.1", version);
            Check("classpath 含版本 jar", cp.Contains("1.20.1.jar"));
            Check("classpath 含库 jar", cp.Contains("log4j-2.19.1.jar"));

            var natives = ClasspathBuilder.GetNativeEntries(root, version, Path.Combine(root, "natives"));
            Check("识别 1 个 natives 条目", natives.Count == 1);
            Check("natives 路径含 natives-linux", natives.Count == 1 && natives[0].JarPath.Contains("natives-linux"));
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }
    }

    private static void CrashAnalysis()
    {
        Console.WriteLine("[崩溃分析]");
        var oom = CrashAnalyzer.Analyze("Description: The game crashed. java.lang.OutOfMemoryError: Java heap space");
        Check("OutOfMemoryError", oom.ExceptionType.Contains("内存不足"));

        var uvc = CrashAnalyzer.Analyze("java.lang.UnsupportedClassVersionError: class file version 65.0");
        Check("UnsupportedClassVersion 识别", uvc.ExceptionType.Contains("Java 版本不匹配"));
        Check("推算需要 Java 21", uvc.Summary.Contains("Java 21"));

        var cnf = CrashAnalyzer.Analyze("java.lang.ClassNotFoundException: com.example.mymod.Mod");
        Check("ClassNotFoundException", cnf.ExceptionType.Contains("类未找到"));

        var gl = CrashAnalyzer.Analyze("OpenGL error: Could not create context");
        Check("OpenGL 错误", gl.ExceptionType.Contains("OpenGL"));
    }

    private static void OfflineAuth()
    {
        Console.WriteLine("[离线认证 UUID]");
        var uuid = OfflineAuthenticator.GenerateOfflineUuid("Notch");
        Check("UUID 长度 36", uuid.Length == 36);
        Check("UUID 含连字符", uuid.Contains('-'));
        Check("同名稳定", OfflineAuthenticator.GenerateOfflineUuid("Notch") == uuid);
    }

    private static async Task VersionMerge()
    {
        Console.WriteLine("[版本合并（Fabric 继承原版）]");
        var root = Path.Combine(Path.GetTempPath(), "mclcs_merge_" + Guid.NewGuid().ToString("N"));
        try
        {
            var vanillaDir = Path.Combine(root, "versions", "1.20.1");
            Directory.CreateDirectory(vanillaDir);
            var vanilla = new VersionJson
            {
                Id = "1.20.1",
                MainClass = "net.minecraft.client.main.Main",
                Libraries = new List<Library> { new() { Name = "com.mojang:patchy:1.0" } },
                Arguments = new Arguments
                {
                    Game = new List<ArgumentItem> { new() { Values = new() { "--username", "${auth_player_name}" } } }
                }
            };
            await File.WriteAllTextAsync(Path.Combine(vanillaDir, "1.20.1.json"),
                JsonSerializer.Serialize(vanilla, new JsonSerializerOptions { WriteIndented = true }));

            var fabricDir = Path.Combine(root, "versions", "fabric-1.20.1");
            Directory.CreateDirectory(fabricDir);
            var fabric = new VersionJson
            {
                Id = "fabric-1.20.1",
                InheritsFrom = "1.20.1",
                MainClass = "net.fabricmc.loader.impl.launcher.Main",
                Libraries = new List<Library> { new() { Name = "net.fabricmc:fabric-loader:0.15.0" } },
                Arguments = new Arguments
                {
                    Game = new List<ArgumentItem> { new() { Values = new() { "--fabric" } } }
                }
            };
            await File.WriteAllTextAsync(Path.Combine(fabricDir, "fabric-1.20.1.json"),
                JsonSerializer.Serialize(fabric, new JsonSerializerOptions { WriteIndented = true }));

            var merged = VersionMerger.Merge(root, "fabric-1.20.1");
            Check("mainClass 取自子版本(Fabric)", merged.MainClass == "net.fabricmc.loader.impl.launcher.Main");
            Check("库合并含原版库", merged.Libraries.Any(l => l.Name == "com.mojang:patchy:1.0"));
            Check("库合并含 Fabric 库", merged.Libraries.Any(l => l.Name == "net.fabricmc:fabric-loader:0.15.0"));
            Check("game 参数合并含原版", merged.Arguments!.Game.Any(i => i.Values.Contains("--username")));
            Check("game 参数合并含 Fabric", merged.Arguments!.Game.Any(i => i.Values.Contains("--fabric")));
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }
        await Task.CompletedTask;
    }

    // ---- v0.2 新增测试 ----

    private static void AccountStoreTest()
    {
        Console.WriteLine("[账号存储 CRUD]");
        var tmp = Path.Combine(Path.GetTempPath(), "mclcs_acctest_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(tmp);
            var list = AccountStore.Load(tmp);
            Check("新目录返回空列表", list.Count == 0);

            var a = new AccountEntry
            {
                Id = "test1",
                DisplayName = "离线玩家",
                AuthType = "offline",
                Username = "Player"
            };
            AccountStore.Upsert(tmp, a);

            var loaded = AccountStore.Load(tmp);
            Check("保存后加载 1 条", loaded.Count == 1);
            Check("条目属性正确", loaded[0].Id == "test1" && loaded[0].AuthType == "offline");
            Check("自动设置 lastUsed", !string.IsNullOrEmpty(loaded[0].LastUsed));

            var lu = AccountStore.GetLastUsed(tmp);
            Check("GetLastUsed 返回正确", lu is not null && lu.Id == "test1");

            AccountStore.Remove(tmp, "test1");
            Check("删除后为空", AccountStore.Load(tmp).Count == 0);
        }
        finally
        {
            if (Directory.Exists(tmp)) Directory.Delete(tmp, true);
        }
    }

    private static void LaunchOptionsAndAuthVars()
    {
        Console.WriteLine("[LaunchOptions 扩展字段]");
        var options = new LaunchOptions
        {
            UserType = "msa",
            UserProperties = "{\"prop\":\"value\"}",
            ExtraJvmArgs = new List<string> { "-XX:+UseZGC" }
        };
        Check("UserType msa", options.UserType == "msa");
        Check("UserProperties 非空", options.UserProperties != "{}");
        Check("ExtraJvmArgs 有值", options.ExtraJvmArgs.Count == 1);
    }

    private static void ModpackIndexParsing()
    {
        Console.WriteLine("[整合包索引解析]");
        var json = @"{
            ""formatVersion"": 1,
            ""game"": ""minecraft"",
            ""versionId"": ""1.20.1"",
            ""name"": ""Test Pack"",
            ""dependencies"": { ""minecraft"": ""1.20.1"", ""fabric-loader"": ""0.15.0"" },
            ""files"": [
                {
                    ""path"": ""mods/sodium.jar"",
                    ""env"": { ""client"": ""required"", ""server"": ""unsupported"" },
                    ""hashes"": { ""sha1"": ""abc123"", ""sha512"": ""def456"" },
                    ""downloads"": [""https://example.com/sodium.jar""],
                    ""fileSize"": 123456
                }
            ]
        }";
        var index = JsonSerializer.Deserialize<ModrinthPackIndex>(json);
        Check("formatVersion 1", index is not null && index.FormatVersion == 1);
        Check("name Test Pack", index!.Name == "Test Pack");
        Check("dependencies 含 fabric-loader", index.Dependencies.ContainsKey("fabric-loader"));
        Check("1 个 file", index.Files.Count == 1);
        Check("file client=required", index.Files[0].Env.Client == "required");
        Check("downloads URL", index.Files[0].Downloads[0] == "https://example.com/sodium.jar");
    }

    private static void ModrinthModelDeserialization()
    {
        Console.WriteLine("[Modrinth 模型反序列化]");
        var projJson = @"{""id"":""abc"",""slug"":""sodium"",""title"":""Sodium"",""description"":""Fast"",""body"":""..."",""project_type"":""mod"",""game_versions"":[""1.20.1""],""loaders"":[""fabric""],""downloads"":999,""icon_url"":""https://icon.png"",""gallery"":[]}";
        var proj = JsonSerializer.Deserialize<ModrinthProject>(projJson);
        Check("ModrinthProject title", proj is not null && proj.Title == "Sodium");

        var depJson = @"[{""version_id"":null,""project_id"":""fabric-api"",""file_name"":null,""dependency_type"":""required""}]";
        var deps = JsonSerializer.Deserialize<List<ModrinthDependency>>(depJson);
        Check("dependency type=required", deps is not null && deps[0].DependencyType == "required");

        // LoaderType.NeoForge
        Check("NeoForge loader string", ModrinthClient.LoaderString(LoaderType.NeoForge) == "neoforge");
    }
}
