using System.Windows.Input;
using System.Windows.Media.Imaging;
using MCLCS.Core.Mvvm;
using MCLCS.Core.Skin;
using MCLCS.Core.Utils;

namespace MCLCS.App.ViewModels;

/// <summary>皮肤预览页 ViewModel。</summary>
public class SkinViewModel : ObservableObject
{
    private string _playerName = "";
    private string _skinUrl = "";
    private string _modelType = "classic";
    private string _statusMessage = "";
    private bool _isBusy;
    private bool _hasSkin;

    public string PlayerName
    {
        get => _playerName;
        set => SetField(ref _playerName, value);
    }

    public string SkinUrl
    {
        get => _skinUrl;
        set => SetField(ref _skinUrl, value);
    }

    public string ModelType
    {
        get => _modelType;
        set => SetField(ref _modelType, value);
    }

    public string StatusMessage
    {
        get => _statusMessage;
        set => SetField(ref _statusMessage, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        set => SetField(ref _isBusy, value);
    }

    public bool HasSkin
    {
        get => _hasSkin;
        set => SetField(ref _hasSkin, value);
    }

    public ICommand FetchSkinCommand { get; }

    public SkinViewModel()
    {
        FetchSkinCommand = new AsyncRelayCommand(_ => FetchSkinAsync());
    }

    private async Task FetchSkinAsync()
    {
        if (string.IsNullOrWhiteSpace(PlayerName)) return;
        IsBusy = true;
        HasSkin = false;
        try
        {
            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
            var skin = await SkinFetcher.FetchByUsernameAsync(client, PlayerName.Trim());
            if (skin is not null)
            {
                SkinUrl = skin.SkinUrl;
                ModelType = skin.Model;
                HasSkin = true;
                StatusMessage = $"已获取 {PlayerName} 的皮肤（{ModelType}）";
            }
            else
            {
                StatusMessage = $"未找到玩家 {PlayerName} 的皮肤";
            }
        }
        catch (Exception ex)
        {
            StatusMessage = $"获取皮肤失败：{ex.Message}";
        }
        finally { IsBusy = false; }
    }
}
