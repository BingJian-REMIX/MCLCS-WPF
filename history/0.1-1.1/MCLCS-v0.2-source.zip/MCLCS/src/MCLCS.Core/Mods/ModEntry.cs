using System.Text.Json.Serialization;

namespace MCLCS.Core.Mods;

/// <summary>一个已安装的 Mod。</summary>
public class ModEntry
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = "";

    [JsonPropertyName("name")]
    public string Name { get; set; } = "";

    [JsonPropertyName("fileName")]
    public string FileName { get; set; } = "";

    [JsonPropertyName("installedVersion")]
    public string InstalledVersion { get; set; } = "";

    [JsonPropertyName("latestVersion")]
    public string? LatestVersion { get; set; }

    [JsonPropertyName("projectUrl")]
    public string ProjectUrl { get; set; } = "";

    [JsonPropertyName("loader")]
    public string Loader { get; set; } = "";

    [JsonPropertyName("hasUpdate")]
    public bool HasUpdate => LatestVersion is not null && LatestVersion != InstalledVersion;
}
