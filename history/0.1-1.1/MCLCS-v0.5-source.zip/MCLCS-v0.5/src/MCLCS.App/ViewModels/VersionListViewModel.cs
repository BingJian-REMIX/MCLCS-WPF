using System.Collections.ObjectModel;
using System.Windows.Input;
using MCLCS.Core.Launcher;
using MCLCS.Core.Mods;
using MCLCS.Core.Mvvm;
using MCLCS.Core.Profiles;
using MCLCS.Core.Utils;
using MCLCS.App.Services;
using MCLCS.App.Views;

namespace MCLCS.App.ViewModels;

public class VersionEntry
{
    public string Id { get; init; } = "";
    public string Type { get; init; } = "";
    public string DisplayName => string.IsNullOrEmpty(Type) ? Id : $"{Id} ({Type})";
}

public class VersionListViewModel : ObservableObject
{
    private ObservableCollection<VersionEntry> _versions = new();
    private VersionEntry? _selectedVersion;
    private string _statusMessage = "";

    public ObservableCollection<VersionEntry> Versions
    {
        get => _versions;
        set => SetField(ref _versions, value);
    }

    public VersionEntry? SelectedVersion
    {
        get => _selectedVersion;
        set => SetField(ref _selectedVersion, value);
    }

    public string StatusMessage
    {
        get => _statusMessage;
        set => SetField(ref _statusMessage, value);
    }

    public ICommand RefreshCommand { get; }
    public ICommand LaunchCommand { get; }

    public VersionListViewModel()
    {
        RefreshCommand = new RelayCommand(_ => Refresh());
        LaunchCommand = new AsyncRelayCommand(_ => LaunchAsync());
        Refresh();
    }

    public void Refresh()
    {
        Versions = new ObservableCollection<VersionEntry>(
            LauncherService.Instance.ListInstalledVersions()
                .Select(t => new VersionEntry { Id = t.Id, Type = t.Type }));
        StatusMessage = Versions.Count > 0
            ? $"共发现 {Versions.Count} 个版本"
            : "暂无已安装版本，请前往「安装新版本」";
    }

    private async Task LaunchAsync()
    {
        if (SelectedVersion is null)
        {
            StatusMessage = "请先选择一个版本";
            return;
        }

        var versionId = SelectedVersion.Id;
        StatusMessage = $"正在启动 {versionId} …";
        try
        {
            // 启动前依赖检测（七.1）：缺失前置按设置自动安装或提示
            await CheckLaunchDependenciesAsync(versionId);

            var policy = ProfileStore.Load(LauncherService.Instance.GameRoot).RepairPolicy;
            var result = await LauncherService.Instance.LaunchAsync(versionId);
            await HandleLaunchResult(result, versionId, policy);
        }
        catch (Exception ex)
        {
            StatusMessage = $"启动失败：{ex.Message}";
        }
    }

    /// <summary>
    /// 根据崩溃修复策略处理启动结果：
    /// - 未崩溃：直接结束；
    /// - 始终拒绝 / 不可自动修复：仅展示崩溃详情；
    /// - 始终开启：静默循环自动修复并重启，直到成功或达到上限；
    /// - 每次询问：弹出报告窗口，由用户点击"尝试自动修复"按钮循环处理。
    /// </summary>
    /// <summary>启动前检测缺失的前置依赖：按「自动安装缺失前置」设置自动安装或提示。</summary>
    private async Task CheckLaunchDependenciesAsync(string versionId)
    {
        var pref = ProfileStore.Load(LauncherService.Instance.GameRoot).AutoInstallMissingMods;
        if (pref == AutoInstallPolicy.Never) return;

        var missing = ModManager.MissingDependencies(LauncherService.Instance.GameRoot);
        if (missing.Count == 0) return;

        if (pref == AutoInstallPolicy.Always)
        {
            var plan = new CrashRepairPlan
            {
                CanRepair = true,
                Strategy = RepairStrategy.InstallMissingModDependency,
                MissingModDependencies = missing,
                VersionId = versionId
            };
            var ok = await LauncherService.Instance.ApplyRepairAsync(plan);
            StatusMessage = ok
                ? $"已自动安装 {missing.Count} 个缺失前置，继续启动…"
                : $"缺失前置自动安装失败（{missing.Count} 个），继续启动";
        }
        else
        {
            StatusMessage = $"检测到 {missing.Count} 个缺失前置，可在「Mod 管理」页一键安装";
        }
    }

    private async Task HandleLaunchResult(LaunchResult result, string versionId, CrashRepairPolicy policy)
    {
        if (result.CrashReportPath is null)
        {
            StatusMessage = $"游戏进程已结束（退出码 {result.ExitCode}）";
            return;
        }

        var repairable = result.RepairPlan is { CanRepair: true };

        if (policy == CrashRepairPolicy.Never || !repairable)
        {
            ShowReport(result, allowRepair: false);
            StatusMessage = repairable
                ? $"崩溃（退出码 {result.ExitCode}），按策略不自动修复"
                : $"崩溃（退出码 {result.ExitCode}），无法自动修复，已展示详情";
            return;
        }

        if (policy == CrashRepairPolicy.Always)
        {
            var cur = result;
            var attempts = 0;
            while (cur.CrashReportPath is not null
                   && cur.RepairPlan is { CanRepair: true }
                   && attempts < GameConstants.MaxRepairAttempts)
            {
                attempts++;
                StatusMessage = $"自动修复中（{cur.RepairPlan.Strategy}），第 {attempts} 次…";
                await LauncherService.Instance.ApplyRepairAsync(cur.RepairPlan);
                cur = await LauncherService.Instance.LaunchAsync(versionId);
            }

            if (cur.CrashReportPath is null)
            {
                StatusMessage = "自动修复成功，游戏已正常启动。";
            }
            else
            {
                ShowReport(cur, allowRepair: cur.RepairPlan is { CanRepair: true });
                StatusMessage = !repairable || cur.RepairPlan is not { CanRepair: true }
                    ? "已尝试自动修复但仍崩溃，且无法继续自动修复。"
                    : $"已达最大自动修复次数（{GameConstants.MaxRepairAttempts}）。";
            }
            return;
        }

        // 每次询问：弹出报告窗口，由用户确认后修复（点击按钮即循环一次）
        ShowReport(result, allowRepair: true, versionId);
        StatusMessage = $"崩溃（退出码 {result.ExitCode}），可尝试自动修复。";
    }

    private void ShowReport(LaunchResult result, bool allowRepair, string? versionId = null)
    {
        System.Windows.Application.Current.Dispatcher.Invoke(() =>
        {
            Func<LaunchResult, Task<LaunchResult?>> relaunch = async r =>
            {
                if (r.RepairPlan is null) return r;
                await LauncherService.Instance.ApplyRepairAsync(r.RepairPlan);
                var vid = versionId ?? ProfileStore.Load(LauncherService.Instance.GameRoot).LastVersionId;
                if (string.IsNullOrEmpty(vid)) return r;
                var res = await LauncherService.Instance.LaunchAsync(vid);
                return res.CrashReportPath is null ? null : res;
            };

            var win = new CrashReportView(result, relaunch, allowRepair)
            {
                Owner = System.Windows.Application.Current.MainWindow
            };
            win.Show();
        });
    }
}
