using System.Text.Json;
using System.IO.Compression;
using MCLCS.Core.Auth;
using MCLCS.Core.Download;
using MCLCS.Core.Installers;
using MCLCS.Core.Launcher;
using MCLCS.Core.Localization;
using MCLCS.Core.Models;
using MCLCS.Core.Mods;
using MCLCS.Core.Profiles;
using MCLCS.Core.Recommend;
using MCLCS.Core.Save;
using MCLCS.Core.Skin;
using MCLCS.Core.Theme;
using MCLCS.Core.Utils;
using MCLCS.Core.Ai;
using MCLCS.Core.MultiInstance;
using MCLCS.Core.Statistics;
using MCLCS.Core.Toolbox;
using MCLCS.Core.Update;

namespace MCLCS.SelfCheck;

internal static class Program
{
    private static int _passed;
    private static int _failed;

    private static void Check(string name, bool condition)
    {
        if (condition) { _passed++; Console.WriteLine($"  PASS  {name}"); }
        else { _failed++; Console.WriteLine($"  FAIL  {name}"); }
    }

    private static async Task Main()
    {
        Console.WriteLine("=== MCLCS Core 自检 ===\n");

        await JavaDetection();
        MavenParsing();
        ArgumentProcessing();
        ClasspathAndNatives();
        CrashAnalysis();
        OfflineAuth();
        await VersionMerge();
        AccountStoreTest();
        LaunchOptionsAndAuthVars();
        RepairEngineTest();
        ModpackIndexParsing();
        ModrinthModelDeserialization();
        CurseForgeModels();
        LocalizationTest();
        SkinFetcherTest();
        ThemeManagerTest();
        ModMetadataParserTest();
        CrashRepairModelsV05Test();
        LibraryRepairTest();
        RecommendationSystemTest();
        JavaVendorTest();
        AutoInstallPolicyTest();
        ModConflictPlanTest();
        ProfileV05Test();
        await SaveFeatureTests();
        await ToolboxV1Tests();
        await AiV2Tests();

        Console.WriteLine($"\n=== 结果：{_passed} 通过, {_failed} 失败 ===");
        Environment.Exit(_failed == 0 ? 0 : 1);
    }

    private static async Task JavaDetection()
    {
        Console.WriteLine("[Java 版本解析]");
        Check("1.8.0_301 -> 8", JavaDetector.MajorFromVersionString("1.8.0_301") == 8);
        Check("21.0.3 -> 21", JavaDetector.MajorFromVersionString("21.0.3") == 21);
        Check("17 -> 17", JavaDetector.MajorFromVersionString("17") == 17);
        await Task.CompletedTask;
    }

    private static void MavenParsing()
    {
        Console.WriteLine("[Maven 坐标解析]");
        var c = MavenCoordinate.Parse("org.lwjgl:lwjgl:3.3.1");
        Check("group", c.Group == "org.lwjgl");
        Check("artifact", c.Artifact == "lwjgl");
        Check("version", c.Version == "3.3.1");
        Check("localPath", c.LocalPath() == "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1.jar");
        var c2 = MavenCoordinate.Parse("com.example:mod:1.0:natives-linux");
        Check("classifier path", c2.LocalPath() == "com/example/mod/1.0/mod-1.0-natives-linux.jar");
    }

    private static void ArgumentProcessing()
    {
        Console.WriteLine("[参数解析：规则 + 变量 + 内存注入]");

        // 构造一个含 windows/linux 规则与变量的版本（在 Linux 沙箱上运行）
        var version = new VersionJson
        {
            Id = "test",
            MainClass = "net.minecraft.client.main.Main",
            Arguments = new Arguments
            {
                Jvm = new List<ArgumentItem>
                {
                    new() { Values = new() { "-XX:+UseG1GC" } },
                    new() { Rules = new() { new Rule { Action = "allow", Os = new OsRule { Name = "windows" } } },
                            Values = new() { "-DWINDOWS_MARKER=1" } },
                    new() { Rules = new() { new Rule { Action = "allow", Os = new OsRule { Name = "linux" } } },
                            Values = new() { "-DLINUX_MARKER=1" } }
                },
                Game = new List<ArgumentItem>
                {
                    new() { Values = new() { "--username", "${auth_player_name}" } },
                    new() { Rules = new() { new Rule { Action = "allow", Features = new() { { "has_custom_resolution", true } } } },
                            Values = new() { "--width", "${resolution_width}" } }
                }
            }
        };

        var vars = new Dictionary<string, string>
        {
            ["auth_player_name"] = "Steve",
            ["natives_directory"] = "/tmp/natives"
        };
        var options = new LaunchOptions { MaxMemoryMb = 4096 };
        var resolved = ArgumentProcessor.Process(version, vars, options, "/tmp/natives");

        Check("保留 -XX:+UseG1GC", resolved.JvmArgs.Contains("-XX:+UseG1GC"));
        Check("包含 linux 标记", resolved.JvmArgs.Contains("-DLINUX_MARKER=1"));
        Check("排除 windows 标记", !resolved.JvmArgs.Contains("-DWINDOWS_MARKER=1"));
        Check("注入 -Xmx4096M", resolved.JvmArgs.Any(a => a == "-Xmx4096M"));
        Check("注入 java.library.path", resolved.JvmArgs.Any(a => a.StartsWith("-Djava.library.path=")));
        Check("注入 org.lwjgl.librarypath", resolved.JvmArgs.Any(a => a.StartsWith("-Dorg.lwjgl.librarypath=")));
        Check("变量替换用户名", resolved.GameArgs.Count >= 2 && resolved.GameArgs[1] == "Steve");
        Check("无自定义分辨率时排除 --width", !resolved.GameArgs.Contains("--width"));

        // 旧版 minecraftArguments 回退
        Console.WriteLine("[参数解析：旧版 minecraftArguments]");
        var legacy = new VersionJson
        {
            Id = "legacy",
            MinecraftArguments = "-Xmx2G -Dfoo=bar -cp ${classpath} net.minecraft.client.main.Main --username ${auth_player_name}"
        };
        var lvars = new Dictionary<string, string> { ["auth_player_name"] = "Alex", ["classpath"] = "a.jar;b.jar" };
        var lresolved = ArgumentProcessor.Process(legacy, lvars, new LaunchOptions { MaxMemoryMb = 2048 }, "/tmp/n");
        Check("legacy 提取 mainClass", lresolved.MainClass == "net.minecraft.client.main.Main");
        Check("legacy 替换用户名", lresolved.GameArgs.Contains("Alex"));
        Check("legacy 内存被用户值覆盖", lresolved.JvmArgs.Contains("-Xmx2048M"));
    }

    private static void ClasspathAndNatives()
    {
        Console.WriteLine("[classpath 构建 + natives]");
        var root = Path.Combine(Path.GetTempPath(), "mclcs_cp_" + Guid.NewGuid().ToString("N"));
        try
        {
            var vdir = Path.Combine(root, "versions", "1.20.1");
            Directory.CreateDirectory(vdir);
            File.WriteAllText(Path.Combine(vdir, "1.20.1.jar"), "dummy");

            var libDir = Path.Combine(root, "libraries", "com", "mojang", "log4j", "2.19.1");
            Directory.CreateDirectory(libDir);
            File.WriteAllText(Path.Combine(libDir, "log4j-2.19.1.jar"), "dummy");

            var version = new VersionJson
            {
                Id = "1.20.1",
                Libraries = new List<Library>
                {
                    new() { Name = "com.mojang:log4j:2.19.1",
                            Downloads = new LibraryDownloads { Artifact = new DownloadInfo { Path = "com/mojang/log4j/2.19.1/log4j-2.19.1.jar" } } },
                    new() { Name = "org.lwjgl:lwjgl:3.3.1",
                            Natives = new Dictionary<string, string> { { "linux", "natives-linux" } },
                            Downloads = new LibraryDownloads { Classifiers = new() { ["natives-linux"] = new DownloadInfo { Path = "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1-natives-linux.jar" } } } }
                }
            };

            var cp = ClasspathBuilder.ComputeClasspath(root, "1.20.1", version);
            Check("classpath 含版本 jar", cp.Contains("1.20.1.jar"));
            Check("classpath 含库 jar", cp.Contains("log4j-2.19.1.jar"));

            var natives = ClasspathBuilder.GetNativeEntries(root, version, Path.Combine(root, "natives"));
            Check("识别 1 个 natives 条目", natives.Count == 1);
            Check("natives 路径含 natives-linux", natives.Count == 1 && natives[0].JarPath.Contains("natives-linux"));
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }
    }

    private static void CrashAnalysis()
    {
        Console.WriteLine("[崩溃分析]");
        var oom = CrashAnalyzer.Analyze("Description: The game crashed. java.lang.OutOfMemoryError: Java heap space");
        Check("OutOfMemoryError", oom.ExceptionType.Contains("内存不足"));

        var uvc = CrashAnalyzer.Analyze("java.lang.UnsupportedClassVersionError: class file version 65.0");
        Check("UnsupportedClassVersion 识别", uvc.ExceptionType.Contains("Java 版本不匹配"));
        Check("推算需要 Java 21", uvc.Summary.Contains("Java 21"));

        var cnf = CrashAnalyzer.Analyze("java.lang.ClassNotFoundException: com.example.mymod.Mod");
        Check("ClassNotFoundException", cnf.ExceptionType.Contains("类未找到"));

        var gl = CrashAnalyzer.Analyze("OpenGL error: Could not create context");
        Check("OpenGL 错误", gl.ExceptionType.Contains("OpenGL"));
    }

    private static void OfflineAuth()
    {
        Console.WriteLine("[离线认证 UUID]");
        var uuid = OfflineAuthenticator.GenerateOfflineUuid("Notch");
        Check("UUID 长度 36", uuid.Length == 36);
        Check("UUID 含连字符", uuid.Contains('-'));
        Check("同名稳定", OfflineAuthenticator.GenerateOfflineUuid("Notch") == uuid);
    }

    private static async Task VersionMerge()
    {
        Console.WriteLine("[版本合并（Fabric 继承原版）]");
        var root = Path.Combine(Path.GetTempPath(), "mclcs_merge_" + Guid.NewGuid().ToString("N"));
        try
        {
            var vanillaDir = Path.Combine(root, "versions", "1.20.1");
            Directory.CreateDirectory(vanillaDir);
            var vanilla = new VersionJson
            {
                Id = "1.20.1",
                MainClass = "net.minecraft.client.main.Main",
                Libraries = new List<Library> { new() { Name = "com.mojang:patchy:1.0" } },
                Arguments = new Arguments
                {
                    Game = new List<ArgumentItem> { new() { Values = new() { "--username", "${auth_player_name}" } } }
                }
            };
            await File.WriteAllTextAsync(Path.Combine(vanillaDir, "1.20.1.json"),
                JsonSerializer.Serialize(vanilla, new JsonSerializerOptions { WriteIndented = true }));

            var fabricDir = Path.Combine(root, "versions", "fabric-1.20.1");
            Directory.CreateDirectory(fabricDir);
            var fabric = new VersionJson
            {
                Id = "fabric-1.20.1",
                InheritsFrom = "1.20.1",
                MainClass = "net.fabricmc.loader.impl.launcher.Main",
                Libraries = new List<Library> { new() { Name = "net.fabricmc:fabric-loader:0.15.0" } },
                Arguments = new Arguments
                {
                    Game = new List<ArgumentItem> { new() { Values = new() { "--fabric" } } }
                }
            };
            await File.WriteAllTextAsync(Path.Combine(fabricDir, "fabric-1.20.1.json"),
                JsonSerializer.Serialize(fabric, new JsonSerializerOptions { WriteIndented = true }));

            var merged = VersionMerger.Merge(root, "fabric-1.20.1");
            Check("mainClass 取自子版本(Fabric)", merged.MainClass == "net.fabricmc.loader.impl.launcher.Main");
            Check("库合并含原版库", merged.Libraries.Any(l => l.Name == "com.mojang:patchy:1.0"));
            Check("库合并含 Fabric 库", merged.Libraries.Any(l => l.Name == "net.fabricmc:fabric-loader:0.15.0"));
            Check("game 参数合并含原版", merged.Arguments!.Game.Any(i => i.Values.Contains("--username")));
            Check("game 参数合并含 Fabric", merged.Arguments!.Game.Any(i => i.Values.Contains("--fabric")));
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }
        await Task.CompletedTask;
    }

    // ---- v0.2 新增测试 ----

    private static void AccountStoreTest()
    {
        Console.WriteLine("[账号存储 CRUD]");
        var tmp = Path.Combine(Path.GetTempPath(), "mclcs_acctest_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(tmp);
            var list = AccountStore.Load(tmp);
            Check("新目录返回空列表", list.Count == 0);

            var a = new AccountEntry
            {
                Id = "test1",
                DisplayName = "离线玩家",
                AuthType = "offline",
                Username = "Player"
            };
            AccountStore.Upsert(tmp, a);

            var loaded = AccountStore.Load(tmp);
            Check("保存后加载 1 条", loaded.Count == 1);
            Check("条目属性正确", loaded[0].Id == "test1" && loaded[0].AuthType == "offline");
            Check("自动设置 lastUsed", !string.IsNullOrEmpty(loaded[0].LastUsed));

            var lu = AccountStore.GetLastUsed(tmp);
            Check("GetLastUsed 返回正确", lu is not null && lu.Id == "test1");

            AccountStore.Remove(tmp, "test1");
            Check("删除后为空", AccountStore.Load(tmp).Count == 0);
        }
        finally
        {
            if (Directory.Exists(tmp)) Directory.Delete(tmp, true);
        }
    }

    private static void LaunchOptionsAndAuthVars()
    {
        Console.WriteLine("[LaunchOptions 扩展字段]");
        var options = new LaunchOptions
        {
            UserType = "msa",
            UserProperties = "{\"prop\":\"value\"}",
            ExtraJvmArgs = new List<string> { "-XX:+UseZGC" }
        };
        Check("UserType msa", options.UserType == "msa");
        Check("UserProperties 非空", options.UserProperties != "{}");
        Check("ExtraJvmArgs 有值", options.ExtraJvmArgs.Count == 1);
    }

    private static void RepairEngineTest()
    {
        Console.WriteLine("[崩溃修复规划引擎]");
        var gameRoot = Path.Combine(Path.GetTempPath(), "mclcs_repair_" + Guid.NewGuid().ToString("N"));

        // 内存不足，当前 2048MB -> 应调大到 4096MB
        var oom = new CrashAnalysis { Category = CrashCategory.OutOfMemory };
        var planOom = CrashRepairEngine.BuildPlan(oom, new LauncherProfile { MaxMemoryMb = 2048 }, null, gameRoot, "1.20.1");
        Check("OOM 可自动修复", planOom.CanRepair);
        Check("OOM 策略=调大内存", planOom.Strategy == RepairStrategy.IncreaseMemory);
        Check("OOM 目标内存=4096", planOom.TargetMemoryMb == 4096);
        Check("OOM 非破坏性", planOom.NonDestructive);

        // 内存已到上限 -> 不可再调
        var oomMax = new CrashAnalysis { Category = CrashCategory.OutOfMemory };
        var planMax = CrashRepairEngine.BuildPlan(oomMax, new LauncherProfile { MaxMemoryMb = GameConstants.MaxRepairMemoryMb }, null, gameRoot, "1.20.1");
        Check("OOM 达上限不可修复", !planMax.CanRepair);

        // Java 版本不匹配，需要 Java 21
        var java = new CrashAnalysis { Category = CrashCategory.JavaVersion, RequiredJavaMajor = 21 };
        var planJava = CrashRepairEngine.BuildPlan(java, new LauncherProfile(), null, gameRoot, "1.20.1");
        Check("Java 版本可自动修复", planJava.CanRepair);
        Check("Java 策略=切换Java", planJava.Strategy == RepairStrategy.SwitchJava);
        Check("Java 需要 21", planJava.RequiredJavaMajor == 21);

        // 缺少库，给定版本 -> 重新下载
        var miss = new CrashAnalysis { Category = CrashCategory.MissingLibrary };
        var planMiss = CrashRepairEngine.BuildPlan(miss, new LauncherProfile(), null, gameRoot, "1.20.1");
        Check("缺失库可自动修复", planMiss.CanRepair);
        Check("缺失库策略=重下库", planMiss.Strategy == RepairStrategy.RedownloadLibraries);
        Check("缺失库版本正确", planMiss.VersionId == "1.20.1");

        // 缺失库但无版本 -> 不可修复
        var missNoVer = new CrashAnalysis { Category = CrashCategory.MissingLibrary };
        Check("缺失库无版本不可修复", !CrashRepairEngine.BuildPlan(missNoVer, new LauncherProfile(), null, gameRoot, null).CanRepair);

        // OpenGL / 未知 -> 不可自动修复
        var gl = new CrashAnalysis { Category = CrashCategory.OpenGL };
        Check("OpenGL 不可自动修复", !CrashRepairEngine.BuildPlan(gl, new LauncherProfile(), null, gameRoot, "1.20.1").CanRepair);
        var unk = new CrashAnalysis { Category = CrashCategory.Unknown };
        Check("Unknown 不可自动修复", !CrashRepairEngine.BuildPlan(unk, new LauncherProfile(), null, gameRoot, "1.20.1").CanRepair);

        // 分析器：从类版本反推所需 Java
        var uvc = CrashAnalyzer.Analyze("java.lang.UnsupportedClassVersionError: class file version 65.0");
        Check("类版本 65 -> 需要 Java 21", uvc.RequiredJavaMajor == 21);
        Check("RawReport 可赋值", (uvc.RawReport = "x") == "x");

        // 策略枚举默认值
        Check("RepairPolicy 默认 Ask", new LauncherProfile().RepairPolicy == CrashRepairPolicy.Ask);
    }

    private static void ModpackIndexParsing()
    {
        Console.WriteLine("[整合包索引解析]");
        var json = @"{
            ""formatVersion"": 1,
            ""game"": ""minecraft"",
            ""versionId"": ""1.20.1"",
            ""name"": ""Test Pack"",
            ""dependencies"": { ""minecraft"": ""1.20.1"", ""fabric-loader"": ""0.15.0"" },
            ""files"": [
                {
                    ""path"": ""mods/sodium.jar"",
                    ""env"": { ""client"": ""required"", ""server"": ""unsupported"" },
                    ""hashes"": { ""sha1"": ""abc123"", ""sha512"": ""def456"" },
                    ""downloads"": [""https://example.com/sodium.jar""],
                    ""fileSize"": 123456
                }
            ]
        }";
        var index = JsonSerializer.Deserialize<ModrinthPackIndex>(json);
        Check("formatVersion 1", index is not null && index.FormatVersion == 1);
        Check("name Test Pack", index!.Name == "Test Pack");
        Check("dependencies 含 fabric-loader", index.Dependencies.ContainsKey("fabric-loader"));
        Check("1 个 file", index.Files.Count == 1);
        Check("file client=required", index.Files[0].Env.Client == "required");
        Check("downloads URL", index.Files[0].Downloads[0] == "https://example.com/sodium.jar");
    }

    private static void ModrinthModelDeserialization()
    {
        Console.WriteLine("[Modrinth 模型反序列化]");
        var projJson = @"{""id"":""abc"",""slug"":""sodium"",""title"":""Sodium"",""description"":""Fast"",""body"":""..."",""project_type"":""mod"",""game_versions"":[""1.20.1""],""loaders"":[""fabric""],""downloads"":999,""icon_url"":""https://icon.png"",""gallery"":[]}";
        var proj = JsonSerializer.Deserialize<ModrinthProject>(projJson);
        Check("ModrinthProject title", proj is not null && proj.Title == "Sodium");

        var depJson = @"[{""version_id"":null,""project_id"":""fabric-api"",""file_name"":null,""dependency_type"":""required""}]";
        var deps = JsonSerializer.Deserialize<List<ModrinthDependency>>(depJson);
        Check("dependency type=required", deps is not null && deps[0].DependencyType == "required");

        // LoaderType.NeoForge
        Check("NeoForge loader string", ModrinthClient.LoaderString(LoaderType.NeoForge) == "neoforge");
    }

    // ---- v0.3 新增测试 ----

    private static void CurseForgeModels()
    {
        Console.WriteLine("[CurseForge 模型反序列化]");
        var manifestJson = @"{
            ""minecraft"": { ""version"": ""1.20.1"", ""modLoaders"": [{""id"":""fabric-0.15.0"",""primary"":true}] },
            ""manifestType"": ""minecraftModpack"",
            ""manifestVersion"": 1,
            ""name"": ""Test CF Pack"",
            ""version"": ""1.0"",
            ""author"": ""Author"",
            ""files"": [{""projectID"":123,""fileID"":456,""required"":true}],
            ""overrides"": ""overrides""
        }";
        var manifest = JsonSerializer.Deserialize<CurseForgeManifest>(manifestJson);
        Check("CF manifest name", manifest is not null && manifest.Name == "Test CF Pack");
        Check("CF mc version", manifest!.Minecraft.Version == "1.20.1");
        Check("CF fabric loader", manifest.Minecraft.ModLoaders[0].Id == "fabric-0.15.0");
        Check("CF 1 file", manifest.Files.Count == 1);
        Check("CF file projectID", manifest.Files[0].ProjectId == 123);
    }

    private static void LocalizationTest()
    {
        Console.WriteLine("[多语言管理]");
        Check("默认 zh_CN", LocaleManager.CurrentLocale == "zh_CN");
        Check("T(app.title) zh", LocaleManager.T("app.title") == "MCLCS 启动器");

        LocaleManager.CurrentLocale = "en_US";
        Check("T(app.title) en", LocaleManager.T("app.title") == "MCLCS Launcher");
        Check("T(不存在) fallback", LocaleManager.T("nonexistent_key") == "nonexistent_key");

        LocaleManager.CurrentLocale = "zh_CN"; // 恢复
        Check("Tf 格式化", LocaleManager.Tf("msg.launching", "1.20.1").Contains("1.20.1"));
    }

    private static void SkinFetcherTest()
    {
        Console.WriteLine("[皮肤解析]");
        // 模拟 textures Base64
        var texturesJson = @"{""textures"":{""SKIN"":{""url"":""https://example.com/skin.png"",""metadata"":{""model"":""slim""}},""CAPE"":{""url"":""https://example.com/cape.png""}}}";
        var b64 = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(texturesJson));
        var profile = new MinecraftProfile
        {
            Id = "abc",
            Name = "TestPlayer",
            Properties = new List<ProfileProperty> { new() { Name = "textures", Value = b64 } }
        };
        // 使用反射调用私有方法测试（这里只测模型绑定）
        Check("Profile name", profile.Name == "TestPlayer");
        Check("Profile has textures", profile.Properties.Any(p => p.Name == "textures"));
    }

    private static void ThemeManagerTest()
    {
        Console.WriteLine("[主题管理]");
        var initial = ThemeManager.Current;
        Check("默认暗色", initial == ThemeType.Dark);

        ThemeManager.Current = ThemeType.Light;
        Check("切换亮色", ThemeManager.Current == ThemeType.Light);

        ThemeManager.Current = ThemeType.Dark;
        Check("切回暗色", ThemeManager.Current == ThemeType.Dark);
    }

    private static void ModMetadataParserTest()
    {
        Console.WriteLine("[Mod 元数据解析]");

        // 测试 TOML 解析
        var toml = @"
[[mods]]
modId=""examplemod""
displayName=""Example Mod""
version=""1.0.0""

[[dependencies.examplemod]]
modId=""fabric-api""
mandatory=true
versionRange=""[0.92,1.0)""
ordering=""NONE""
side=""BOTH""
";
        var meta = ModMetadataParser.ParseForgeMod("nonexistent.jar"); // 文件不存在返回 null
        Check("不存在的jar返回null", meta is null);

        // 测试 DependencyCheckResult 模型
        var result = new DependencyCheckResult
        {
            ModFileName = "test.jar",
            ModId = "testmod",
            ModName = "Test Mod",
            Missing = { new MissingDependency { DependencyId = "dep1", VersionRange = ">=1.0", Required = true } }
        };
        Check("依赖检查 Missing 1", result.Missing.Count == 1);
        Check("依赖检查 dep1", result.Missing[0].DependencyId == "dep1");
    }

    // ---- v0.5 新增测试 ----

    private static void RecommendationSystemTest()
    {
        Console.WriteLine("[智能推荐系统 v0.5]");

        // 玩法分区映射
        Check("technology → Tech", GameplayCategoryMap.FromModrinthCategories(new[] { "technology" }) == GameplayCategory.Tech);
        Check("magic → Magic", GameplayCategoryMap.FromModrinthCategories(new[] { "magic" }) == GameplayCategory.Magic);
        Check("未识别 → null", GameplayCategoryMap.FromModrinthCategories(new[] { "xyz" }) is null);
        Check("Tech 展示名=生电", GameplayCategoryMap.DisplayName(GameplayCategory.Tech) == "生电");
        Check("All 含 6 个分区", GameplayCategoryMap.All.Count == 6);
        Check("ToModrinth Tech=technology", GameplayCategoryMap.ToModrinthCategory(GameplayCategory.Tech) == "technology");

        // 规则引擎：Fabric 已装但无 API + 存在光影包但无 Iris
        var root = Path.Combine(Path.GetTempPath(), "mclcs_rec_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(root);
            var sp = PathEx.ShaderPacksDir(root);
            Directory.CreateDirectory(sp);
            File.WriteAllText(Path.Combine(sp, "test.zip"), "dummy");

            var installed = new List<ModEntry>
            {
                new() { ModId = "sodium", Loader = "fabric", FileName = "sodium.jar" }
            };
            var rules = RuleEngine.EvaluateLocalRules(root, installed);
            Check("规则推荐 Fabric API", rules.Any(r => r.Slug == "fabric-api" && r.IsDependencyCompletion));
            Check("规则推荐 Iris", rules.Any(r => r.Slug == "iris" && r.IsDependencyCompletion));

            // 已装 Fabric API + Iris → 不再推荐
            var installed2 = new List<ModEntry>
            {
                new() { ModId = "fabric-api", Loader = "fabric", FileName = "fabric-api.jar" },
                new() { ModId = "iris", Loader = "fabric", FileName = "iris.jar" }
            };
            var rules2 = RuleEngine.EvaluateLocalRules(root, installed2);
            Check("已装 API+Ir is 时无推荐", rules2.Count == 0);
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }

        // 推荐引擎：Disabled → 空；LocalOnly + 玩法偏好过滤
        var profileDisabled = new LauncherProfile { IntelliRecommend = IntelliRecommendMode.Disabled };
        var empty = RecommendationEngine.BuildAsync(GameConstants.DefaultGameRoot, profileDisabled,
            new HttpClient(), null).GetAwaiter().GetResult();
        Check("Disabled 返回空", empty.Count == 0);

        var profileLocal = new LauncherProfile
        {
            IntelliRecommend = IntelliRecommendMode.LocalOnly,
            PreferredCategories = new() { GameplayCategory.Tech } // 只关心生电
        };
        // LocalOnly 不联网，仅本地规则；用含 Fabric 的假环境
        var root2 = Path.Combine(Path.GetTempPath(), "mclcs_rec2_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(root2);
            var localItems = RuleEngine.EvaluateLocalRules(root2, new List<ModEntry> { new() { ModId = "x", Loader = "fabric" } });
            // 依赖补全类（fabric-api → Tech）应保留；若偏好只选 Tech 则 iris(Optimization) 被过滤——但规则引擎不过滤，过滤在引擎
            Check("本地规则含 fabric-api", localItems.Any(i => i.Slug == "fabric-api"));
        }
        finally
        {
            if (Directory.Exists(root2)) Directory.Delete(root2, true);
        }

        // 热门榜单缓存：写入缓存后可命中（不联网）
        var root3 = Path.Combine(Path.GetTempPath(), "mclcs_rec3_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(root3);
            var cached = new List<RecommendationItem>
            {
                new() { Slug = "sodium", Title = "Sodium", Category = GameplayCategory.Optimization }
            };
            // 直接写缓存（通过反射私有方法不便，这里用公开路径约定复刻）
            var cacheDir = Path.Combine(root3, "cache");
            Directory.CreateDirectory(cacheDir);
            var payload = new { CachedAt = DateTime.UtcNow, Items = cached };
            File.WriteAllText(Path.Combine(cacheDir, "mclcs_hot_any_Any_all.json"),
                System.Text.Json.JsonSerializer.Serialize(payload));

            var hot = HotRanking.GetHotAsync(new HttpClient(), root3, null, LoaderType.Any, null, ct: CancellationToken.None)
                .GetAwaiter().GetResult();
            Check("榜单命中本地缓存", hot.Count == 1 && hot[0].Slug == "sodium");
        }
        finally
        {
            if (Directory.Exists(root3)) Directory.Delete(root3, true);
        }
    }

    /// <summary>无网络下载器（仅用于离线测试）。</summary>
    private class NoopDownloader : IDownloader
    {
        public Task DownloadAsync(DownloadItem item, IProgress<double>? progress = null, CancellationToken ct = default)
            => Task.CompletedTask;
        public Task DownloadBatchAsync(IEnumerable<DownloadItem> items, IProgress<(int Done, int Total)>? progress = null, CancellationToken ct = default)
            => Task.CompletedTask;
    }

    private static async Task LibraryRepairTest()
    {
        Console.WriteLine("[库修复 LibraryRepair]");
        var root = Path.Combine(Path.GetTempPath(), "mclcs_librepair_" + Guid.NewGuid().ToString("N"));
        var downloader = new NoopDownloader();
        try
        {
            var vdir = Path.Combine(root, "versions", "1.20.1");
            Directory.CreateDirectory(vdir);
            var version = new VersionJson { Id = "1.20.1", Libraries = new() };
            await File.WriteAllTextAsync(Path.Combine(vdir, "1.20.1.json"),
                JsonSerializer.Serialize(version));

            // 无库版本：无需下载，所有库健康（FixedCount=0）
            var ok = await LibraryRepair.RepairAsync(root, "1.20.1", new HttpClient(), downloader, null);
            Check("无库版本 AllHealthy", ok.AllHealthy);
            Check("无库版本 FixedCount=0", ok.FixedCount == 0);

            // 不存在的版本：返回失败
            var fail = await LibraryRepair.RepairAsync(root, "9.9.9", new HttpClient(), downloader, null);
            Check("不存在版本 Success=false", !fail.Success);
            Check("不存在版本 AllHealthy=false", !fail.AllHealthy);
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }
        await Task.CompletedTask;
    }

    private static void CrashRepairModelsV05Test()
    {
        Console.WriteLine("[崩溃修复模型 v0.5]");

        // ModConflictInfo
        var conflict = new ModConflictInfo
        {
            FilePath = "/mods/sodium.jar",
            Name = "Sodium"
        };
        Check("ModConflictInfo FilePath", conflict.FilePath == "/mods/sodium.jar");
        Check("ModConflictInfo Name", conflict.Name == "Sodium");

        // RepairStrategy 新枚举值
        Check("DisableConflictingMods 枚举值", RepairStrategy.DisableConflictingMods.ToString() == "DisableConflictingMods");
        Check("InstallMissingModDependency 枚举值", RepairStrategy.InstallMissingModDependency.ToString() == "InstallMissingModDependency");

        // CrashRepairPlan 新字段
        var plan = new CrashRepairPlan();
        Check("ConflictingMods 初始为空", plan.ConflictingMods.Count == 0);
        Check("MissingModDependencies 初始为空", plan.MissingModDependencies.Count == 0);
        Check("KeepModFile 初始为 null", plan.KeepModFile is null);

        plan.ConflictingMods.Add(new ModConflictInfo { FilePath = "/mods/a.jar", Name = "A" });
        plan.ConflictingMods.Add(new ModConflictInfo { FilePath = "/mods/b.jar", Name = "B" });
        Check("ConflictingMods 添加后 2 个", plan.ConflictingMods.Count == 2);

        plan.MissingModDependencies.Add("fabric-api");
        plan.MissingModDependencies.Add("cloth-config");
        Check("MissingModDependencies 添加后 2 个", plan.MissingModDependencies.Count == 2);
        Check("MissingModDependencies 含 fabric-api", plan.MissingModDependencies.Contains("fabric-api"));
    }

    private static void JavaVendorTest()
    {
        Console.WriteLine("[JavaVendor 枚举 & Oracle 安装模型]");

        // 枚举值
        Check("JavaVendor.Auto", JavaVendor.Auto.ToString() == "Auto");
        Check("JavaVendor.Temurin", JavaVendor.Temurin.ToString() == "Temurin");
        Check("JavaVendor.Oracle", JavaVendor.Oracle.ToString() == "Oracle");

        // 默认值
        var profile = new LauncherProfile();
        Check("Profile 默认 PreferredJavaVendor = Auto", profile.PreferredJavaVendor == JavaVendor.Auto);

        // JavaInstaller 静态方法存在
        var ensureMethod = typeof(JavaInstaller).GetMethod("EnsureJavaAsync",
            new[] { typeof(int), typeof(string), typeof(IDownloader), typeof(JavaVendor), typeof(ILogger), typeof(CancellationToken) });
        Check("JavaInstaller.EnsureJavaAsync(JavaVendor) 方法存在", ensureMethod is not null);

        // Oracle 方法存在（public static）
        var oracleMethod = typeof(JavaInstaller).GetMethod("InstallOracleAsync",
            System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
        Check("JavaInstaller.InstallOracleAsync 方法存在", oracleMethod is not null);
    }

    private static void AutoInstallPolicyTest()
    {
        Console.WriteLine("[AutoInstallPolicy 枚举]");

        Check("AutoInstallPolicy.Always", AutoInstallPolicy.Always.ToString() == "Always");
        Check("AutoInstallPolicy.Ask", AutoInstallPolicy.Ask.ToString() == "Ask");
        Check("AutoInstallPolicy.Never", AutoInstallPolicy.Never.ToString() == "Never");

        var profile = new LauncherProfile();
        Check("Profile 默认 AutoInstallMissingMods = Ask", profile.AutoInstallMissingMods == AutoInstallPolicy.Ask);
    }

    private static void ModConflictPlanTest()
    {
        Console.WriteLine("[Mod 冲突修复规划]");

        var gameRoot = Path.Combine(Path.GetTempPath(), "mclcs_conflict_" + Guid.NewGuid().ToString("N"));
        try
        {
            // 创建一个无 mods 目录的环境，测试非 OOM/非 Java 的崩溃也能产出 plan
            Directory.CreateDirectory(gameRoot);
            var modsDir = Path.Combine(gameRoot, "mods");
            Directory.CreateDirectory(modsDir);

            // 非 OOM/Java 的崩溃（如 ClassNotFoundException），应尝试检测 mod 问题
            var cnf = new CrashAnalysis { Category = CrashCategory.MissingLibrary };
            var plan = CrashRepairEngine.BuildPlan(cnf, new LauncherProfile(), null, gameRoot, "1.20.1");

            // 在没有 mod 冲突/缺失依赖的情况下，不应产出冲突或缺失计划
            Check("无冲突时 ConflictingMods 为空", plan.ConflictingMods.Count == 0);
            Check("无缺失时 MissingModDependencies 为空", plan.MissingModDependencies.Count == 0);
        }
        finally
        {
            if (Directory.Exists(gameRoot)) Directory.Delete(gameRoot, true);
        }
    }

    private static void ProfileV05Test()
    {
        Console.WriteLine("[LauncherProfile v0.5 序列化]");

        var profile = new LauncherProfile
        {
            PreferredJavaVendor = JavaVendor.Oracle,
            AutoInstallMissingMods = AutoInstallPolicy.Always
        };

        var json = JsonSerializer.Serialize(profile);
        Check("序列化含 preferredJavaVendor", json.Contains("preferredJavaVendor"));
        Check("序列化含 autoInstallMissingMods", json.Contains("autoInstallMissingMods"));

        var deserialized = JsonSerializer.Deserialize<LauncherProfile>(json);
        Check("反序列化 PreferredJavaVendor = Oracle", deserialized?.PreferredJavaVendor == JavaVendor.Oracle);
        Check("反序列化 AutoInstallMissingMods = Always", deserialized?.AutoInstallMissingMods == AutoInstallPolicy.Always);
    }

    // ---- §二.4 / §三 / §四.2 存档兼容性、降级、降级联动 ----

    /// <summary>构造一个最小 level.dat（gzip NBT，含 DataVersion）。</summary>
    private static void WriteLevelDat(string saveDir, int dataVersion)
    {
        Directory.CreateDirectory(saveDir);
        var root = NbtTag.Compound("");
        var data = NbtTag.Compound("Data");
        data.Children!.Add(NbtTag.Int("GameType", 0));
        root.Children!.Add(data);
        root.Children.Add(NbtTag.Int("DataVersion", dataVersion));
        NbtFile.WriteGzip(SaveCompatibilityDetector.LevelDatPath(saveDir), root);
    }

    private static async Task SaveFeatureTests()
    {
        Console.WriteLine("[NBT 读写往返]");
        NbtRoundTripTest();
        Console.WriteLine("[DataVersion 对照表]");
        DataVersionMapTest();
        Console.WriteLine("[§二.4 存档兼容性检测]");
        SaveCompatTest();
        Console.WriteLine("[§三 存档降级 + 备份回滚]");
        await SaveDowngradeTest();
        Console.WriteLine("[§四.2 降级联动]");
        DowngradeLinkageTest();
    }

    private static void NbtRoundTripTest()
    {
        var root = NbtTag.Compound("root");
        var c = NbtTag.Compound("c");
        c.Children!.Add(NbtTag.Int("DataVersion", 3465));
        c.Children.Add(new NbtTag { Type = NbtTagType.Byte, Name = "b", ByteValue = 5 });
        c.Children.Add(new NbtTag { Type = NbtTagType.Short, Name = "s", ShortValue = 1234 });
        c.Children.Add(new NbtTag { Type = NbtTagType.Long, Name = "l", LongValue = 12345678901L });
        c.Children.Add(new NbtTag { Type = NbtTagType.Float, Name = "f", FloatValue = 3.14f });
        c.Children.Add(new NbtTag { Type = NbtTagType.Double, Name = "d", DoubleValue = 2.718281828 });
        c.Children.Add(new NbtTag { Type = NbtTagType.String, Name = "str", StringValue = "你好nbt" });
        c.Children.Add(new NbtTag { Type = NbtTagType.ByteArray, Name = "ba", ByteArrayValue = new byte[] { 1, 2, 3 } });
        c.Children.Add(new NbtTag { Type = NbtTagType.IntArray, Name = "ia", IntArrayValue = new[] { 10, 20, 30 } });
        c.Children.Add(new NbtTag { Type = NbtTagType.LongArray, Name = "la", LongArrayValue = new[] { 100L, 200L } });
        var list = new NbtTag { Type = NbtTagType.List, Name = "list", Children = new List<NbtTag> { NbtTag.Int("x", 7), NbtTag.Int("y", 8) } };
        c.Children.Add(list);
        root.Children!.Add(c);

        using var ms = new MemoryStream();
        using (var gzip = new GZipStream(ms, CompressionMode.Compress, leaveOpen: true))
            NbtFile.Write(gzip, root);

        // 先用原始流隔离（排除 gzip 影响）
        using var raw = new MemoryStream();
        NbtFile.Write(raw, root);
        raw.Position = 0;
        var rawBack = NbtFile.Read(raw);
        Check("原始流往返 Int DataVersion=3465", rawBack.GetChild("c")!.GetChild("DataVersion")!.IntValue == 3465);

        ms.Position = 0;
        using var ingzip = new GZipStream(ms, CompressionMode.Decompress);
        var back = NbtFile.Read(ingzip);

        Check("根名 root", back.Name == "root");
        var rc = back.GetChild("c")!;
        Check("Int DataVersion=3465", rc.GetChild("DataVersion")!.IntValue == 3465);
        Check("Byte=5", rc.GetChild("b")!.ByteValue == 5);
        Check("Short=1234", rc.GetChild("s")!.ShortValue == 1234);
        Check("Long 往返", rc.GetChild("l")!.LongValue == 12345678901L);
        Check("Float 往返", Math.Abs(rc.GetChild("f")!.FloatValue - 3.14f) < 1e-6);
        Check("Double 往返", Math.Abs(rc.GetChild("d")!.DoubleValue - 2.718281828) < 1e-12);
        Check("String 往返", rc.GetChild("str")!.StringValue == "你好nbt");
        Check("ByteArray 往返", ((ReadOnlySpan<byte>)rc.GetChild("ba")!.ByteArrayValue!).SequenceEqual(new byte[] { 1, 2, 3 }));
        Check("IntArray 往返", rc.GetChild("ia")!.IntArrayValue!.SequenceEqual(new[] { 10, 20, 30 }));
        Check("LongArray 往返", rc.GetChild("la")!.LongArrayValue!.SequenceEqual(new[] { 100L, 200L }));
        Check("List 元素类型 Int", rc.GetChild("list")!.Children![0].Type == NbtTagType.Int);
        Check("List 元素值 7/8", rc.GetChild("list")!.Children![0].IntValue == 7 && rc.GetChild("list")!.Children![1].IntValue == 8);

        // 递归读取 DataVersion（与 level.dat 用法一致）
        Check("GetDataVersion 递归=3465", back.GetDataVersion() == 3465);

        // 改写 DataVersion 后再次往返
        back.TrySetDataVersion(3337);
        using var ms2 = new MemoryStream();
        using (var g2 = new GZipStream(ms2, CompressionMode.Compress, leaveOpen: true))
            NbtFile.Write(g2, back);
        ms2.Position = 0;
        using var ig2 = new GZipStream(ms2, CompressionMode.Decompress);
        Check("改写后 GetDataVersion=3337", NbtFile.Read(ig2).GetDataVersion() == 3337);
    }

    private static void DataVersionMapTest()
    {
        Check("1.20.1 -> 3465", DataVersionMap.ToDataVersion("1.20.1") == 3465);
        Check("1.19.4 -> 3337", DataVersionMap.ToDataVersion("1.19.4") == 3337);
        Check("1.21.8 -> 4440", DataVersionMap.ToDataVersion("1.21.8") == 4440);
        Check("1.12.2 -> 1343", DataVersionMap.ToDataVersion("1.12.2") == 1343);
        Check("fabric-1.20.1 去前缀 -> 3465", DataVersionMap.ToDataVersion("fabric-1.20.1") == 3465);
        Check("dv 3465 -> 1.20.1", DataVersionMap.ToGameVersion(3465) == "1.20.1");
        Check("dv 4440 -> 1.21.8", DataVersionMap.ToGameVersion(4440) == "1.21.8");
        Check("未知版本 -> null", DataVersionMap.ToDataVersion("99.99.99") is null);
        Check("KnownVersions 升序且含 1.20.1", DataVersionMap.KnownVersions().First() == "1.12.2" && DataVersionMap.KnownVersions().Contains("1.20.1"));

        // ---- 新命名方案 YY.M ----
        Check("26.1 -> 4786", DataVersionMap.ToDataVersion("26.1") == 4786);
        Check("26.1.2 -> 4790", DataVersionMap.ToDataVersion("26.1.2") == 4790);
        Check("26.2 -> 4903", DataVersionMap.ToDataVersion("26.2") == 4903);
        Check("1.21.11 -> 4671", DataVersionMap.ToDataVersion("1.21.11") == 4671);
        Check("fabric-26.1 去前缀 -> 4786", DataVersionMap.ToDataVersion("fabric-26.1") == 4786);
        Check("dv 4786 -> 26.1", DataVersionMap.ToGameVersion(4786) == "26.1");
        Check("dv 4903 -> 26.2", DataVersionMap.ToGameVersion(4903) == "26.2");
        Check("比较 26.1 < 26.2", DataVersionMap.CompareVersions("26.1", "26.2") < 0);
        Check("比较 1.21.11 < 26.1", DataVersionMap.CompareVersions("1.21.11", "26.1") < 0);
        Check("KnownVersions 含 26.1 与 26.2", DataVersionMap.KnownVersions().Contains("26.1") && DataVersionMap.KnownVersions().Contains("26.2"));
    }

    private static void SaveCompatTest()
    {
        var root = Path.Combine(Path.GetTempPath(), "mclcs_selftest_saves_" + Guid.NewGuid().ToString("N"));
        try
        {
            var saves = SaveCompatibilityDetector.SavesDir(root);
            // 略高版本存档（1.20.2, dv=3578）启动 1.20.1（dv=3465）→ 不兼容、轻微
            WriteLevelDat(Path.Combine(saves, "NewWorld"), 3578);
            // 兼容存档（1.12.2, dv=1343）启动 1.20.1 → 兼容
            WriteLevelDat(Path.Combine(saves, "OldWorld"), 1343);

            var reports = SaveCompatibilityDetector.Scan(root, "1.20.1");
            var newW = reports.First(r => r.SaveName == "NewWorld");
            var oldW = reports.First(r => r.SaveName == "OldWorld");

            Check("NewWorld 不兼容", !newW.Compatible);
            Check("NewWorld 严重程度 SlightlyNewer", newW.Severity == SaveCompatibilitySeverity.SlightlyNewer);
            Check("NewWorld 建议降级", newW.RecommendedAction == SaveCompatAction.Downgrade);
            Check("NewWorld 反查版本 1.20.2", newW.SaveGameVersion == "1.20.2");

            Check("OldWorld 兼容", oldW.Compatible);
            Check("OldWorld 严重度 Ok", oldW.Severity == SaveCompatibilitySeverity.Ok);

            // 跨大版本：1.21.8（dv=4440）启动 1.19（dv=3105）→ 不兼容、严重
            WriteLevelDat(Path.Combine(saves, "FutureWorld"), 4440);
            var futReport = SaveCompatibilityDetector.CheckSingleSave(Path.Combine(saves, "FutureWorld"), "1.19");
            Check("FutureWorld 不兼容", futReport is not null && !futReport.Compatible);
            Check("FutureWorld 严重程度 MuchNewer", futReport is not null && futReport.Severity == SaveCompatibilitySeverity.MuchNewer);

            // 未知目标版本：保守视为兼容
            var unknown = SaveCompatibilityDetector.CheckSingleSave(Path.Combine(saves, "NewWorld"), "99.99.99");
            Check("未知目标版本 -> 兼容/Unknown", unknown!.Compatible && unknown.Severity == SaveCompatibilitySeverity.Unknown);

            // ---- 新命名方案 YY.M ----
            // 26.2（dv=4903）存档启动 26.1（dv=4786）→ 不兼容、轻微（仅隔 1 个月）
            WriteLevelDat(Path.Combine(saves, "NewSchemeWorld"), 4903);
            var nsReport = SaveCompatibilityDetector.CheckSingleSave(Path.Combine(saves, "NewSchemeWorld"), "26.1");
            Check("NewSchemeWorld 不兼容", nsReport is not null && !nsReport.Compatible);
            Check("NewSchemeWorld 严重程度 SlightlyNewer", nsReport is not null && nsReport.Severity == SaveCompatibilitySeverity.SlightlyNewer);
            Check("NewSchemeWorld 反查版本 26.2", nsReport is not null && nsReport.SaveGameVersion == "26.2");

            // 新方案跨月较多：26.3（dv=5005）存档启动 26.1（dv=4786）→ 不兼容、严重（隔 2 个月）
            WriteLevelDat(Path.Combine(saves, "MuchNewerNew"), 5005);
            var mnReport = SaveCompatibilityDetector.CheckSingleSave(Path.Combine(saves, "MuchNewerNew"), "26.1");
            Check("MuchNewerNew 不兼容", mnReport is not null && !mnReport.Compatible);
            Check("MuchNewerNew 严重程度 MuchNewer", mnReport is not null && mnReport.Severity == SaveCompatibilitySeverity.MuchNewer);

            // 旧方案 -> 新方案（跨命名方案）：26.1（dv=4786）存档启动 1.21.11（dv=4671）→ 不兼容、严重
            WriteLevelDat(Path.Combine(saves, "CrossSchemeWorld"), 4786);
            var csReport = SaveCompatibilityDetector.CheckSingleSave(Path.Combine(saves, "CrossSchemeWorld"), "1.21.11");
            Check("CrossSchemeWorld 不兼容", csReport is not null && !csReport.Compatible);
            Check("CrossSchemeWorld 严重程度 MuchNewer", csReport is not null && csReport.Severity == SaveCompatibilitySeverity.MuchNewer);
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, recursive: true);
        }
    }

    private static async Task SaveDowngradeTest()
    {
        var root = Path.Combine(Path.GetTempPath(), "mclcs_selftest_down_" + Guid.NewGuid().ToString("N"));
        try
        {
            var saves = SaveCompatibilityDetector.SavesDir(root);
            var saveDir = Path.Combine(saves, "MyWorld");
            WriteLevelDat(saveDir, 3465); // 1.20.1

            Check("降级前 GetSaveDataVersion=3465", SaveDowngrader.GetSaveDataVersion(saveDir) == 3465);

            // 方案 A：快速降级到 1.19.4 (dv=3337)
            var plan = await SaveDowngrader.DowngradeAsync(saveDir, "1.19.4", DowngradeMethod.QuickModifyDataVersion);
            Check("降级成功", plan.Success);
            Check("降级 From=3465 To=3337", plan.FromDataVersion == 3465 && plan.ToDataVersion == 3337);
            Check("强制备份已创建", plan.BackupPath is not null && Directory.Exists(plan.BackupPath));
            Check("降级后 DataVersion=3337", SaveDowngrader.GetSaveDataVersion(saveDir) == 3337);
            Check("变更摘要非空", plan.Summary.Count > 0);

            // 原始存档完好（备份存在且仍为 1.20.1）
            var backups = SaveCompatibilityDetector.FindBackups(saves, "MyWorld");
            Check("找到 1 个备份", backups.Count == 1);
            Check("备份 DataVersion 仍为 3465", backups[0].DataVersion == 3465);
            Check("备份 GameVersion=1.20.1", backups[0].GameVersion == "1.20.1");

            // 回滚到备份
            var replaced = SaveDowngrader.RestoreBackupAsync(backups[0].BackupPath, saveDir);
            Check("回滚后 DataVersion 恢复 3465", SaveDowngrader.GetSaveDataVersion(saveDir) == 3465);
            Check("回滚时另存了 replaced 目录", !string.IsNullOrEmpty(replaced) && Directory.Exists(replaced));

            // 方案 B：Amulet 未安装时应优雅失败（不抛异常）
            var planB = await SaveDowngrader.DowngradeAsync(saveDir, "1.19.4", DowngradeMethod.Amulet);
            Check("Amulet 缺失时降级失败但安全", !planB.Success && planB.ErrorMessage is not null);
            Check("Amulet 失败仍保留备份", SaveCompatibilityDetector.FindBackups(saves, "MyWorld").Count >= 1);

            // ---- 新命名方案 YY.M 降级：26.2 (dv=4903) -> 26.1 (dv=4786) ----
            var newSaveDir = Path.Combine(saves, "NewSchemeWorld");
            WriteLevelDat(newSaveDir, 4903);
            Check("新方案降级前 GetSaveDataVersion=4903", SaveDowngrader.GetSaveDataVersion(newSaveDir) == 4903);
            var plan26 = await SaveDowngrader.DowngradeAsync(newSaveDir, "26.1", DowngradeMethod.QuickModifyDataVersion);
            Check("新方案降级成功", plan26.Success);
            Check("新方案降级 From=4903 To=4786", plan26.FromDataVersion == 4903 && plan26.ToDataVersion == 4786);
            Check("新方案降级后 DataVersion=4786", SaveDowngrader.GetSaveDataVersion(newSaveDir) == 4786);
            Check("新方案降级反查版本=26.1", SaveCompatibilityDetector.CheckSingleSave(newSaveDir, "1.21.8") is { } r26 && r26.SaveGameVersion == "26.1");
            Check("新方案降级已强制备份", plan26.BackupPath is not null && Directory.Exists(plan26.BackupPath));
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, recursive: true);
        }
    }

    private static void DowngradeLinkageTest()
    {
        var root = Path.Combine(Path.GetTempPath(), "mclcs_selftest_link_" + Guid.NewGuid().ToString("N"));
        try
        {
            var saves = SaveCompatibilityDetector.SavesDir(root);
            var saveDir = Path.Combine(saves, "LinkWorld");
            WriteLevelDat(saveDir, 3465);

            // 无备份：不适用
            var analysisNoBackup = new CrashAnalysis
            {
                Category = CrashCategory.Unknown,
                ExceptionType = "java.lang.RuntimeException",
                RawReport = "Caught exception in world tick: chunk ... NBT ..."
            };
            var noPlan = DowngradeCrashLinkage.BuildPlan(analysisNoBackup, saveDir, root);
            Check("无降级备份时降级联动不适用", !noPlan.Applicable);

            // 制造一次降级（生成备份）
            var down = SaveDowngrader.DowngradeAsync(saveDir, "1.19.4", DowngradeMethod.QuickModifyDataVersion).Result;

            // 世界相关崩溃 + 存在备份 → 适用
            var analysis = new CrashAnalysis
            {
                Category = CrashCategory.Unknown,
                ExceptionType = "java.lang.RuntimeException",
                RawReport = "Caught exception in world tick: Exception generating new chunk: NBT tag ... region file corrupt"
            };
            var plan = DowngradeCrashLinkage.BuildPlan(analysis, saveDir, root);
            Check("存在备份+世界崩溃 -> 适用", plan.Applicable);
            Check("建议动作=回滚备份", plan.SuggestedAction == DowngradeRecoveryAction.RevertToBackup);
            Check("选项含回滚/其他方式/安装原版", plan.Options.Contains(DowngradeRecoveryAction.RevertToBackup)
                && plan.Options.Contains(DowngradeRecoveryAction.TryOtherMethod)
                && plan.Options.Contains(DowngradeRecoveryAction.InstallOriginalVersion));
            Check("原始版本反查=1.20.1", plan.OriginalGameVersion == "1.20.1");
            Check("BackupPath 指向备份", plan.BackupPath is not null && System.Text.RegularExpressions.Regex.IsMatch(plan.BackupPath, @"\.backup-\d{14}$"));

            // 内存类崩溃（与降级无关）→ 不适用
            var memAnalysis = new CrashAnalysis
            {
                Category = CrashCategory.OutOfMemory,
                ExceptionType = "java.lang.OutOfMemoryError",
                RawReport = "Java heap space"
            };
            var memPlan = DowngradeCrashLinkage.BuildPlan(memAnalysis, saveDir, root);
            Check("内存崩溃不误判为降级联动", !memPlan.Applicable);

            // 接入 CrashRepairEngine：Unknown + 世界崩溃 → 生成含降级恢复的方案
            var profile = new LauncherProfile();
            var repair = CrashRepairEngine.BuildPlan(analysis, profile, null, root, "1.19.4", saveDir);
            Check("CrashRepairEngine 产出降级恢复方案", repair.CanRepair && repair.DowngradeRecovery is not null);
            Check("降级恢复策略=回滚备份", repair.Strategy == RepairStrategy.RevertDowngradeBackup);
        }
        finally
        {
            if (Directory.Exists(root)) Directory.Delete(root, recursive: true);
        }
    }

    // ---- v1.0 工具箱 / 统计 / AI / 更新 / 多开 模块 ----

    private static async Task ToolboxV1Tests()
    {
        Console.WriteLine("[LogManager 日志管理]");
        await LogManagerTest();
        Console.WriteLine("[SeedLibrary 种子库]");
        await SeedLibraryTest();
        Console.WriteLine("[ScreenshotManager 截图管理]");
        await ScreenshotManagerTest();
        Console.WriteLine("[NetworkDiagnostics 网络诊断]");
        await NetworkDiagnosticsTest();
        Console.WriteLine("[RedundantFileCleaner 冗余清理]");
        RedundantCleanerTest();
        Console.WriteLine("[ModpackExporter 整合包导出]");
        ModpackExportTest();
        Console.WriteLine("[PlaytimeTracker 游玩统计]");
        PlaytimeTrackerTest();
        Console.WriteLine("[Assistant AI 助手]");
        AssistantTest();
        Console.WriteLine("[LauncherUpdater 自动更新]");
        LauncherUpdaterTest();
        Console.WriteLine("[InstanceTracker 多开实例]");
        InstanceTrackerTest();
    }

    private static string TempDir(string name)
        => Path.Combine(Path.GetTempPath(), "mclcs_selftest_" + name + "_" + Guid.NewGuid().ToString("N"));

    private static async Task LogManagerTest()
    {
        var root = TempDir("logs");
        try
        {
            Directory.CreateDirectory(LogManager.LogsDir(root));
            var logPath = Path.Combine(LogManager.LogsDir(root), "latest.log");
            await File.WriteAllTextAsync(logPath,
                "[INFO] 启动游戏\n[ERROR] java.lang.OutOfMemoryError: Java heap space\n[WARN] 内存偏低");

            var files = LogManager.ListLogs(root);
            Check("ListLogs 含 latest.log", files.Any(f => f.Name == "latest.log"));

            var text = LogManager.ReadLog(logPath);
            Check("ReadLog 读回内容", text.Contains("OutOfMemoryError"));

            var lines = LogManager.ParseLines(text);
            Check("ParseLines 行数=3", lines.Count == 3);
            Check("ParseLines 错误分级", lines.Any(l => l.Severity == LogSeverity.Error));

            var onlyErr = LogManager.Filter(lines, onlyErrors: true);
            Check("Filter 仅错误=1", onlyErr.Count == 1);

            var kw = LogManager.Filter(lines, "内存");
            Check("Filter 关键字『内存』=1", kw.Count == 1);

            var dest = Path.Combine(root, "export.log");
            Check("Export 复制成功", LogManager.Export(logPath, dest) && File.Exists(dest));
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }

    private static async Task SeedLibraryTest()
    {
        var root = TempDir("seeds");
        try
        {
            var saves = Path.Combine(root, "saves");
            var path = SeedLibrary.CreateWorld(saves, "World1", 123456789, 3700);
            Check("CreateWorld 写出 level.dat", File.Exists(path));

            var seed = SeedLibrary.ExtractSeed(Path.Combine(saves, "World1"));
            Check("ExtractSeed 读回种子", seed == 123456789);

            // 网络不可用时安全返回空列表
            var empty = await SeedLibrary.SearchSeedsAsync(null, null, null, "http://127.0.0.1:1/nope");
            Check("SearchSeedsAsync 不可达返回空", empty.Count == 0);
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }

    private static async Task ScreenshotManagerTest()
    {
        var root = TempDir("shots");
        try
        {
            Check("空目录 ListScreenshots 为空", ScreenshotManager.ListScreenshots(root).Count == 0);

            var dir = ScreenshotManager.ScreenshotsDir(root);
            Directory.CreateDirectory(dir);
            var p1 = Path.Combine(dir, "a.png");
            await File.WriteAllTextAsync(p1, "x");
            Check("列出截图=1", ScreenshotManager.ListScreenshots(root).Count == 1);

            var zip = Path.Combine(root, "pack.zip");
            ScreenshotManager.Package(new[] { p1 }, zip);
            Check("Package 生成 zip", File.Exists(zip));

            Check("DeleteScreenshots 删除=1", ScreenshotManager.DeleteScreenshots(new[] { p1 }) == 1);
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }

    private static async Task NetworkDiagnosticsTest()
    {
        var eps = new[] { ("本地不可达", "http://127.0.0.1:1/") };
        var results = await NetworkDiagnostics.DiagnoseAsync(eps, new HttpClient());
        Check("不可达端点 Reachable=false", results.Count == 1 && !results[0].Reachable);

        var single = await NetworkDiagnostics.ProbeAsync("z", "http://127.0.0.1:1/", new HttpClient(), 2000);
        Check("ProbeAsync 超时 Reachable=false 且不抛异常", single.Reachable == false);
    }

    private static void RedundantCleanerTest()
    {
        var root = TempDir("redundant");
        try
        {
            Check("空 gameRoot Scan 为空", RedundantFileCleaner.Scan(root).Count == 0);
            Check("ComputeReferencedPaths 为空集合", RedundantFileCleaner.ComputeReferencedPaths(root).Count == 0);
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }

    private static void ModpackExportTest()
    {
        var root = TempDir("modpack");
        try
        {
            Directory.CreateDirectory(Path.Combine(root, "mods"));
            var dest = Path.Combine(root, "pack.zip");
            ModpackExporter.Export(root, "1.20.1", dest, new ModpackExportOptions
            {
                IncludeMods = false,
                IncludeConfig = false,
                IncludeResourcePacks = false,
                IncludeShaderPacks = false,
                IncludeSaves = false
            });
            Check("Export 生成 zip", File.Exists(dest));

            using var zip = ZipFile.OpenRead(dest);
            var manifestEntry = zip.GetEntry("mclcs_manifest.json");
            Check("含 mclcs_manifest.json", manifestEntry is not null);
            if (manifestEntry is not null)
            {
                using var sr = new StreamReader(manifestEntry.Open());
                var json = sr.ReadToEnd();
                Check("清单含版本 1.20.1", json.Contains("1.20.1"));
            }
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }

    private static void PlaytimeTrackerTest()
    {
        var root = TempDir("stats");
        try
        {
            var after1 = PlaytimeTracker.RecordLaunch(root, "1.20.1");
            Check("RecordLaunch 启动次数=1", after1.LaunchCount == 1);

            var after2 = PlaytimeTracker.RecordCrash(root);
            Check("RecordCrash 崩溃次数=1", after2.CrashCount == 1);

            var after3 = PlaytimeTracker.RecordPlayMinutes(root, 30);
            Check("RecordPlayMinutes 累计=30", after3.TotalPlayMinutes == 30);

            var loaded = PlaytimeTracker.Load(root);
            Check("Load 持久化启动次数", loaded.LaunchCount == 1 && loaded.TotalPlayMinutes == 30);
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }

    private static void AssistantTest()
    {
        Assistant.Config = new AiConfig { Enabled = false, Mode = AiMode.Local };
        var interp = Assistant.InterpretCrashAsync(
            "Exception in thread \"main\" java.lang.OutOfMemoryError: Java heap space").GetAwaiter().GetResult();
        Check("本地崩溃解读命中内存不足", interp.Contains("内存"));

        var noCrash = Assistant.InterpretCrashAsync("游戏正常退出").GetAwaiter().GetResult();
        Check("无已知类型回退提示", !string.IsNullOrEmpty(noCrash));

        var translated = Assistant.TranslateModDescriptionAsync("A cool mod").GetAwaiter().GetResult();
        Check("本地翻译原样返回", translated == "A cool mod");
    }

    private static async Task AiV2Tests()
    {
        Console.WriteLine("[AI 助手 v2：本地部署 Ollama + 外部 API]");

        // 本地模型目录
        Check("模型目录含 3 项", OllamaModels.Catalog.Count == 3);
        Check("默认模型为 Qwen2.5-Coder-1.5B", OllamaModels.Default.DisplayName == "Qwen2.5-Coder-1.5B");
        var qwen = OllamaModels.ByDisplayName("Qwen2.5-Coder-1.5B");
        Check("Qwen tag", qwen?.OllamaTag == "qwen2.5-coder:1.5b");
        Check("Qwen 大小 0.9GB", qwen?.SizeGb == 0.9);
        Check("Qwen 推荐标签", qwen?.RecommendTag == "【默认推荐】");
        var internlm = OllamaModels.ByDisplayName("InternLM2-1.8B");
        Check("InternLM 大小 1.1GB", internlm?.SizeGb == 1.1);
        var phi = OllamaModels.ByDisplayName("Phi-3.5-mini-3.8B");
        Check("Phi 大小 2.2GB", phi?.SizeGb == 2.2);

        // 版本号解析
        Check("ParseVersion 正常", OllamaManager.ParseVersion("ollama version 0.1.2") == "0.1.2");
        Check("ParseVersion 空", OllamaManager.ParseVersion("not a version") is null);

        // 外部 API 地址 → 模型名推断
        Check("openai -> gpt-4o-mini", Assistant.SuggestModelForEndpoint("https://api.openai.com/v1/chat/completions") == "gpt-4o-mini");
        Check("deepseek -> deepseek-chat", Assistant.SuggestModelForEndpoint("https://api.deepseek.com/v1/chat/completions") == "deepseek-chat");
        Check("127.0.0.1 -> 空", Assistant.SuggestModelForEndpoint("http://127.0.0.1:11434/api/chat") == "");
        Check("localhost -> 空", Assistant.SuggestModelForEndpoint("http://localhost:11434") == "");
        Check("其他 -> 空", Assistant.SuggestModelForEndpoint("https://my.example.com/v1") == "");

        // AiConfig 序列化往返
        var cfg = new AiConfig
        {
            Enabled = true,
            Mode = AiMode.Local,
            SelectedLocalModel = "qwen2.5-coder:1.5b",
            Endpoint = "http://127.0.0.1:11434/api/chat",
            Model = "gpt-4o-mini",
            CrashInterpret = true,
            RecommendReason = false,
            ModTranslate = true
        };
        var json = JsonSerializer.Serialize(cfg);
        var back = JsonSerializer.Deserialize<AiConfig>(json);
        Check("AiConfig 往返 Enabled", back?.Enabled == true);
        Check("AiConfig 往返 Mode=Local", back?.Mode == AiMode.Local);
        Check("AiConfig 往返 SelectedLocalModel", back?.SelectedLocalModel == "qwen2.5-coder:1.5b");

        // 离线环境：服务不可达 / 模型未拉取，且不抛异常
        var status = await OllamaManager.GetServiceStatusAsync();
        Check("离线 GetServiceStatus 返回 NotRunning", status == OllamaServiceStatus.NotRunning);
        var pulled = await OllamaManager.IsModelPulledAsync("qwen2.5-coder:1.5b");
        Check("离线 IsModelPulled 返回 false", pulled == false);

        // 外部 API 开启但无网络 → 回退本地启发式（含内存判定）
        Assistant.Config = new AiConfig
        {
            Enabled = true,
            Mode = AiMode.External,
            Endpoint = "http://127.0.0.1:1/v1/chat/completions",
            Model = "gpt-4o-mini"
        };
        var extFallback = Assistant.InterpretCrashAsync(
            "Exception in thread \"main\" java.lang.OutOfMemoryError: Java heap space").GetAwaiter().GetResult();
        Check("外部 API 失败回退启发式(内存)", extFallback.Contains("内存"));

        // 本地部署但 Ollama 未运行 → 回退本地启发式
        Assistant.Config = new AiConfig
        {
            Enabled = true,
            Mode = AiMode.Local,
            SelectedLocalModel = "qwen2.5-coder:1.5b"
        };
        var localFallback = Assistant.InterpretCrashAsync(
            "java.lang.UnsupportedClassVersionError: class file version 65.0").GetAwaiter().GetResult();
        Check("本地部署未运行回退启发式(Java版本)", localFallback.Contains("Java 版本"));
    }

    private static void LauncherUpdaterTest()
    {
        Check("IsNewer 1.0.0 > 0.5.0", LauncherUpdater.IsNewer("0.5.0", "1.0.0"));
        Check("IsNewer 0.5.0 < 1.0.0 为假", !LauncherUpdater.IsNewer("1.0.0", "0.5.0"));
        Check("IsNewer 相等为假", !LauncherUpdater.IsNewer("1.0.0", "1.0.0"));

        var result = LauncherUpdater.CheckAsync("1.0.0", "http://127.0.0.1:1/version.json", new HttpClient())
            .GetAwaiter().GetResult();
        Check("CheckAsync 不可达 Available=false 不抛异常", result.Available == false && result.Error is not null);
    }

    private static void InstanceTrackerTest()
    {
        var pid = System.Diagnostics.Process.GetCurrentProcess().Id;
        InstanceTracker.Register(pid, "1.20.1");
        var active = InstanceTracker.ListActive();
        Check("Register 后 ListActive 含当前进程", active.Any(i => i.Pid == pid));

        InstanceTracker.Unregister(pid);
        Check("Unregister 后 ActiveCount=0", InstanceTracker.ActiveCount() == 0);
    }
}
