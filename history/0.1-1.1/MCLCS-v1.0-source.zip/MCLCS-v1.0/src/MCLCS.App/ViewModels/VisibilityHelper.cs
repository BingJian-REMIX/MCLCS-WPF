using System.Windows.Controls;
using System.Windows.Data;

namespace MCLCS.App.ViewModels;

/// <summary>UI 辅助：暴露内置 <see cref="BooleanToVisibilityConverter"/> 的静态实例，供 XAML 绑定。</summary>
public static class VisibilityHelper
{
    /// <summary>bool → Visibility（true=Visible）。</summary>
    public static readonly IValueConverter BoolToVis = new BooleanToVisibilityConverter();

    /// <summary>bool → Visibility（true=Collapsed，即取反）。</summary>
    public static readonly IValueConverter BoolToVisInvert = new BooleanToVisibilityConverter
    {
        FalseValue = Visibility.Visible,
        TrueValue = Visibility.Collapsed
    };
}
