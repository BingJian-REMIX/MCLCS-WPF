using MCLCS.Core.Download;
using MCLCS.Core.Models;
using MCLCS.Core.Utils;

namespace MCLCS.Core.Mods;

/// <summary>
/// Mod 管理：扫描已安装 Mod、检查更新（通过 Modrinth）、卸载。
/// </summary>
public class ModManager
{
    private readonly string _gameRoot;
    private readonly ModrinthClient _modrinth;
    private readonly IDownloader _downloader;

    public ModManager(string gameRoot, HttpClient httpClient, IDownloader downloader)
    {
        _gameRoot = gameRoot;
        _modrinth = new ModrinthClient(httpClient);
        _downloader = downloader;
    }

    /// <summary>扫描 mods/ 目录，返回已安装的 Mod 列表。</summary>
    public List<ModEntry> ListInstalledMods()
    {
        var modsDir = PathEx.ModsDir(_gameRoot);
        if (!Directory.Exists(modsDir)) return new List<ModEntry>();

        var result = new List<ModEntry>();
        foreach (var file in Directory.EnumerateFiles(modsDir, "*.jar"))
        {
            var name = System.IO.Path.GetFileName(file);
            result.Add(new ModEntry
            {
                Id = name,
                Name = name,
                FileName = name,
                InstalledVersion = "unknown",
                ProjectUrl = ""
            });
        }
        return result;
    }

    /// <summary>对已安装的 Mod 批量检查更新（通过 Modrinth 搜索）。</summary>
    public async Task<List<ModEntry>> CheckForUpdatesAsync(CancellationToken ct = default)
    {
        var mods = ListInstalledMods();
        foreach (var mod in mods)
        {
            try
            {
                // 取文件名去除 .jar 作为搜索词
                var query = System.IO.Path.GetFileNameWithoutExtension(mod.FileName);
                if (string.IsNullOrWhiteSpace(query) || query.Length < 3) continue;

                var result = await _modrinth.SearchAsync(query, type: ModrinthProjectType.Mod, limit: 3, ct: ct);
                var hit = result.Hits.FirstOrDefault();
                if (hit is null) continue;

                var versions = await _modrinth.GetVersionsAsync(hit.ProjectId, ct);
                var latest = versions.FirstOrDefault()?.VersionNumber;
                mod.LatestVersion = latest;
                mod.ProjectUrl = $"https://modrinth.com/mod/{hit.Slug}";
            }
            catch
            {
                // 单个查询失败不影响整体
            }
        }
        return mods;
    }

    /// <summary>卸载 Mod（删除文件）。</summary>
    public bool UninstallMod(string fileName)
    {
        var path = System.IO.Path.Combine(PathEx.ModsDir(_gameRoot), fileName);
        if (!File.Exists(path)) return false;
        File.Delete(path);
        return true;
    }
}
