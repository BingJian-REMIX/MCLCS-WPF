# MCLCS — Minecraft 启动器

一个使用 **C# / WPF / .NET 8** 实现的 Minecraft 启动器，覆盖原版 / Fabric / Forge 安装、
智能 Java 选择、参数解析与变量替换、原生库处理、崩溃分析、Modrinth 下载中心、
**Microsoft / Authlib-Injector 登录、多账号管理、CLI 命令行、Mod 管理（含依赖检查）、
整合包安装（Modrinth .mrpack + CurseForge .zip）、皮肤预览、多语言（zh_CN / en_US）、
亮色/暗色主题切换**。

> v0.3 新增：CurseForge 整合包（.zip）安装、Mod 依赖检查（fabric.mod.json / mods.toml 解析）、
> 皮肤预览（Mojang API）、多语言支持（简体中文/English）、亮色/暗色主题切换、
> CLI 扩展（modpack/mods/skin 命令）、logging 日志参数注入。

---

## 功能一览

| 模块 | 说明 |
|---|---|
| 主界面与菜单 | Tab 式导航：版本列表、安装版本、下载中心、Mod 管理、皮肤预览、崩溃分析、设置 |
| 游戏启动 | 智能 Java 选择（≥21）、arguments 条件规则与变量替换、classpath 构建、natives 解压、内存/用户名/JVM 参数自定义、退出后崩溃检测、log4j 配置注入 |
| 崩溃分析 | 识别 OutOfMemoryError / UnsupportedClassVersionError / ClassNotFoundException / OpenGL 等 8 种异常 |
| 版本安装 | 原版 / Fabric / Forge / Modrinth 整合包（.mrpack）/ CurseForge 整合包（.zip） |
| 下载中心 | Modrinth 搜索，按版本/加载器（Fabric/Forge/Quilt/NeoForge）/类型过滤 |
| 账号系统 | 离线 / Microsoft（设备流 OAuth2）/ Authlib-Injector（Yggdrasil）；多账号存储与切换 |
| Mod 管理 | 扫描已安装、元数据解析（fabric.mod.json / mods.toml）、依赖检查、更新检查、卸载 |
| 皮肤预览 | 通过 Mojang API 查询正版玩家皮肤（支持 slim/classic 模型） |
| 多语言 | 简体中文 / English，内置翻译无需额外文件 |
| 主题 | 亮色/暗色主题切换，偏好持久化 |
| CLI 命令行 | launch / list / install / modpack / mods / skin / version |
| 辅助功能 | Java 自动安装（Temurin 21）、管理员权限提示 |

**零第三方运行时依赖**：核心逻辑仅使用 .NET 内置 API，MVVM 基类自研。

---

## 解决方案结构

```
MCLCS/
├── MCLCS.sln
├── src/
│   ├── MCLCS.Core/          # 平台无关核心逻辑（无 WPF 引用）
│   │   ├── Models/          # VersionJson / Library / Rule / FabricMeta / ForgeMeta /
│   │   │                   #   ModrinthModels / CurseForgeModels / ModMetaModels
│   │   ├── Launcher/        # JavaDetector, JavaInstaller, ArgumentProcessor,
│   │   │                   #   ClasspathBuilder, VersionMerger, GameLauncher,
│   │   │                   #   CrashDetector, CrashAnalyzer, RuleEvaluator
│   │   ├── Installers/      # Vanilla / Fabric / Forge / ModpackInstaller / CurseForgeModpackInstaller
│   │   ├── Download/        # HttpDownloader, MirrorPolicy, ModrinthClient, CurseForgeClient
│   │   ├── Auth/            # IAuthenticator, Offline, Microsoft, AuthlibInjector
│   │   ├── Profiles/        # LauncherProfile, ProfileStore, AccountStore
│   │   ├── Mods/            # ModManager, ModEntry, ModMetadataParser
│   │   ├── Skin/            # SkinFetcher (Mojang Sessionserver API)
│   │   ├── Localization/    # LocaleManager (zh_CN / en_US)
│   │   ├── Theme/           # ThemeManager (Light / Dark)
│   │   ├── Mvvm/            # ObservableObject, RelayCommand（零依赖）
│   │   └── Utils/           # GameConstants, PathEx, Unzip, HashUtil, Elevation
│   └── MCLCS.App/           # WPF 界面（.NET 8 / net8.0-windows）
│       ├── Views/           # 7 个页面（含 Mod 管理、皮肤预览）
│       ├── ViewModels/      # MVVM 视图模型
│       ├── Themes/          # DarkTheme.xaml / LightTheme.xaml
│       └── Services/        # LauncherService
├── tests/MCLCS.Core.Tests/  # xUnit 单元测试
├── tools/
│   ├── MCLCS.Cli/           # 命令行启动器
│   └── MCLCS.SelfCheck/     # 离线自检（70+ 项通过）
└── docs/
    ├── README.md
    └── BUILD.md
```

---

## 快速使用

### GUI
1. 启动器打开后，在「设置」中配置 Java 路径、内存、用户名、主题、语言并保存。
2. 在「安装新版本」中选择类型与版本号安装。
3. 在「版本列表」选择版本，点「启动游戏」。崩溃自动弹出分析报告。
4. 在「下载中心」搜索 Mod/光影/资源包并下载到对应目录。
5. 在「Mod 管理」中查看已安装 Mod、检查依赖关系、检查更新。

### CLI
```powershell
mclcs launch 1.20.1 --username Steve --memory 4096
mclcs list
mclcs install fabric 1.20.1
mclcs modpack modrinth mypack.mrpack
mclcs modpack curseforge mypack.zip
mclcs mods list
mclcs mods check
mclcs mods updates
mclcs skin Notch
mclcs version
```

---

## 镜像策略

所有下载优先走 **BMCLAPI**（`bmclapi2.bangbang93.com`），失败自动回退官方源。
Java 自动安装使用 Adoptium API，Modrinth 使用官方 API，CurseForge 使用公开 v1 API。

---

## 已知限制与后续路线

见 [BUILD.md](./BUILD.md)。
