using System.Collections.ObjectModel;
using System.Net.Http;
using System.Windows.Input;
using MCLCS.Core.Mvvm;
using MCLCS.Core.Profiles;
using MCLCS.Core.Recommend;
using MCLCS.Core.Servers;
using MCLCS.Core.UI;
using MCLCS.Core.Utils;
using MCLCS.App.Services;

namespace MCLCS.App.ViewModels;

/// <summary>
/// 游戏页视图模型（需求规格 2.1）。
/// 快速启动区绑定版本列表 / 用户名 / 内存；局域网与服务器列表接真实后端
/// （LanServerScanner / ServerListStore / ServerPinger）；智能推荐接 RecommendationEngine。
/// 加入按钮目前触发启动（直接连接地址的接线见 LaunchCliOverrides 注释，留待 v2.2 完善）。
/// </summary>
public class GameViewModel : ObservableObject
{
    private readonly string _gameRoot = GameConstants.DefaultGameRoot;
    private readonly LauncherProfile _profile = ProfileStore.Load(GameConstants.DefaultGameRoot);

    public VersionListViewModel Versions { get; } = new();

    private string _username;
    public string Username
    {
        get => _username;
        set => SetField(ref _username, value);
    }

    private int _memoryMb;
    public int MemoryMb
    {
        get => _memoryMb;
        set => SetField(ref _memoryMb, value);
    }

    /// <summary>局域网世界（"对局域网开放"广播）。</summary>
    public ObservableCollection<LanServer> LanServers { get; } = new();

    /// <summary>服务器列表（来自 servers.dat）。</summary>
    public ObservableCollection<ServerEntry> Servers { get; } = new();

    /// <summary>智能推荐 Top N。</summary>
    public ObservableCollection<RecommendationItem> Recommendations { get; } = new();

    private bool _lanEmpty = true;
    /// <summary>局域网列表是否为空（驱动空状态提示）。</summary>
    public bool LanEmpty { get => _lanEmpty; private set => SetField(ref _lanEmpty, value); }

    private bool _serversEmpty = true;
    /// <summary>服务器列表是否为空。</summary>
    public bool ServersEmpty { get => _serversEmpty; private set => SetField(ref _serversEmpty, value); }

    private bool _recommendEmpty = true;
    /// <summary>推荐列表是否为空。</summary>
    public bool RecommendEmpty { get => _recommendEmpty; private set => SetField(ref _recommendEmpty, value); }

    public ICommand LaunchCommand { get; }
    public ICommand ScanLanCommand { get; }
    public ICommand RefreshServersCommand { get; }
    public ICommand RefreshRecommendCommand { get; }
    public ICommand JoinLanCommand { get; }
    public ICommand JoinServerCommand { get; }

    public GameViewModel()
    {
        _username = _profile.DefaultUsername;
        _memoryMb = _profile.MaxMemoryMb > 0 ? _profile.MaxMemoryMb : 2048;

        LaunchCommand = new AsyncRelayCommand(_ => LaunchAsync());
        ScanLanCommand = new AsyncRelayCommand(_ => ScanLanAsync());
        RefreshServersCommand = new AsyncRelayCommand(_ => RefreshServersAsync());
        RefreshRecommendCommand = new AsyncRelayCommand(_ => RefreshRecommendAsync());
        JoinLanCommand = new AsyncRelayCommand(p => JoinLanAsync(p as LanServer));
        JoinServerCommand = new AsyncRelayCommand(p => JoinServerAsync(p as ServerEntry));

        Versions.Refresh();
        LoadServers();

        LanServers.CollectionChanged += (_, _) => LanEmpty = LanServers.Count == 0;
        Servers.CollectionChanged += (_, _) => ServersEmpty = Servers.Count == 0;
        Recommendations.CollectionChanged += (_, _) => RecommendEmpty = Recommendations.Count == 0;
    }

    private string SelectedVersionId =>
        Versions.SelectedVersion?.Id ?? _profile.LastVersionId ?? "";

    private async Task LaunchAsync()
    {
        var id = SelectedVersionId;
        if (string.IsNullOrWhiteSpace(id)) return;
        await LauncherService.Instance.LaunchAsync(id, null,
            new LaunchCliOverrides { Username = Username, MaxMemoryMb = MemoryMb });
    }

    private async Task ScanLanAsync()
    {
        LanServers.Clear();
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(6));
        try
        {
            var found = await LanServerScanner.ScanAsync(onFound: s =>
            {
                if (!LanServers.Any(x => x.Endpoint == s.Endpoint))
                    LanServers.Add(s);
            }, ct: cts.Token);
            foreach (var s in found)
                if (!LanServers.Any(x => x.Endpoint == s.Endpoint))
                    LanServers.Add(s);
        }
        catch
        {
            // 监听失败（无权限 / 平台不支持）静默返回空列表
        }
    }

    private void LoadServers()
    {
        Servers.Clear();
        foreach (var s in ServerListStore.Load(_gameRoot))
            Servers.Add(s);
    }

    private async Task RefreshServersAsync()
    {
        LoadServers();
        try { await ServerPinger.PingAllAsync(Servers); }
        catch { /* 离线时保持 -1 */ }
    }

    private async Task RefreshRecommendAsync()
    {
        Recommendations.Clear();
        try
        {
            using var client = new HttpClient();
            var items = await RecommendationEngine.BuildAsync(_gameRoot, _profile, client, null);
            foreach (var it in items.Take(8))
                Recommendations.Add(it);
        }
        catch
        {
            // 联网失败时用本地规则，引擎内部已处理；此处兜底为空
        }
    }

    private async Task JoinLanAsync(LanServer? s)
    {
        if (s is null) return;
        // 直接连接地址需 LauncherService 透传 ServerAddress（LaunchCliOverrides 暂未含该字段），
        // 此处先启动对应版本，连接交互留待 v2.2。
        await LauncherService.Instance.LaunchAsync(_profile.LastVersionId ?? SelectedVersionId, null,
            new LaunchCliOverrides { Username = Username, MaxMemoryMb = MemoryMb });
    }

    private async Task JoinServerAsync(ServerEntry? s)
    {
        if (s is null) return;
        await LauncherService.Instance.LaunchAsync(_profile.LastVersionId ?? SelectedVersionId, null,
            new LaunchCliOverrides { Username = Username, MaxMemoryMb = MemoryMb });
    }
}
