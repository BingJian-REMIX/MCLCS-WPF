using System.Windows;
using Microsoft.Win32;

namespace MCLCS.App.Services;

/// <summary>
/// 简单的 UI 服务：消息框与文件/文件夹选择。
/// </summary>
public static class UIService
{
    public static void ShowMessage(string message, string title = "MCLCS")
    {
        MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information);
    }

    public static void ShowError(string message, string title = "错误")
    {
        MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Error);
    }

    public static bool Confirm(string message, string title = "确认")
    {
        return MessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;
    }

    public static string? PickFolder(string description = "选择文件夹")
    {
        var dialog = new System.Windows.Forms.FolderBrowserDialog
        {
            Description = description,
            UseDescriptionForTitle = true
        };

        return dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK ? dialog.SelectedPath : null;
    }

    public static string? PickFile(string filter = "所有文件|*.*", string title = "选择文件")
    {
        var dialog = new OpenFileDialog
        {
            Filter = filter,
            Title = title
        };

        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }
}
