using System.Windows.Controls;
using MCLCS.App.ViewModels;

namespace MCLCS.App.Views;

public partial class DownloadPageView : UserControl
{
    public DownloadPageViewModel ViewModel { get; }

    public DownloadPageView()
    {
        InitializeComponent();
        ViewModel = new DownloadPageViewModel();
        DataContext = ViewModel;
    }

    /// <summary>由 MainWindow 侧边栏路由调用，切换到指定副标签并加载内容（解决 TODO(v2.2)）。</summary>
    public void ShowSubTab(string? id) => ViewModel.SetSubTab(id);
}
