using System.Text.Json.Serialization;
using MCLCS.Core.Utils;

namespace MCLCS.Core.Profiles;

/// <summary>启动器持久化配置（默认用户名、内存、Java 路径等）。</summary>
public class LauncherProfile
{
    [JsonPropertyName("defaultUsername")]
    public string DefaultUsername { get; set; } = "Player";

    [JsonPropertyName("maxMemoryMb")]
    public int MaxMemoryMb { get; set; } = 2048;

    [JsonPropertyName("minMemoryMb")]
    public int MinMemoryMb { get; set; } = 512;

    [JsonPropertyName("javaPath")]
    public string? JavaPath { get; set; }

    [JsonPropertyName("gameRoot")]
    public string GameRoot { get; set; } = GameConstants.DefaultGameRoot;

    [JsonPropertyName("lastVersionId")]
    public string? LastVersionId { get; set; }

    [JsonPropertyName("resolutionWidth")]
    public int? ResolutionWidth { get; set; }

    [JsonPropertyName("resolutionHeight")]
    public int? ResolutionHeight { get; set; }

    /// <summary>额外的 JVM 参数（如 -XX:+UseZGC）。</summary>
    [JsonPropertyName("extraJvmArgs")]
    public List<string> ExtraJvmArgs { get; set; } = new();

    /// <summary>当前活跃账号 ID（AccountEntry.Id）。</summary>
    [JsonPropertyName("lastAccountId")]
    public string? LastAccountId { get; set; }
}
