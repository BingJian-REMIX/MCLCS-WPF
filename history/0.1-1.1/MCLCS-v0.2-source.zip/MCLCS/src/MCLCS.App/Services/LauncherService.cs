using MCLCS.Core.Auth;
using MCLCS.Core.Download;
using MCLCS.Core.Installers;
using MCLCS.Core.Launcher;
using MCLCS.Core.Models;
using MCLCS.Core.Profiles;
using MCLCS.Core.Utils;

namespace MCLCS.App.Services;

/// <summary>
/// 应用级服务：持有 HttpClient / 下载器 / 游戏目录，并暴露安装、启动、下载 Mod、版本列表等操作。
/// 实现 ILogger 以将进度回传到 UI。
/// </summary>
public class LauncherService : ILogger
{
    public static LauncherService Instance { get; private set; } = new(GameConstants.DefaultGameRoot);

    private readonly HttpClient _client = new();
    private readonly IDownloader _downloader;

    public string GameRoot { get; }

    public event Action<string>? Logged;

    public LauncherService(string gameRoot)
    {
        GameRoot = gameRoot;
        _downloader = new HttpDownloader(_client, 8, this);
    }

    public void Log(string message) => Logged?.Invoke(message);

    // ---- 版本列表 ----

    public async Task<List<string>> GetVanillaVersionsAsync()
    {
        try
        {
            var json = await MirrorPolicy.GetStringWithFallback(MirrorPolicy.VersionManifestUrls(), _client);
            var manifest = System.Text.Json.JsonSerializer.Deserialize<VersionManifest>(json);
            return manifest?.Versions.Select(v => v.Id).ToList() ?? new List<string>();
        }
        catch
        {
            return new List<string>();
        }
    }

    public List<(string Id, string Type)> ListInstalledVersions()
    {
        var result = new List<(string Id, string Type)>();
        var versionsDir = PathEx.VersionsDir(GameRoot);
        if (!Directory.Exists(versionsDir)) return result;

        foreach (var dir in Directory.GetDirectories(versionsDir))
        {
            var id = Path.GetFileName(dir);
            var jsonPath = PathEx.VersionJsonPath(GameRoot, id);
            if (!File.Exists(jsonPath)) continue;
            var type = "";
            try
            {
                var json = File.ReadAllText(jsonPath);
                var v = System.Text.Json.JsonSerializer.Deserialize<VersionJson>(json);
                type = v?.Type ?? "";
            }
            catch { /* 忽略解析错误 */ }
            result.Add((id, type));
        }
        return result;
    }

    // ---- 安装 ----

    public async Task InstallAsync(string installType, string versionId,
        IProgress<(int Done, int Total)>? progress = null, CancellationToken ct = default)
    {
        InstallerBase installer = installType.ToLowerInvariant() switch
        {
            "fabric" => new FabricInstaller(GameRoot, _client, _downloader, this),
            "forge" => new ForgeInstaller(GameRoot, _client, _downloader, this),
            _ => new VanillaInstaller(GameRoot, _client, _downloader, this)
        };

        switch (installer)
        {
            case VanillaInstaller v: await v.InstallAsync(versionId, progress, ct); break;
            case FabricInstaller f: await f.InstallAsync(versionId, progress, ct); break;
            case ForgeInstaller g: await g.InstallAsync(versionId, progress, ct); break;
        }
    }

    // ---- 启动 ----

    /// <summary>使用指定认证方式启动游戏。authenticator 为 null 时默认离线。cliOverrides 可覆盖内存/用户名/Java。</summary>
    public async Task<LaunchResult> LaunchAsync(string versionId,
        IAuthenticator? authenticator = null,
        LaunchCliOverrides? cliOverrides = null,
        CancellationToken ct = default)
    {
        var profile = ProfileStore.Load(GameRoot);
        var java = await ResolveJavaAsync(profile, cliOverrides, ct);

        // 解析账号
        AuthSession session;
        if (authenticator is not null)
        {
            var account = AccountStore.GetLastUsed(GameRoot);
            var username = cliOverrides?.Username ?? account?.Username ?? profile.DefaultUsername;
            session = await authenticator.AuthenticateAsync(username, ct);
        }
        else
        {
            var username = cliOverrides?.Username ?? profile.DefaultUsername;
            session = await new OfflineAuthenticator().AuthenticateAsync(username, ct);
        }

        var options = new LaunchOptions
        {
            Username = session.Username,
            Uuid = session.Uuid,
            AccessToken = session.AccessToken,
            UserType = session.UserType,
            MaxMemoryMb = cliOverrides?.MaxMemoryMb ?? profile.MaxMemoryMb,
            MinMemoryMb = cliOverrides?.MinMemoryMb ?? profile.MinMemoryMb,
            ExtraJvmArgs = profile.ExtraJvmArgs
        };

        if (profile.ResolutionWidth.HasValue && profile.ResolutionHeight.HasValue)
            options.Resolution = (profile.ResolutionWidth.Value, profile.ResolutionHeight.Value);

        // 记住最后使用的版本
        profile.LastVersionId = versionId;
        ProfileStore.Save(profile);

        return await GameLauncher.LaunchAsync(GameRoot, versionId, java, options, this, ct);
    }

    private async Task<JavaInfo> ResolveJavaAsync(LauncherProfile profile, LaunchCliOverrides? cliOverrides, CancellationToken ct)
    {
        // CLI 指定的 Java 路径优先
        if (!string.IsNullOrEmpty(cliOverrides?.JavaPath) && File.Exists(cliOverrides.JavaPath))
        {
            var (major, raw) = await JavaDetector.QueryVersionAsync(cliOverrides.JavaPath);
            if (major >= GameConstants.MinimumJavaMajorVersion)
                return new JavaInfo { JavaExe = cliOverrides.JavaPath, MajorVersion = major, RawVersion = raw };
        }

        JavaInfo? java = null;
        if (!string.IsNullOrEmpty(profile.JavaPath) && File.Exists(profile.JavaPath))
        {
            var (major, raw) = await JavaDetector.QueryVersionAsync(profile.JavaPath);
            if (major >= GameConstants.MinimumJavaMajorVersion)
                java = new JavaInfo { JavaExe = profile.JavaPath, MajorVersion = major, RawVersion = raw };
        }

        java ??= await JavaDetector.FindBestAsync(GameConstants.MinimumJavaMajorVersion);
        if (java is null)
            java = await JavaInstaller.EnsureJavaAsync(GameConstants.MinimumJavaMajorVersion, GameRoot, _downloader, this, ct);

        return java ?? throw new InvalidOperationException("未找到可用的 Java 运行环境");
    }

    // ---- 下载中心（Modrinth）----

    public async Task<List<ModrinthHit>> SearchModsAsync(string query, string? gameVersion, LoaderType loader, ModrinthProjectType type)
    {
        var client = new ModrinthClient(_client);
        var result = await client.SearchAsync(query, gameVersion, loader, type);
        return result.Hits;
    }

    public async Task<bool> DownloadModAsync(string projectId, string targetDir, string? gameVersion, LoaderType loader)
    {
        var client = new ModrinthClient(_client);
        var versions = await client.GetVersionsAsync(projectId);
        var ver = versions.FirstOrDefault(v =>
                        (string.IsNullOrEmpty(gameVersion) || v.GameVersions.Contains(gameVersion))
                        && (loader == LoaderType.Any || v.Loaders.Contains(ModrinthClient.LoaderString(loader), StringComparer.OrdinalIgnoreCase)))
                  ?? versions.FirstOrDefault();
        if (ver is null) return false;

        var file = client.SelectBestFile(ver, gameVersion, loader);
        if (file is null) return false;

        Directory.CreateDirectory(targetDir);
        var dest = Path.Combine(targetDir, file.FileName);
        await _downloader.DownloadAsync(new DownloadItem(new[] { file.Url }, dest, file.Hashes.Sha1), null, CancellationToken.None);
        return true;
    }
}

/// <summary>CLI 传入的启动参数覆盖（不持久化）。</summary>
public class LaunchCliOverrides
{
    public string? Username { get; set; }
    public int? MaxMemoryMb { get; set; }
    public int? MinMemoryMb { get; set; }
    public string? JavaPath { get; set; }
    public List<string>? ExtraJvmArgs { get; set; }
}
