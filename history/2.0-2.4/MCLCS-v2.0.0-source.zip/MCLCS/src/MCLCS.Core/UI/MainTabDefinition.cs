using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

namespace MCLCS.Core.UI;

/// <summary>index 主标签页标识（四色主标签）。</summary>
public enum MainTabKind
{
    /// <summary>主页（绿）。</summary>
    Home,
    /// <summary>游戏（蓝）。</summary>
    Game,
    /// <summary>下载（橙）。</summary>
    Download,
    /// <summary>工具箱（灰）。</summary>
    Toolbox
}

/// <summary>
/// 主标签页定义：标识 / 标题 / 默认配色 / 图标 / 排序。
/// 界面层据此渲染 index 的四个主标签，配色可被 <see cref="TabThemeConfig"/> 覆盖。
/// </summary>
public sealed class MainTabDefinition
{
    public MainTabDefinition(MainTabKind kind, string title, string defaultColor, string icon, int order)
    {
        Kind = kind;
        Title = title;
        DefaultColor = defaultColor;
        Icon = icon;
        Order = order;
    }

    public MainTabKind Kind { get; }

    /// <summary>显示标题。</summary>
    public string Title { get; }

    /// <summary>默认配色（#RRGGBB）。</summary>
    public string DefaultColor { get; }

    /// <summary>图标名（界面层自行映射字体图标）。</summary>
    public string Icon { get; }

    /// <summary>展示顺序（从 0 起）。</summary>
    public int Order { get; }
}

/// <summary>四色主标签注册表。</summary>
public static class MainTabs
{
    /// <summary>主页 - 绿。</summary>
    public const string DefaultHomeColor = "#4CAF50";

    /// <summary>游戏 - 蓝。</summary>
    public const string DefaultGameColor = "#2196F3";

    /// <summary>下载 - 橙。</summary>
    public const string DefaultDownloadColor = "#FF9800";

    /// <summary>工具箱 - 灰。</summary>
    public const string DefaultToolboxColor = "#9E9E9E";

    /// <summary>四个主标签，按 Order 升序。</summary>
    public static IReadOnlyList<MainTabDefinition> All { get; } = new List<MainTabDefinition>
    {
        new(MainTabKind.Home,     "主页",   DefaultHomeColor,     "home",     0),
        new(MainTabKind.Game,     "游戏",   DefaultGameColor,     "gamepad",  1),
        new(MainTabKind.Download, "下载",   DefaultDownloadColor, "download", 2),
        new(MainTabKind.Toolbox,  "工具箱", DefaultToolboxColor,  "toolbox",  3)
    };

    public static MainTabDefinition Get(MainTabKind kind) => All.First(t => t.Kind == kind);

    /// <summary>按标题查找（找不到返回 null）。</summary>
    public static MainTabDefinition? ByTitle(string? title) =>
        string.IsNullOrWhiteSpace(title) ? null : All.FirstOrDefault(t => t.Title == title);
}

/// <summary>
/// 主标签配色配置（持久化到 LauncherProfile）。允许用户自定义四色，非法值自动回退默认。
/// </summary>
public class TabThemeConfig
{
    [JsonPropertyName("home")]
    public string Home { get; set; } = MainTabs.DefaultHomeColor;

    [JsonPropertyName("game")]
    public string Game { get; set; } = MainTabs.DefaultGameColor;

    [JsonPropertyName("download")]
    public string Download { get; set; } = MainTabs.DefaultDownloadColor;

    [JsonPropertyName("toolbox")]
    public string Toolbox { get; set; } = MainTabs.DefaultToolboxColor;

    /// <summary>是否对未选中的标签使用灰度显示（选中才上色）。</summary>
    [JsonPropertyName("colorOnlyWhenActive")]
    public bool ColorOnlyWhenActive { get; set; } = true;

    private static readonly Regex HexColor =
        new("^#(?:[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$", RegexOptions.Compiled);

    /// <summary>校验 #RRGGBB 或 #AARRGGBB。</summary>
    public static bool IsValidColor(string? color) =>
        !string.IsNullOrWhiteSpace(color) && HexColor.IsMatch(color!.Trim());

    /// <summary>取某个标签的实际配色；自定义值非法时回退默认色。</summary>
    public string ColorOf(MainTabKind kind)
    {
        var custom = kind switch
        {
            MainTabKind.Home => Home,
            MainTabKind.Game => Game,
            MainTabKind.Download => Download,
            MainTabKind.Toolbox => Toolbox,
            _ => null
        };
        return IsValidColor(custom) ? custom!.Trim().ToUpperInvariant() : MainTabs.Get(kind).DefaultColor;
    }

    /// <summary>设置某个标签的配色；非法值返回 false 且不修改。</summary>
    public bool SetColor(MainTabKind kind, string? color)
    {
        if (!IsValidColor(color)) return false;
        var v = color!.Trim().ToUpperInvariant();
        switch (kind)
        {
            case MainTabKind.Home: Home = v; break;
            case MainTabKind.Game: Game = v; break;
            case MainTabKind.Download: Download = v; break;
            case MainTabKind.Toolbox: Toolbox = v; break;
            default: return false;
        }
        return true;
    }

    /// <summary>是否已被用户改动过（与默认四色不同）。</summary>
    public bool IsCustomized() =>
        MainTabs.All.Any(t => !string.Equals(ColorOf(t.Kind), t.DefaultColor, StringComparison.OrdinalIgnoreCase));

    /// <summary>恢复默认四色。</summary>
    public void Reset()
    {
        Home = MainTabs.DefaultHomeColor;
        Game = MainTabs.DefaultGameColor;
        Download = MainTabs.DefaultDownloadColor;
        Toolbox = MainTabs.DefaultToolboxColor;
    }
}
