using System.Windows.Controls;

namespace MCLCS.App.Views;

public partial class DownloadPageView : UserControl
{
    public DownloadPageView()
    {
        InitializeComponent();
    }
}
