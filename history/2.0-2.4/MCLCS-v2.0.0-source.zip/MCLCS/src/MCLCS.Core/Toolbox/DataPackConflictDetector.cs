using System.IO.Compression;
using System.Text.Json;

namespace MCLCS.Core.Toolbox;

/// <summary>一个数据包。</summary>
public class DataPackInfo
{
    /// <summary>数据包名（目录名或 zip 文件名）。</summary>
    public string Name { get; set; } = "";

    /// <summary>完整路径。</summary>
    public string Path { get; set; } = "";

    /// <summary>是否为 zip 形式。</summary>
    public bool IsZip { get; set; }

    /// <summary>pack.mcmeta 中的 pack_format。</summary>
    public int PackFormat { get; set; }

    /// <summary>pack.mcmeta 中的描述。</summary>
    public string? Description { get; set; }

    /// <summary>是否缺少 pack.mcmeta（非法数据包）。</summary>
    public bool MissingMeta { get; set; }

    /// <summary>包内资源路径（形如 <c>data/命名空间/类别/xxx.json</c>）。</summary>
    public List<string> Resources { get; set; } = new();

    /// <summary>加载顺序（越大越靠后，后者覆盖前者）。</summary>
    public int LoadOrder { get; set; }
}

/// <summary>一处冲突。</summary>
public sealed class DataPackConflict
{
    public DataPackConflict(string resource, List<string> packs, string winner)
    {
        Resource = resource;
        Packs = packs;
        Winner = winner;
    }

    /// <summary>冲突的资源路径。</summary>
    public string Resource { get; }

    /// <summary>涉及的数据包（按加载顺序）。</summary>
    public List<string> Packs { get; }

    /// <summary>最终生效的数据包（加载顺序最靠后的）。</summary>
    public string Winner { get; }

    /// <summary>被覆盖掉的数据包。</summary>
    public IEnumerable<string> Losers => Packs.Where(p => p != Winner);

    public override string ToString() =>
        $"{Resource}：{string.Join(" → ", Packs)}（生效：{Winner}）";
}

/// <summary>检测报告。</summary>
public sealed class DataPackReport
{
    public List<DataPackInfo> Packs { get; } = new();
    public List<DataPackConflict> Conflicts { get; } = new();

    /// <summary>pack_format 与目标游戏版本不符的包。</summary>
    public List<string> FormatWarnings { get; } = new();

    /// <summary>缺少 pack.mcmeta 的包。</summary>
    public IEnumerable<DataPackInfo> Invalid => Packs.Where(p => p.MissingMeta);

    public bool HasConflicts => Conflicts.Count > 0;

    public string Summary =>
        $"共 {Packs.Count} 个数据包，冲突 {Conflicts.Count} 处，格式告警 {FormatWarnings.Count} 条";
}

/// <summary>
/// 数据包冲突检测（工具箱开发工具）：扫描存档 <c>datapacks/</c> 目录，
/// 解析每个包的 <c>pack.mcmeta</c> 与资源清单，找出同一资源被多个包定义的情况。
/// Minecraft 的覆盖规则是"后加载者胜出"，因此加载顺序靠后的包为最终生效方。
/// </summary>
public static class DataPackConflictDetector
{
    /// <summary>常见 pack_format 与游戏版本的对应（用于格式告警）。</summary>
    public static readonly Dictionary<string, int> KnownPackFormats = new()
    {
        ["1.16"] = 6, ["1.17"] = 7, ["1.18"] = 8, ["1.19"] = 10,
        ["1.20"] = 15, ["1.20.5"] = 41, ["1.21"] = 48
    };

    /// <summary>存档中的数据包目录。</summary>
    public static string DataPacksDir(string saveDir) => Path.Combine(saveDir, "datapacks");

    /// <summary>解析 pack.mcmeta 文本，返回 (pack_format, description)。</summary>
    public static (int Format, string? Description) ParseMeta(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return (0, null);
        try
        {
            using var doc = JsonDocument.Parse(json);
            if (!doc.RootElement.TryGetProperty("pack", out var pack)) return (0, null);

            var format = pack.TryGetProperty("pack_format", out var pf) && pf.TryGetInt32(out var f) ? f : 0;

            string? desc = null;
            if (pack.TryGetProperty("description", out var d))
            {
                desc = d.ValueKind switch
                {
                    JsonValueKind.String => d.GetString(),
                    JsonValueKind.Object when d.TryGetProperty("text", out var t) => t.GetString(),
                    _ => d.ToString()
                };
            }
            return (format, desc);
        }
        catch
        {
            return (0, null);
        }
    }

    /// <summary>
    /// 判断资源路径是否参与冲突比较：只统计 <c>data/</c> 下的实际资源文件。
    /// </summary>
    public static bool IsComparableResource(string relativePath)
    {
        var p = relativePath.Replace('\\', '/').TrimStart('/');
        if (!p.StartsWith("data/", StringComparison.OrdinalIgnoreCase)) return false;
        if (p.EndsWith('/')) return false;
        return p.Count(c => c == '/') >= 3;   // data/<ns>/<类别>/<文件>
    }

    /// <summary>扫描一个存档的数据包目录。</summary>
    public static DataPackReport Scan(string saveDir, string? targetVersion = null)
    {
        var report = new DataPackReport();
        var dir = DataPacksDir(saveDir);
        if (!Directory.Exists(dir)) return report;

        var order = 0;
        var candidates = Directory.GetFileSystemEntries(dir)
            .OrderBy(p => Path.GetFileName(p), StringComparer.OrdinalIgnoreCase);

        foreach (var entry in candidates)
        {
            var info = Directory.Exists(entry) ? ReadFolderPack(entry) : ReadZipPack(entry);
            if (info is null) continue;
            info.LoadOrder = order++;
            report.Packs.Add(info);
        }

        // 格式告警
        if (!string.IsNullOrWhiteSpace(targetVersion))
        {
            var expected = ExpectedFormat(targetVersion!);
            if (expected > 0)
            {
                foreach (var p in report.Packs.Where(p => p.PackFormat > 0 && p.PackFormat != expected))
                    report.FormatWarnings.Add(
                        $"{p.Name}：pack_format={p.PackFormat}，{targetVersion} 期望 {expected}");
            }
        }

        report.Conflicts.AddRange(FindConflicts(report.Packs));
        return report;
    }

    /// <summary>在已解析的包列表中找出冲突（纯函数）。</summary>
    public static List<DataPackConflict> FindConflicts(IEnumerable<DataPackInfo> packs)
    {
        var map = new Dictionary<string, List<DataPackInfo>>(StringComparer.OrdinalIgnoreCase);
        foreach (var pack in packs)
        {
            foreach (var res in pack.Resources.Where(IsComparableResource))
            {
                var key = res.Replace('\\', '/').TrimStart('/');
                if (!map.TryGetValue(key, out var list)) map[key] = list = new List<DataPackInfo>();
                if (!list.Contains(pack)) list.Add(pack);
            }
        }

        return map.Where(kv => kv.Value.Count > 1)
            .Select(kv =>
            {
                var ordered = kv.Value.OrderBy(p => p.LoadOrder).ToList();
                return new DataPackConflict(
                    kv.Key,
                    ordered.Select(p => p.Name).ToList(),
                    ordered[^1].Name);
            })
            .OrderBy(c => c.Resource, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    /// <summary>按游戏版本推断期望的 pack_format（取最接近的主版本）。</summary>
    public static int ExpectedFormat(string version)
    {
        if (KnownPackFormats.TryGetValue(version, out var exact)) return exact;

        var parts = version.Split('.');
        if (parts.Length >= 2)
        {
            var major = $"{parts[0]}.{parts[1]}";
            if (KnownPackFormats.TryGetValue(major, out var m)) return m;
        }
        return 0;
    }

    private static DataPackInfo? ReadFolderPack(string dir)
    {
        try
        {
            var info = new DataPackInfo { Name = Path.GetFileName(dir), Path = dir, IsZip = false };
            var metaPath = Path.Combine(dir, "pack.mcmeta");
            if (File.Exists(metaPath))
            {
                var (fmt, desc) = ParseMeta(File.ReadAllText(metaPath));
                info.PackFormat = fmt;
                info.Description = desc;
            }
            else
            {
                info.MissingMeta = true;
            }

            var dataDir = Path.Combine(dir, "data");
            if (Directory.Exists(dataDir))
            {
                foreach (var f in Directory.GetFiles(dataDir, "*", SearchOption.AllDirectories))
                    info.Resources.Add(Path.GetRelativePath(dir, f).Replace('\\', '/'));
            }
            return info;
        }
        catch
        {
            return null;
        }
    }

    private static DataPackInfo? ReadZipPack(string zipPath)
    {
        if (!zipPath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)) return null;
        try
        {
            var info = new DataPackInfo
            {
                Name = Path.GetFileName(zipPath),
                Path = zipPath,
                IsZip = true
            };

            using var archive = ZipFile.OpenRead(zipPath);
            var meta = archive.GetEntry("pack.mcmeta");
            if (meta is not null)
            {
                using var reader = new StreamReader(meta.Open());
                var (fmt, desc) = ParseMeta(reader.ReadToEnd());
                info.PackFormat = fmt;
                info.Description = desc;
            }
            else
            {
                info.MissingMeta = true;
            }

            foreach (var e in archive.Entries)
            {
                if (e.FullName.EndsWith('/')) continue;
                info.Resources.Add(e.FullName.Replace('\\', '/'));
            }
            return info;
        }
        catch
        {
            return null;
        }
    }
}
